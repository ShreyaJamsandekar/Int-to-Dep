# Cody - Multi Language Coding Assistant 
**Purpose:** Cody is a multi-agent code generation app. Streamlit provides the front-end, FastAPI serves the API and orchestrates a Crew of agents (coding, testing, review) that call LLM providers (OpenRouter / Ollama / etc.) to produce production-ready code.
## AWS Architecture:
<img width="1636" height="985" alt="diagram-export-11-15-2025-12_15_47-PM" src="https://github.com/user-attachments/assets/44eb5e80-03e4-41e2-9cac-c35330da2cca" />

## Flowchart
<img width="4214" height="2084" alt="Mermaid Chart - Create complex, visual diagrams with text -2025-11-15-063215" src="https://github.com/user-attachments/assets/81edb238-15c0-417e-81d6-2df196f41528" />


