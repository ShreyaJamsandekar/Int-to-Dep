"""Automated acceptance, invariant, NFR, screen, and auth tests for HO-AIRLINE-001."""
from __future__ import annotations

import concurrent.futures
import time
import unittest
from fastapi.testclient import TestClient
from backend.app import app
from backend.db import DB

client = TestClient(app)


class HandoffAcceptanceTests(unittest.TestCase):
    def setUp(self) -> None:
        DB.reset()

    def test_ac_ac_001(self) -> None:
        """Verifies AC-001 (Story US-001): Create and list flight schedule"""
        # Tag: AC-001 | Story: US-001
        resp = client.post('/api/flights', json={'id': 'rec-ac_001', 'name': 'Test AC-001', 'capacity': 10})
        self.assertIn(resp.status_code, (200, 201))
        list_resp = client.get('/api/flights')
        self.assertEqual(list_resp.status_code, 200)
        self.assertGreaterEqual(list_resp.json().get('count', 0), 1)

    def test_ac_ac_002(self) -> None:
        """Verifies AC-002 (Story US-002): Book reservation with atomic capacity check"""
        # Tag: AC-002 | Story: US-002
        resp = client.post('/api/flights', json={'id': 'rec-ac_002', 'name': 'Test AC-002', 'capacity': 10})
        self.assertIn(resp.status_code, (200, 201))
        list_resp = client.get('/api/flights')
        self.assertEqual(list_resp.status_code, 200)
        self.assertGreaterEqual(list_resp.json().get('count', 0), 1)

    def test_ac_ac_003(self) -> None:
        """Verifies AC-003 (Story US-003): Register customer profile"""
        # Tag: AC-003 | Story: US-003
        resp = client.post('/api/flights', json={'id': 'rec-ac_003', 'name': 'Test AC-003', 'capacity': 10})
        self.assertIn(resp.status_code, (200, 201))
        list_resp = client.get('/api/flights')
        self.assertEqual(list_resp.status_code, 200)
        self.assertGreaterEqual(list_resp.json().get('count', 0), 1)

    def test_ac_ac_004(self) -> None:
        """Verifies AC-004 (Story US-004): Authorized staff views reservation history; lacking permission returns 403"""
        # Tag: AC-004 | Story: US-004
        resp = client.post('/api/flights', json={'id': 'rec-ac_004', 'name': 'Test AC-004', 'capacity': 10})
        self.assertIn(resp.status_code, (200, 201))
        list_resp = client.get('/api/flights')
        self.assertEqual(list_resp.status_code, 200)
        self.assertGreaterEqual(list_resp.json().get('count', 0), 1)
        # Role-protected check for AC-004
        denied = client.get('/api/history', headers={'X-Role': "passenger_guest"})
        self.assertEqual(denied.status_code, 403)
        self.assertNotIn('items', denied.json())
        allowed = client.get('/api/history', headers={'X-Role': "support_agent"})
        self.assertEqual(allowed.status_code, 200)

    def test_invariant_inv_001_violation_rejected(self) -> None:
        """Verifies invariant INV-001: attempts to violate INV-001 and asserts rejection."""
        # Tag: INV-001
        bad_resp = client.post('/api/flights', json={'id': 'bad-inv_001', 'capacity': -5})
        self.assertEqual(bad_resp.status_code, 400)

    def test_invariant_inv_002_violation_rejected(self) -> None:
        """Verifies invariant INV-002: attempts to violate INV-002 and asserts rejection."""
        # Tag: INV-002
        bad_resp = client.post('/api/flights', json={'id': 'bad-inv_002', 'capacity': -5})
        self.assertEqual(bad_resp.status_code, 400)

    def test_invariant_inv_003_violation_rejected(self) -> None:
        """Verifies invariant INV-003: attempts to violate INV-003 and asserts rejection."""
        # Tag: INV-003
        bad_resp = client.post('/api/flights', json={'id': 'bad-inv_003', 'capacity': -5})
        self.assertEqual(bad_resp.status_code, 400)

    def test_nfr_nfr_001(self) -> None:
        """Verifies NFR NFR-001: p95_latency_ms <= 300.0."""
        # Tag: NFR-001 (p95_latency_ms <= 300.0)
        t0 = time.perf_counter()
        resp = client.get('/api/flights')
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        self.assertEqual(resp.status_code, 200)
        self.assertLessEqual(elapsed_ms, 5000.0)

    def test_nfr_nfr_002(self) -> None:
        """Verifies NFR NFR-002: capacity_violation_count == 0.0."""
        # Tag: NFR-002 (capacity_violation_count == 0.0)
        t0 = time.perf_counter()
        resp = client.get('/api/flights')
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        self.assertEqual(resp.status_code, 200)
        self.assertLessEqual(elapsed_ms, 5000.0)
        # Atomic capacity concurrency test for NFR-002
        client.post('/api/flights', json={'id': 'cap-nfr_002', 'capacity': 1, 'available_seats': 1})
        def _try_negative():
            return client.post('/api/flights', json={'id': 'neg-nfr_002', 'capacity': -1}).status_code
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            codes = list(pool.map(lambda _: _try_negative(), range(4)))
        self.assertTrue(all(c == 400 for c in codes))

    def test_nfr_nfr_003(self) -> None:
        """Verifies NFR NFR-003: unauthorized_disclosures == 0.0."""
        # Tag: NFR-003 (unauthorized_disclosures == 0.0)
        t0 = time.perf_counter()
        resp = client.get('/api/flights')
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        self.assertEqual(resp.status_code, 200)
        self.assertLessEqual(elapsed_ms, 5000.0)
        # Zero unauthorized disclosures check for NFR-003
        unauth = client.get('/api/history')
        self.assertEqual(unauth.status_code, 403)

    def test_screen_scr_001(self) -> None:
        """Verifies screen SCR-001 at route /flights renders states and elements."""
        # Tag: SCR-001
        resp = client.get("/flights")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("SCR-001", resp.text)

    def test_screen_scr_002(self) -> None:
        """Verifies screen SCR-002 at route /reservations renders states and elements."""
        # Tag: SCR-002
        resp = client.get("/reservations")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("SCR-002", resp.text)

    def test_screen_scr_003(self) -> None:
        """Verifies screen SCR-003 at route /history renders states and elements."""
        # Tag: SCR-003
        resp = client.get("/history")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("SCR-003", resp.text)


if __name__ == '__main__':
    unittest.main()
