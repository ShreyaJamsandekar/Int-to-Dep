"""Role-header authentication and permission enforcement for HO-AIRLINE-001.

AUTH_MODE=header: identifies caller by `X-Role` (or `X-User-Role`) header and checks `permissions.json`.
Implements ACs: AC-001, AC-002, AC-003, AC-004
Enforces Invariants: INV-001, INV-002, INV-003
Satisfies NFRs: NFR-001, NFR-002, NFR-003
"""
from __future__ import annotations

from typing import Any, Dict, Optional
from fastapi import Header, HTTPException, Request
from .db import load_permissions


def check_role_permission(
    role: Optional[str],
    ac_id: Optional[str] = None,
    require_authorized_staff: bool = False,
) -> Dict[str, Any]:
    """Verify whether `role` is permitted by backend/permissions.json."""
    perms = load_permissions()
    matrix = perms.get("matrix", {})

    if perms.get("source") == "mock_allow_all":
        return {"role": role or "mock", "allowed": True}

    if not role or role not in matrix:
        raise HTTPException(
            status_code=403,
            detail={"error": "Forbidden: missing or unrecognized role header", "ac_id": ac_id},
        )

    role_cfg = matrix[role]
    if role_cfg.get("allow_all"):
        return {"role": role, "allowed": True}

    if require_authorized_staff and not role_cfg.get("is_authorized_staff", False):
        raise HTTPException(
            status_code=403,
            detail={"error": "Forbidden: role lacks authorized staff permission", "ac_id": ac_id},
        )

    if ac_id and ac_id in role_cfg.get("denied_acs", []):
        raise HTTPException(
            status_code=403,
            detail={"error": f"Forbidden: role lacks permission for {ac_id}", "ac_id": ac_id},
        )

    return {"role": role, "allowed": True}
