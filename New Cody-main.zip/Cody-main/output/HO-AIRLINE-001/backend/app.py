"""Main FastAPI application for HO-AIRLINE-001 (SkyLine Reservation System).

Implements ACs: AC-001, AC-002, AC-003, AC-004
Enforces Invariants: INV-001, INV-002, INV-003
Satisfies NFRs: NFR-001, NFR-002, NFR-003
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response

from .auth import check_role_permission
from .db import DB, load_contracts, load_permissions
from frontend.ui_app import SCREENS, TOKENS_CSS, render_screen_html

app = FastAPI(title="SkyLine Reservation System", version="1.0.0")

TABLES: List[Dict[str, Any]] = [{'name': 'flights', 'entity': 'Flight', 'slug': 'flight', 'columns': [{'name': 'id', 'type': 'str'}, {'name': 'flight_number', 'type': 'str'}, {'name': 'origin', 'type': 'str'}, {'name': 'destination', 'type': 'str'}, {'name': 'departure_time', 'type': 'str'}, {'name': 'capacity', 'type': 'int'}, {'name': 'available_seats', 'type': 'int'}, {'name': 'seats', 'type': 'int'}, {'name': 'role', 'type': 'str'}, {'name': 'customer_id', 'type': 'str'}, {'name': 'reservation_id', 'type': 'str'}]}, {'name': 'customers', 'entity': 'Customer', 'slug': 'customer', 'columns': [{'name': 'id', 'type': 'str'}, {'name': 'name', 'type': 'str'}, {'name': 'email', 'type': 'str'}, {'name': 'phone', 'type': 'str'}, {'name': 'capacity', 'type': 'int'}, {'name': 'available_seats', 'type': 'int'}, {'name': 'seats', 'type': 'int'}, {'name': 'role', 'type': 'str'}, {'name': 'flight_id', 'type': 'str'}, {'name': 'reservation_id', 'type': 'str'}]}, {'name': 'reservations', 'entity': 'Reservation', 'slug': 'reservation', 'columns': [{'name': 'id', 'type': 'str'}, {'name': 'flight_id', 'type': 'str'}, {'name': 'customer_id', 'type': 'str'}, {'name': 'seats', 'type': 'int'}, {'name': 'status', 'type': 'str'}, {'name': 'capacity', 'type': 'int'}, {'name': 'available_seats', 'type': 'int'}, {'name': 'role', 'type': 'str'}]}]
ENDPOINTS: List[Dict[str, Any]] = [{'method': 'GET', 'path': '/api/flights', 'summary': 'List or search flights', 'story_id': None, 'ac_ids': ['AC-001', 'AC-002'], 'task_ids': ['TSK-001', 'TSK-002'], 'entity_slug': 'flight', 'role_protected': False}, {'method': 'POST', 'path': '/api/flights', 'summary': 'Create flight', 'story_id': None, 'ac_ids': ['AC-001', 'AC-002'], 'task_ids': ['TSK-001', 'TSK-002'], 'entity_slug': 'flight', 'role_protected': False}, {'method': 'GET', 'path': '/api/flights/{item_id}', 'summary': 'Get flight by ID', 'story_id': None, 'ac_ids': [], 'task_ids': [], 'entity_slug': 'flight', 'role_protected': False}, {'method': 'GET', 'path': '/api/customers', 'summary': 'List or search customers', 'story_id': None, 'ac_ids': ['AC-003', 'AC-004'], 'task_ids': ['TSK-003', 'TSK-004', 'TSK-005'], 'entity_slug': 'customer', 'role_protected': False}, {'method': 'POST', 'path': '/api/customers', 'summary': 'Create customer', 'story_id': None, 'ac_ids': ['AC-003', 'AC-004'], 'task_ids': ['TSK-003', 'TSK-004', 'TSK-005'], 'entity_slug': 'customer', 'role_protected': False}, {'method': 'GET', 'path': '/api/customers/{item_id}', 'summary': 'Get customer by ID', 'story_id': None, 'ac_ids': [], 'task_ids': [], 'entity_slug': 'customer', 'role_protected': False}, {'method': 'GET', 'path': '/api/reservations', 'summary': 'List or search reservations', 'story_id': None, 'ac_ids': [], 'task_ids': [], 'entity_slug': 'reservation', 'role_protected': False}, {'method': 'POST', 'path': '/api/reservations', 'summary': 'Create reservation', 'story_id': None, 'ac_ids': [], 'task_ids': [], 'entity_slug': 'reservation', 'role_protected': False}, {'method': 'GET', 'path': '/api/reservations/{item_id}', 'summary': 'Get reservation by ID', 'story_id': None, 'ac_ids': [], 'task_ids': [], 'entity_slug': 'reservation', 'role_protected': False}, {'method': 'GET', 'path': '/api/flights/search', 'summary': 'Search flights for Search Flights and Book Reservations', 'story_id': 'US-002', 'ac_ids': ['AC-002'], 'task_ids': ['TSK-002'], 'entity_slug': 'flight', 'role_protected': False}, {'method': 'GET', 'path': '/api/customers/history', 'summary': 'Retrieve View Customer Reservation History', 'story_id': 'US-004', 'ac_ids': ['AC-004'], 'task_ids': ['TSK-004', 'TSK-005'], 'entity_slug': 'customer', 'role_protected': True}, {'method': 'GET', 'path': '/api/history', 'summary': 'History endpoint for View Customer Reservation History', 'story_id': 'US-004', 'ac_ids': ['AC-004'], 'task_ids': ['TSK-004', 'TSK-005'], 'entity_slug': 'customer', 'role_protected': True}]
PROTECTED_AC_IDS: List[str] = ['AC-004']


@app.get("/health")
async def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "handoff_id": "HO-AIRLINE-001",
        "mock_mode": False,
    }


@app.get("/api/contracts")
async def get_contracts() -> Dict[str, Any]:
    return load_contracts()


@app.get("/api/permissions")
async def get_permissions() -> Dict[str, Any]:
    return load_permissions()


@app.get("/api/history")
async def get_global_history(
    request: Request,
    customer_id: Optional[str] = Query(default=None),
    x_role: Optional[str] = Header(default=None, alias="X-Role"),
) -> Dict[str, Any]:
    """Role-protected history endpoint enforcing INV-001, INV-002, INV-003 and AC-004."""
    check_role_permission(
        role=x_role,
        ac_id=PROTECTED_AC_IDS[0] if PROTECTED_AC_IDS else None,
        require_authorized_staff=bool(PROTECTED_AC_IDS),
    )
    target_table = TABLES[0]["name"] if TABLES else "items"
    for t in TABLES:
        if "reservation" in t["name"] or "booking" in t["name"] or "order" in t["name"]:
            target_table = t["name"]
            break
    filters = {"customer_id": customer_id} if customer_id else None
    records = DB.list_records(target_table, filters=filters)
    return {"table": target_table, "items": records, "count": len(records)}


def _register_table_routes(table_cfg: Dict[str, Any]) -> None:
    tname = table_cfg["name"]
    slug = table_cfg["slug"]

    @app.get(f"/api/{tname}/history", name=f"history_{tname}")
    async def _table_history(
        request: Request,
        x_role: Optional[str] = Header(default=None, alias="X-Role"),
    ) -> Dict[str, Any]:
        check_role_permission(
            role=x_role,
            ac_id=PROTECTED_AC_IDS[0] if PROTECTED_AC_IDS else None,
            require_authorized_staff=bool(PROTECTED_AC_IDS),
        )
        q_filters = dict(request.query_params)
        items = DB.list_records(tname, filters=q_filters)
        return {"table": tname, "items": items, "count": len(items)}

    @app.get(f"/api/{tname}/search", name=f"search_{tname}")
    async def _table_search(request: Request) -> Dict[str, Any]:
        q_filters = dict(request.query_params)
        items = DB.list_records(tname, filters=q_filters)
        return {"table": tname, "items": items, "count": len(items)}

    @app.get(f"/api/{tname}", name=f"list_{tname}")
    async def _list_items(request: Request) -> Dict[str, Any]:
        q_filters = dict(request.query_params)
        items = DB.list_records(tname, filters=q_filters)
        return {"table": tname, "items": items, "count": len(items)}

    @app.post(f"/api/{tname}", status_code=201, name=f"create_{tname}")
    async def _create_item(
        payload: Dict[str, Any],
        x_role: Optional[str] = Header(default=None, alias="X-Role"),
    ) -> Dict[str, Any]:
        if payload.get("_require_staff"):
            check_role_permission(role=x_role, require_authorized_staff=True)
        try:
            created = DB.insert_record(tname, payload)
            return created
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))

    @app.get(f"/api/{tname}/{{item_id}}", name=f"get_{slug}")
    async def _get_item(item_id: str) -> Dict[str, Any]:
        rec = DB.get_record(tname, item_id)
        if rec is None:
            raise HTTPException(status_code=404, detail=f"{slug} '{item_id}' not found")
        return rec


for _tbl in TABLES:
    _register_table_routes(_tbl)


# Mount UI routes and design tokens on the main app as well
@app.get("/tokens.css")
async def serve_tokens() -> Response:
    return Response(content=TOKENS_CSS, media_type="text/css")


@app.get("/ui/screens")
async def serve_screens_meta() -> Dict[str, Any]:
    return {"screens": SCREENS}


for _scr in SCREENS:
    _route = _scr.get("route") or "/"

    def _bind_screen(screen_obj: Dict[str, Any]):
        async def _handler(state: str = "loaded") -> HTMLResponse:
            return HTMLResponse(content=render_screen_html(screen_obj, active_state=state))
        return _handler

    app.add_api_route(_route, _bind_screen(_scr), methods=["GET"], response_class=HTMLResponse)
