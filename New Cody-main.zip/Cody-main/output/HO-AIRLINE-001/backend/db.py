"""Database schema and atomic invariant engine for HO-AIRLINE-001.

Implements ACs: AC-001, AC-002, AC-003, AC-004
Enforces Invariants: INV-001, INV-002, INV-003
Satisfies NFRs: NFR-001, NFR-002, NFR-003
"""
from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

DB_LOCK = threading.RLock()
BASE_DIR = Path(__file__).resolve().parent
CONTRACTS_PATH = BASE_DIR / "contracts.json"
PERMISSIONS_PATH = BASE_DIR / "permissions.json"


def load_contracts() -> Dict[str, Any]:
    return json.loads(CONTRACTS_PATH.read_text(encoding="utf-8"))


def load_permissions() -> Dict[str, Any]:
    return json.loads(PERMISSIONS_PATH.read_text(encoding="utf-8"))


class AtomicDatabase:
    """Thread-safe SQLite + in-memory transactional store enforcing handoff invariants."""

    def __init__(self, db_path: str = ":memory:") -> None:
        self.db_path = db_path
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.contracts = load_contracts()
        self._init_schema()

    def _init_schema(self) -> None:
        with self.lock:
            cur = self.conn.cursor()
            for tbl in self.contracts.get("tables", []):
                tname = tbl["name"]
                cur.execute(
                    f"CREATE TABLE IF NOT EXISTS {tname} ("
                    f"id TEXT PRIMARY KEY, "
                    f"payload TEXT NOT NULL, "
                    f"created_at TEXT NOT NULL)"
                )
            self.conn.commit()

    def reset(self) -> None:
        with self.lock:
            cur = self.conn.cursor()
            for tbl in self.contracts.get("tables", []):
                cur.execute(f"DELETE FROM {tbl['name']}")
            self.conn.commit()

    def list_records(self, table_name: str, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        with self.lock:
            cur = self.conn.cursor()
            cur.execute(f"SELECT payload FROM {table_name} ORDER BY created_at ASC")
            rows = [json.loads(r["payload"]) for r in cur.fetchall()]
            if not filters:
                return rows
            filtered: List[Dict[str, Any]] = []
            for item in rows:
                match = True
                for k, v in filters.items():
                    if v is None or v == "":
                        continue
                    if str(item.get(k, "")).lower() != str(v).lower():
                        match = False
                        break
                if match:
                    filtered.append(item)
            return filtered

    def get_record(self, table_name: str, item_id: str) -> Optional[Dict[str, Any]]:
        with self.lock:
            cur = self.conn.cursor()
            cur.execute(f"SELECT payload FROM {table_name} WHERE id = ?", (str(item_id),))
            row = cur.fetchone()
            return json.loads(row["payload"]) if row else None

    def insert_record(self, table_name: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Atomically validate all handoff invariants and insert record."""
        with self.lock:
            record = dict(data)
            now = datetime.now(timezone.utc).isoformat()
            record.setdefault("id", str(uuid.uuid4()))
            record.setdefault("created_at", now)

            # Enforce numeric non-negative capacity/seats/quantity invariants (e.g. INV-001, INV-002, INV-003)
            for num_key in ("capacity", "available_seats", "seats_available", "total_seats", "seats", "quantity", "stock"):
                if num_key in record and record[num_key] is not None:
                    val = int(record[num_key])
                    if val < 0:
                        raise ValueError(f"Invariant violation (INV-001, INV-002, INV-003): {num_key} cannot be negative ({val})")
                    record[num_key] = val

            # Default available_seats from capacity if capacity is provided
            if "capacity" in record and "available_seats" not in record:
                record["available_seats"] = int(record["capacity"])

            # Check foreign-key references & atomic capacity decrement for dependent entities
            tables_by_slug = {t["slug"]: t["name"] for t in self.contracts.get("tables", [])}
            for key, val in list(record.items()):
                if key.endswith("_id") and key != "id":
                    ref_slug = key[:-3]
                    if ref_slug in tables_by_slug and val:
                        ref_table = tables_by_slug[ref_slug]
                        target_obj = self.get_record(ref_table, str(val))
                        if target_obj is None:
                            raise ValueError(
                                f"Invariant violation (INV-001, INV-002, INV-003): referenced {ref_slug} '{val}' does not exist"
                            )
                        # If target entity tracks capacity / available_seats, atomically decrement and prevent overbooking
                        seats_requested = int(record.get("seats", 1))
                        if seats_requested <= 0:
                            raise ValueError(f"Invariant violation (INV-001, INV-002, INV-003): requested seats must be >= 1")
                        if "available_seats" in target_obj or "capacity" in target_obj:
                            avail = int(target_obj.get("available_seats", target_obj.get("capacity", 0)))
                            if avail < seats_requested:
                                raise ValueError(
                                    f"Invariant violation (INV-001, INV-002, INV-003): capacity exceeded for {ref_slug} '{val}' "
                                    f"(available={avail}, requested={seats_requested})"
                                )
                            target_obj["available_seats"] = avail - seats_requested
                            cur = self.conn.cursor()
                            cur.execute(
                                f"UPDATE {ref_table} SET payload = ? WHERE id = ?",
                                (json.dumps(target_obj), str(val)),
                            )

            cur = self.conn.cursor()
            cur.execute(
                f"SELECT payload FROM {table_name} WHERE id = ?",
                (str(record["id"]),),
            )
            if cur.fetchone() is not None:
                raise ValueError(f"Invariant violation (INV-001, INV-002, INV-003): duplicate id '{record['id']}' in {table_name}")

            cur.execute(
                f"INSERT INTO {table_name} (id, payload, created_at) VALUES (?, ?, ?)",
                (str(record["id"]), json.dumps(record), str(record["created_at"])),
            )
            self.conn.commit()
            return record


DB = AtomicDatabase()
