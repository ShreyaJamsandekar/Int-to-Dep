"""Task handler for CHK-003 (TSK-002: Flight search and reservation booking module).

Implements Tasks: TSK-002
Implements Stories: US-002
Implements ACs: AC-002
Enforces Invariants: INV-001, INV-002
Satisfies NFRs: NFR-001, NFR-002
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Header, HTTPException, Query
from ..auth import check_role_permission
from ..db import DB

router = APIRouter()

TASK_METADATA: Dict[str, Any] = {
    "checklist_id": "CHK-003",
    "task_ids": ["TSK-002"],
    "story_ids": ["US-002"],
    "ac_ids": ["AC-002"],
    "invariant_ids": ["INV-001", "INV-002"],
    "nfr_ids": ["NFR-001", "NFR-002"],
    "ac_details": [{'id': 'AC-002', 'story_id': 'US-002', 'title': 'Book reservation with atomic capacity check', 'gherkin': 'Book reservation with atomic capacity check Given an existing flight with available seats and a registered customer When a reservation is requested Then the reservation is created and available_seats is decremented atomically', 'role_protected': False}],
}


def execute_task_operation(
    table_name: str,
    action: str = "list",
    payload: Optional[Dict[str, Any]] = None,
    filters: Optional[Dict[str, Any]] = None,
    role: Optional[str] = None,
    require_staff: bool = False,
    ac_id: Optional[str] = None,
) -> Any:
    """Execute validated domain operation for AC-002 enforcing INV-001, INV-002."""
    if require_staff:
        check_role_permission(role=role, ac_id=ac_id, require_authorized_staff=True)
    if action == "create":
        try:
            return DB.insert_record(table_name, payload or {})
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    if action == "get" and payload and "id" in payload:
        rec = DB.get_record(table_name, str(payload["id"]))
        if rec is None:
            raise HTTPException(status_code=404, detail="Not found")
        return rec
    return DB.list_records(table_name, filters=filters)
