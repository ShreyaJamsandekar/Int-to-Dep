"""Task handler for CHK-005 (TSK-004: Customer reservation history endpoint).

Implements Tasks: TSK-004
Implements Stories: US-004
Implements ACs: AC-004
Enforces Invariants: INV-003
Satisfies NFRs: NFR-003
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Header, HTTPException, Query
from ..auth import check_role_permission
from ..db import DB

router = APIRouter()

TASK_METADATA: Dict[str, Any] = {
    "checklist_id": "CHK-005",
    "task_ids": ["TSK-004"],
    "story_ids": ["US-004"],
    "ac_ids": ["AC-004"],
    "invariant_ids": ["INV-003"],
    "nfr_ids": ["NFR-003"],
    "ac_details": [{'id': 'AC-004', 'story_id': 'US-004', 'title': 'Authorized staff views reservation history; lacking permission returns 403', 'gherkin': 'Authorized staff views reservation history; lacking permission returns 403 Given a caller requesting customer reservation history When the caller lacks permission or is not in authorized staff roles Then the API returns 403 Forbidden with zero protected disclosures', 'role_protected': True}],
}


def execute_task_operation(
    table_name: str,
    action: str = "list",
    payload: Optional[Dict[str, Any]] = None,
    filters: Optional[Dict[str, Any]] = None,
    role: Optional[str] = None,
    require_staff: bool = False,
    ac_id: Optional[str] = None,
) -> Any:
    """Execute validated domain operation for AC-004 enforcing INV-003."""
    if require_staff:
        check_role_permission(role=role, ac_id=ac_id, require_authorized_staff=True)
    if action == "create":
        try:
            return DB.insert_record(table_name, payload or {})
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    if action == "get" and payload and "id" in payload:
        rec = DB.get_record(table_name, str(payload["id"]))
        if rec is None:
            raise HTTPException(status_code=404, detail="Not found")
        return rec
    return DB.list_records(table_name, filters=filters)
