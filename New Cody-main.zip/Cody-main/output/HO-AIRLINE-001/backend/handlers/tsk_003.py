"""Task handler for CHK-004 (TSK-003: Customers service module).

Implements Tasks: TSK-003
Implements Stories: US-003
Implements ACs: AC-003
Enforces Invariants: INV-001, INV-002, INV-003
Satisfies NFRs: NFR-001
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Header, HTTPException, Query
from ..auth import check_role_permission
from ..db import DB

router = APIRouter()

TASK_METADATA: Dict[str, Any] = {
    "checklist_id": "CHK-004",
    "task_ids": ["TSK-003"],
    "story_ids": ["US-003"],
    "ac_ids": ["AC-003"],
    "invariant_ids": ["INV-001", "INV-002", "INV-003"],
    "nfr_ids": ["NFR-001"],
    "ac_details": [{'id': 'AC-003', 'story_id': 'US-003', 'title': 'Register customer profile', 'gherkin': 'Register customer profile Given valid customer name and email When submitted to the customer endpoint Then the customer profile is stored and retrievable', 'role_protected': False}],
}


def execute_task_operation(
    table_name: str,
    action: str = "list",
    payload: Optional[Dict[str, Any]] = None,
    filters: Optional[Dict[str, Any]] = None,
    role: Optional[str] = None,
    require_staff: bool = False,
    ac_id: Optional[str] = None,
) -> Any:
    """Execute validated domain operation for AC-003 enforcing INV-001, INV-002, INV-003."""
    if require_staff:
        check_role_permission(role=role, ac_id=ac_id, require_authorized_staff=True)
    if action == "create":
        try:
            return DB.insert_record(table_name, payload or {})
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    if action == "get" and payload and "id" in payload:
        rec = DB.get_record(table_name, str(payload["id"]))
        if rec is None:
            raise HTTPException(status_code=404, detail="Not found")
        return rec
    return DB.list_records(table_name, filters=filters)
