"""Start every generated component locally without Docker.

Configurable via environment variables:
  API_PORT (default: 8000)
  UI_PORT (default: 8080)
  AUTH_MODE (default: header)
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path
import uvicorn

ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))


def main() -> int:
    parser = argparse.ArgumentParser(description="Run generated application components locally.")
    parser.add_argument("--check", action="store_true", help="Verify imports, health endpoint, and exit 0.")
    parser.add_argument("--api-only", action="store_true", help="Run only backend API server.")
    parser.add_argument("--ui-only", action="store_true", help="Run only frontend UI server.")
    args = parser.parse_args()

    api_port = int(os.getenv("API_PORT", "8000"))
    ui_port = int(os.getenv("UI_PORT", "8080"))

    from backend.app import app as backend_app
    from frontend.ui_app import app as frontend_app

    if args.check:
        from fastapi.testclient import TestClient
        with TestClient(backend_app) as c:
            res = c.get("/health")
            assert res.status_code == 200, f"Health check failed: {res.text}"
        with TestClient(frontend_app) as uc:
            ures = uc.get("/ui/screens")
            assert ures.status_code == 200, f"UI check failed: {ures.text}"
        print(f"OK: HO-AIRLINE-001 components verified (API_PORT={api_port}, UI_PORT={ui_port}).")
        return 0

    if args.api_only:
        uvicorn.run(backend_app, host="0.0.0.0", port=api_port)
        return 0

    if args.ui_only:
        uvicorn.run(frontend_app, host="0.0.0.0", port=ui_port)
        return 0

    # Start both backend and frontend processes
    api_proc = subprocess.Popen([sys.executable, __file__, "--api-only"])
    ui_proc = subprocess.Popen([sys.executable, __file__, "--ui-only"])
    try:
        api_proc.wait()
        ui_proc.wait()
    except KeyboardInterrupt:
        api_proc.terminate()
        ui_proc.terminate()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
