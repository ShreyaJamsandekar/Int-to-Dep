"""Generated frontend package."""
