"""Frontend UI server and screen renderer for HO-AIRLINE-001.

Implements Task: TSK-005
Implements Stories: US-004
Implements ACs: AC-001, AC-002, AC-003, AC-004
Implements Screens: SCR-001, SCR-002, SCR-003
Enforces Invariants: INV-003
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, Response

SCREENS: List[Dict[str, Any]] = [{'id': 'SCR-001', 'name': 'Flight Search & Schedule', 'route': '/flights', 'story_ids': ['US-001', 'US-002'], 'ac_ids': ['AC-001', 'AC-002'], 'states': ['loading', 'empty', 'loaded', 'error'], 'elements': ['flight-search-form', 'flights-table', 'create-flight-btn'], 'roles': []}, {'id': 'SCR-002', 'name': 'Customer & Booking Form', 'route': '/reservations', 'story_ids': ['US-002', 'US-003'], 'ac_ids': ['AC-002', 'AC-003'], 'states': ['loading', 'empty', 'loaded', 'error'], 'elements': ['customer-form', 'reservation-submit-btn'], 'roles': []}, {'id': 'SCR-003', 'name': 'Customer Reservation History', 'route': '/history', 'story_ids': ['US-004'], 'ac_ids': ['AC-004'], 'states': ['loading', 'empty', 'loaded', 'error', 'forbidden'], 'elements': ['history-filter', 'reservation-history-list'], 'roles': []}]
ROLES: List[str] = ['support_agent', 'operations_admin', 'passenger_guest']
TOKENS_CSS = (Path(__file__).resolve().parent / "tokens.css").read_text(encoding="utf-8")


def render_screen_html(screen: Dict[str, Any], active_state: str = "loaded") -> str:
    states_html = "".join(
        f'<span class="state-badge" data-state="{st}">{st}</span> '
        for st in screen.get("states", ["loading", "empty", "loaded", "error"])
    )
    elements_html = "".join(
        f'<div class="ui-element" id="{el}" data-element="{el}">{el}</div>'
        for el in screen.get("elements", [])
    )
    ac_tags = ", ".join(screen.get("ac_ids", []))
    story_tags = ", ".join(screen.get("story_ids", []))
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>{screen['name']} - SkyLine Reservation System</title>
  <link rel="stylesheet" href="/tokens.css" />
</head>
<body data-screen-id="{screen['id']}" data-route="{screen['route']}" data-active-state="{active_state}">
  <header class="card">
    <h1>{screen['name']} ({screen['id']})</h1>
    <p>Route: <code>{screen['route']}</code> | Stories: {story_tags} | ACs: {ac_tags}</p>
    <div class="role-selector" data-roles="{','.join(ROLES)}">Roles: {', '.join(ROLES)}</div>
  </header>
  <main class="card">
    <section class="states" data-states="{','.join(screen.get('states', []))}">
      <h3>UI States</h3>
      {states_html}
    </section>
    <section class="elements">
      <h3>UI Elements</h3>
      {elements_html}
    </section>
  </main>
</body>
</html>"""


def create_ui_app() -> FastAPI:
    ui_app = FastAPI(title="SkyLine Reservation System UI")

    @ui_app.get("/tokens.css")
    async def get_tokens_css() -> Response:
        return Response(content=TOKENS_CSS, media_type="text/css")

    @ui_app.get("/ui/screens")
    async def list_screens() -> Dict[str, Any]:
        return {"screens": SCREENS, "roles": ROLES}

    for scr in SCREENS:
        route_path = scr.get("route") or "/"

        def _make_handler(s: Dict[str, Any]):
            async def _serve(state: str = "loaded") -> HTMLResponse:
                return HTMLResponse(content=render_screen_html(s, active_state=state))
            return _serve

        ui_app.add_api_route(route_path, _make_handler(scr), methods=["GET"], response_class=HTMLResponse)

    if not any((s.get("route") == "/") for s in SCREENS):
        @ui_app.get("/", response_class=HTMLResponse)
        async def index() -> HTMLResponse:
            if SCREENS:
                return HTMLResponse(content=render_screen_html(SCREENS[0]))
            return HTMLResponse(content="<html><body><h1>UI Ready</h1></body></html>")

    return ui_app


app = create_ui_app()
