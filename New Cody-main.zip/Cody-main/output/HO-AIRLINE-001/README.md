# SkyLine Reservation System (`HO-AIRLINE-001`)

Generated from handoff `HO-AIRLINE-001` (version `1.0.0`).

## How to Run

### Run Locally (without Docker)
```bash
export API_PORT=8000
export UI_PORT=8080
python run_local.py
```

Verify component health and startup:
```bash
python run_local.py --check
```

### Run Tests
```bash
pytest -q
# or
python -m unittest discover -s tests
```

### Run with Docker Compose
```bash
docker compose up --build
```

## Authentication & Permissions
- **Auth Mode:** `AUTH_MODE=header` (`X-Role` request header)
- **Permissions File:** `backend/permissions.json` (source: `inferred_from_handoff`)
- **Roles:** `support_agent, operations_admin, passenger_guest`

## Acceptance Criteria to File Map

| AC ID | Story ID | Title | Implementing Files | Verification Test |
|---|---|---|---|---|
| `AC-001` | `US-001` | Create and list flight schedule | `backend/handlers/tsk_001.py`, `backend/app.py` | `tests/test_acceptance.py` |
| `AC-002` | `US-002` | Book reservation with atomic capacity check | `backend/handlers/tsk_002.py`, `backend/app.py` | `tests/test_acceptance.py` |
| `AC-003` | `US-003` | Register customer profile | `backend/handlers/tsk_003.py`, `backend/app.py` | `tests/test_acceptance.py` |
| `AC-004` | `US-004` | Authorized staff views reservation history; lacking permission returns 403 | `backend/handlers/tsk_004.py`, `backend/handlers/tsk_005.py`, `backend/app.py` | `tests/test_acceptance.py` |
