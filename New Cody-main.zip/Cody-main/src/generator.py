from crewai import Crew, Agent, Task, Process
from crewai.llm import LLM
from pydantic import BaseModel, Field
import time
import os
from dotenv import load_dotenv

load_dotenv()


class Code(BaseModel):
    code: str = Field(..., description="The generated code as a string")
    
    class Config:
        from_attributes = True


async def developer(language: str, requirement: str, llm):
    """
    Creates a multi-agent workflow to develop, test, and review code.
    
    Args:
        language: Programming language to use
        requirement: Description of what to build
        llm: Dictionary with LLM configuration (model, api_key, base_url)
    
    Returns:
        str: Final reviewed and optimized code
    """
    
    LLM_IN = LLM(**llm)
    
    # Agent definitions with clearer, more focused goals
    coding_agent = Agent(
        role=f"Senior {language} Developer",
        goal=f"""Write clean, efficient {language} code that exactly meets the requirement.
                Focus on:
                - Correct implementation of the requirement
                - Clean, readable code structure
                - Appropriate comments for complex logic
                - Following {language} best practices and idioms""",
        backstory=f"""You are a senior {language} developer with 10+ years of experience.
                You specialize in writing production-ready code that is both efficient and maintainable.
                You understand {language} idioms and best practices deeply.""",
        llm=LLM_IN,
        verbose=True
    )
    
    testing_agent = Agent(
        role=f"QA Engineer specializing in {language}",
        goal=f"""Verify the code works correctly by:
                - Testing all edge cases
                - Checking for bugs and logical errors
                - Validating performance and efficiency
                - Ensuring the code meets the exact requirement""",
        backstory=f"""You are an expert QA engineer with deep knowledge of {language}.
                You excel at finding edge cases and potential issues in code.
                You provide clear, actionable feedback to improve code quality.""",
        llm=LLM_IN,
        verbose=True
    )
    
    review_agent = Agent(
        role=f"Code Review Expert for {language}",
        goal=f"""Produce the final, production-ready code by:
                - Incorporating test feedback and fixing any issues
                - Removing test cases from the output
                - Ensuring code follows best practices
                - Providing ONLY the clean, executable code with necessary comments
                - Making sure the code is optimized and ready to use""",
        backstory=f"""You are a principal engineer who specializes in code review and optimization.
                You have reviewed thousands of {language} projects and know what production-ready code looks like.
                You deliver clean, polished code without any test artifacts.""",
        llm=LLM_IN,
        verbose=True
    )

    # Task definitions with clearer expected outputs
    coding_task = Task(
        description=f"""Write {language} code for this requirement: {requirement}
        
        Requirements:
        - Implement the exact functionality requested
        - Use clear variable names and structure
        - Add comments only where necessary for clarity
        - Follow {language} conventions and best practices
        - Make the code efficient and readable""",
        expected_output=f"""Complete, working {language} code that implements the requirement.
                The code should be clean, well-structured, and include necessary comments.""",
        agent=coding_agent
    )
    
    testing_task = Task(
        description=f"""Analyze the code from the previous step and:
        
        1. Test the logic for correctness
        2. Identify any bugs or edge cases not handled
        3. Check for performance issues
        4. Verify it meets the exact requirement
        5. Provide specific feedback on what needs to be fixed (if anything)""",
        expected_output=f"""A detailed test report including:
                - Confirmation the code works correctly OR specific issues found
                - Edge cases tested
                - Any bugs or improvements needed
                - Performance assessment""",
        agent=testing_agent,
        context=[coding_task]
    )
    
    review_task = Task(
        description=f"""Based on the code and test feedback, produce the final version:
        
        CRITICAL INSTRUCTIONS:
        - Fix any issues identified in testing
        - Output ONLY the final {language} code
        - Remove ALL test cases, test descriptions, and testing artifacts
        - Keep only necessary comments in the code
        - Ensure the code is clean and production-ready
        - Format the code properly
        
        Your output should be ONLY executable {language} code, nothing else.""",
        expected_output=f"""ONLY the final, clean {language} code in a markdown code block.
                No test cases, no explanations, no test reports - just the production-ready code.""",
        agent=review_agent,
        context=[coding_task, testing_task]
    )
    
    # Create crew with optimized settings
    crew = Crew(
        tasks=[coding_task, testing_task, review_task],
        agents=[coding_agent, testing_agent, review_agent],
        process=Process.sequential,
        verbose=True,
        memory=False,  # Disable memory for faster execution if not needed
        cache=True  # Enable caching for efficiency
    )
    
    # Execute the workflow
    result = await crew.kickoff_async(inputs={
        'language': language,
        'requirement': requirement
    })
    
    # Extract just the code from the result
    output = result.raw
    
    # Clean up the output if needed (remove extra markdown formatting)
    if isinstance(output, str):
        # Remove excessive newlines
        output = '\n'.join(line for line in output.split('\n') if line.strip() or line == '')
    
    return output


async def main_async():
    """Test the developer function"""
    language = 'Python'
    requirement = 'Create a function that takes a list of integers and returns the sum of all even numbers in the list.'
    
    # Configuration options
    # Option 1: Local Ollama
    # llm = { 
    #     "model": "ollama/qwen3:4b",
    #     "api_key": "ollama",
    #     "base_url": "http://localhost:11434"
    # }
    
    # Option 2: OpenRouter
    llm = { 
        "model": "openrouter/google/gemini-2.0-flash-exp:free",  # Updated to a more capable free model
        "api_key": os.getenv("OPENROUTER_API_KEY"),
        "base_url": "https://openrouter.ai/api/v1"
    }
    
    if not llm['api_key']:
        print("Error: API key not found in environment variables")
        return
    
    print(f"Using model: {llm['model']}")
    print(f"Generating code for: {requirement}\n")
    print("-" * 80)
    
    start = time.time()
    output = await developer(language, requirement, llm)
    end = time.time()
    
    print("-" * 80)
    print(f"\n⏱️  Time taken: {end - start:.2f} seconds")
    print("\n📝 Final Output:")
    print("-" * 80)
    print(output)
    print("-" * 80)


if __name__ == '__main__':
    import asyncio
    asyncio.run(main_async())