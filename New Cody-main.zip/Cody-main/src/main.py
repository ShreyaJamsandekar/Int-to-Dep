from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel , Field
from dotenv import load_dotenv
load_dotenv()
import time
import uvicorn
import os 
import re
from typing import Any, Dict

try:
    from scalar_fastapi import get_scalar_api_reference
except ImportError:  # graceful fallback if scalar_fastapi is not installed in test env
    def get_scalar_api_reference(**kwargs):
        return kwargs

try:
    from generator import developer
except ImportError:
    async def developer(language: str, requirement: str, llm: dict) -> str:
        raise RuntimeError("crewai generator dependency not installed in current environment")

from pipeline.run import run_pipeline, get_run_summary

app = FastAPI(title="AI Developer API", description="API to generate code based on requirements using AI agents", version="1.0.0")

app.add_middleware(
    CORSMiddleware, 
    allow_origins=["*"], 
    allow_credentials=True, 
    allow_methods=["*"], 
    allow_headers=["*"]
    )


# LLM = { 
#     "model":"ollama/gemma3:4b",
#     "api_key": "ollama",
#     "base_url":"http://localhost:11434"
#     }

LLM = { 
    "model":"openrouter/google/gemma-3-27b-it:free",
    "api_key": os.getenv("OPENROUTER_API_KEY"),
    "base_url":"https://openrouter.ai/api/v1"
    }


class QueryRequest(BaseModel):
    language : str = Field(...,description="Programming Language to be used")
    requirement : str = Field(...,description="Requirement for the code to be developed")
    
class QueryResponse(BaseModel):
    code : str = Field(...,description="Generated Code")
    timetaken : str = Field(...,description="Time taken to generate the code in seconds")
    
@app.get("/", tags=["Health Check"])
async def health_check():
    return {"status": "API is running"}

@app.get("/scalar" , tags=["Scalar API Reference"])
async def scalar_api_reference():
    return get_scalar_api_reference(
        title="Scalar API Reference",
        # description="API reference for Scalar library used in the project",
        # version="1.0.0",
        openapi_url=app.openapi_url,
    )
    
@app.post("/generate_code", response_model=QueryResponse)
async def generate_code(request:QueryRequest):
    start = time.time()
    code = await developer(request.language,request.requirement,LLM)
    code = re.sub("```[a-zA-Z]*","",code)  # Remove ```language
    code = re.sub("```","",code)  # Remove ```
    end = time.time()
    total = f"{end - start} seconds"
    return QueryResponse(code=code,timetaken=total)


@app.post("/generate_from_handoff", tags=["Handoff Pipeline"])
async def generate_from_handoff(handoff: Dict[str, Any] = Body(...)):
    result = await run_pipeline(handoff_input=handoff)
    return {
        "run_id": result["run_id"],
        "output_dir": result["output_dir"],
        "logs_dir": result["logs_dir"],
        "status": result["status"],
        "checklist_mode": result["checklist_mode"],
        "passed/total": result["passed_total"],
        "passed": result["passed"],
        "total": result["total"],
        "checklist": result.get("checklist", {}),
        "review": result.get("review", {}),
    }


@app.get("/runs/{run_id}", tags=["Handoff Pipeline"])
async def get_run(run_id: str):
    try:
        return get_run_summary(run_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


if __name__ == "__main__":
    uvicorn.run(app=app)