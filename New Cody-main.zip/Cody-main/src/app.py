import streamlit as st
import requests
import json
import time
from typing import Dict, Any
import os

url = os.getenv("URL") or "http://localhost:7777"
# Configure page settings
st.set_page_config(
    page_title="Cody - AI Code Generator",
    layout="wide",
    initial_sidebar_state="expanded"
)

# API Configuration
API_ENDPOINT = f"{url}/generate_code"
HANDOFF_ENDPOINT = f"{url}/generate_from_handoff"
RUNS_ENDPOINT = f"{url}/runs"


def generate_code(params: Dict[str, str]) -> tuple:
    """Make API call to FastAPI backend"""
    try:
        response = requests.post(API_ENDPOINT, json=params)
        response.raise_for_status()  # Raise exception for bad status codes
        result = response.json()
        return result["code"], result["timetaken"]
    except requests.exceptions.RequestException as e:
        st.error(f"API Error: {str(e)}")
        return None, None


def generate_from_handoff_api(handoff_payload: Dict[str, Any]) -> Dict[str, Any] | None:
    """Make API call to POST /generate_from_handoff on FastAPI backend"""
    try:
        response = requests.post(HANDOFF_ENDPOINT, json=handoff_payload, timeout=180)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"Handoff API Error: {str(e)}")
        return None


def render_code_generator_tab():
    # Create two columns
    chat_col, code_col = st.columns(2)
    
    # Chat Column
    with chat_col:
        st.subheader("Chat & Input")
        
        # Input fields
        language = st.selectbox(
            "Select Programming Language",
            ["Python", "JavaScript", "Java", "C++", "Go"]
        )
        extenstions = {
            "Python":'py', 
            "JavaScript":'js',
            "Java":'java', 
            "C++":"cpp", 
            "Go":"go"
        }
        requirement = st.text_area(
            "Enter your requirement",
            height=150,
            placeholder="Describe what you want to generate..."
        )
        
        if st.button("Generate Code"):
            if requirement:
                with st.spinner("Generating code..."):
                    # Create parameters
                    params = {
                        "language": language,
                        "requirement": requirement
                    }
                    
                    # Store parameters in session state
                    st.session_state['params'] = params
                    
                    # Call FastAPI endpoint
                    code, generation_time = generate_code(params)
                    if code:
                        st.session_state['generated_code'] = code
                        st.success(f"Code generated successfully in {generation_time}!")
                        # Add to chat history
                        st.session_state.chat_history.append(f"Generated {language} code in {generation_time}")
            else:
                st.error("Please enter a requirement")
        
        # Chat History
        st.subheader("Chat History")
        if 'chat_history' not in st.session_state:
            st.session_state.chat_history = []
            
        for msg in st.session_state.chat_history:
            st.text(msg)
    
    # Code Column
    with code_col:
        st.subheader("Generated Code")
        
        if 'generated_code' in st.session_state:
            # Code editor with syntax highlighting
            st.code(st.session_state['generated_code'], language=st.session_state['params']['language'].lower())
            
            # Download button for the generated code
            if st.download_button(
                label="Download Code",
                data=st.session_state['generated_code'],
                file_name=f"generated_code.{extenstions[st.session_state['params']['language']]}",
                mime="text/plain"
            ):
                st.success("Code downloaded successfully!")
        else:
            st.info("Generated code will appear here")
        
        # Additional options
        if st.session_state.get('generated_code'):
            if st.button("Clear Code"):
                del st.session_state['generated_code']
                st.rerun()


def render_handoff_json_tab():
    st.subheader("Handoff JSON → Traceable Code Generation")
    uploaded_file = st.file_uploader("Upload handoff.json", type=["json"])

    if uploaded_file is not None:
        try:
            handoff_data = json.loads(uploaded_file.getvalue().decode("utf-8"))
        except Exception as exc:
            st.error(f"Invalid JSON file: {exc}")
            return

        if st.button("Run Handoff Pipeline"):
            with st.spinner("Running traceable code generation pipeline..."):
                res = generate_from_handoff_api(handoff_data)
                if res:
                    st.session_state["handoff_result"] = res
                    # Fetch full run summary if available
                    try:
                        run_resp = requests.get(f"{RUNS_ENDPOINT}/{res['run_id']}", timeout=30)
                        if run_resp.ok:
                            st.session_state["handoff_run_detail"] = run_resp.json()
                    except Exception:
                        pass

    if "handoff_result" in st.session_state:
        res = st.session_state["handoff_result"]
        detail = st.session_state.get("handoff_run_detail", res)

        st.success(f"Run `{res.get('run_id')}` finished with status: **{res.get('status')}**")
        col1, col2, col3 = st.columns(3)
        col1.metric("Checklist Workflow Mode", res.get("checklist_mode", "mixed"))
        col2.metric("Review Checks Passed", res.get("passed/total", f"{res.get('passed', 0)}/{res.get('total', 0)}"))
        col3.write(f"**Output Path:** `{res.get('output_dir')}`\n\n**Logs Path:** `{res.get('logs_dir')}`")

        checklist_items = detail.get("checklist", {}).get("items", [])
        if checklist_items:
            st.markdown("### Checklist (Serial / Parallel Layers)")
            table_rows = [
                {
                    "ID": item.get("id"),
                    "Layer": f"L{item.get('layer')}",
                    "Mode": item.get("mode"),
                    "Title": item.get("title"),
                    "Status": item.get("status"),
                    "Depends On": ", ".join(item.get("depends_on", [])),
                }
                for item in checklist_items
            ]
            st.table(table_rows)

        review_checks = detail.get("review", {}).get("checks", [])
        if review_checks:
            st.markdown("### Review Results")
            rev_rows = [
                {
                    "Check ID": chk.get("id"),
                    "Category": chk.get("category"),
                    "Status": chk.get("status"),
                    "Evidence": chk.get("evidence"),
                }
                for chk in review_checks
            ]
            st.table(rev_rows)

        if detail.get("summary_markdown"):
            with st.expander("Full Traceability Summary (summary.md)"):
                st.markdown(detail["summary_markdown"])


def main():
    st.title("Cody - Your Code Buddy")
    tab_existing, tab_handoff = st.tabs(["Code Generator", "Handoff JSON"])
    with tab_existing:
        render_code_generator_tab()
    with tab_handoff:
        render_handoff_json_tab()


if __name__ == "__main__":
    main()