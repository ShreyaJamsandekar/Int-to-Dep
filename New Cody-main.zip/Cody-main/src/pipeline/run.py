"""Stage Orchestrator (S0 -> S8) for Handoff JSON -> Traceable Code Generation.

Stages:
  S0: Validate (Pydantic parse + cross-reference checks; fail fast on errors) -> trace.jsonl
  S1: Intent (one intent record per story) -> intent.jsonl
  S2: Extraction (entities, invariants, NFRs, components, screens, build plan, permissions + extraction gate) -> extraction.jsonl
  S3: Checklist (topological layers tagged serial / parallel) -> checklist.json, trace.jsonl
  S4: Generate (executes checklist; parallel layers run with asyncio.gather capped by MAX_PARALLEL) -> trace.jsonl
  S5: Intent-match gate (checks output against intent; retries failing items) -> intent_match.jsonl
  S6: Graphify (code graph merged into TraceGraph) -> graph.json, graph.mmd
  S7: Review (runs review checklist + tests; targeted fix loop) -> review.jsonl
  S8: Summary (pass/fail per checklist item, AC coverage, unresolved items, paths) -> summary.md
"""
from __future__ import annotations

import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from .executor import execute_all_layers
from .extraction import run_extraction
from .graphify_adapter import run_graphify_stage
from .intent import build_intents
from .intent_gate import run_full_output_gate, verify_item_and_retry
from .llm import LLMClient
from .models import HandoffSpec, ValidationResult, parse_handoff, validate_handoff
from .planner import build_checklist
from .reviewer import run_review_loop
from .tracing import TraceGraph, TraceLogger


def _resolve_project_root() -> Path:
    return Path(__file__).resolve().parent.parent.parent


def _write_summary_md(
    run_id: str,
    spec: HandoffSpec,
    validation: ValidationResult,
    checklist_doc: Dict[str, Any],
    gate_summary: Dict[str, Any],
    review_summary: Dict[str, Any],
    output_dir: Path,
    logs_dir: Path,
    is_mock: bool,
) -> str:
    """Write Stage S8 `summary.md` with pass/fail per checklist item, AC coverage, unresolved items, and paths."""
    lines: List[str] = [
        f"# Traceability Run Summary — `{run_id}`",
        "",
        f"- **Handoff ID:** `{spec.handoff_id}` (version `{spec.handoff_version}`)",
        f"- **Project Name:** {spec.project_name}",
        f"- **Workflow Mode:** `{checklist_doc.get('workflow_mode', 'mixed')}` — {checklist_doc.get('workflow_reason', '')}",
        f"- **Output Directory:** `{output_dir}`",
        f"- **Logs Directory:** `{logs_dir}`",
        f"- **Review Score:** `{review_summary['passed']}/{review_summary['total']}` checks passed",
    ]

    if is_mock:
        lines.extend([
            "",
            "> **IMPORTANT MOCK MODE NOTICE (`LLM_MODEL=mock`):**",
            "> This dry run generated TODO-marked stubs and logged review test execution as `skipped (mock)`. "
            "**This is not production code** — it is used to verify pipeline traceability without an LLM API key.",
        ])

    # Validation warnings / assumptions
    if validation.warnings:
        lines.extend(["", "## Validation Warnings & Recorded Assumptions (S0)"])
        for w in validation.warnings:
            lines.append(f"- **`{w.code}`**: {w.message}")

    # Checklist table
    lines.extend([
        "",
        "## Checklist Execution (S3–S5)",
        "",
        "| Checklist ID | Layer | Mode | Title | Status | Linked Tasks / ACs |",
        "|---|---|---|---|---|---|",
    ])
    for item in checklist_doc.get("items", []):
        linked = item.get("linked", {})
        t_str = ", ".join(linked.get("task", [])) or "—"
        a_str = ", ".join(linked.get("ac", [])) or "—"
        lines.append(
            f"| `{item['id']}` | L{item['layer']} | `{item['mode']}` | {item['title']} | **{item['status']}** | Tasks: {t_str}<br>ACs: {a_str} |"
        )

    # AC coverage table
    lines.extend([
        "",
        "## Acceptance Criteria Coverage (S5)",
        "",
        "| AC ID | Story ID | Covered | Implementing Files | Verification Tests |",
        "|---|---|---|---|---|",
    ])
    for aid, cov in gate_summary.get("ac_coverage", {}).items():
        impls = ", ".join(f"`{f}`" for f in cov.get("implementing_files", [])) or "None"
        tests = ", ".join(f"`{f}`" for f in cov.get("test_files", [])) or "None"
        status_icon = "PASS" if cov.get("covered") else "UNMATCHED"
        lines.append(f"| `{aid}` | `{cov.get('story_id')}` | **{status_icon}** | {impls} | {tests} |")

    # Review checklist results
    lines.extend([
        "",
        f"## Review Checklist Results (S7) — {review_summary['passed']}/{review_summary['total']} Passed",
        "",
        "| Check ID | Category | Status | Evidence |",
        "|---|---|---|---|",
    ])
    for r in review_summary.get("checks", []):
        ev = str(r.get("evidence", "")).replace("\n", " ")
        lines.append(f"| `{r['id']}` | `{r['category']}` | **{r['status']}** | {ev} |")

    # Unresolved / unmatched items
    unmatched_chks = gate_summary.get("unmatched_checklist_items", [])
    failures_left = review_summary.get("failures_left", [])
    lines.extend(["", "## Unresolved Items"])
    if not unmatched_chks and not failures_left:
        lines.append("- None. All checklist items and blocking review checks resolved.")
    else:
        for ucid in unmatched_chks:
            item_obj = next((i for i in checklist_doc.get("items", []) if i["id"] == ucid), {})
            lines.append(
                f"- **Unmatched Checklist Item `{ucid}`**: {item_obj.get('unmatched_reason', 'Failed intent gate after max retries')} "
                f"(Missing: {item_obj.get('unmatched_missing', [])})"
            )
        for fl in failures_left:
            lines.append(f"- **Failed Review Check `{fl['id']}`**: {fl['title']} — {fl['evidence']}")

    summary_text = "\n".join(lines) + "\n"
    (logs_dir / "summary.md").write_text(summary_text, encoding="utf-8")
    return summary_text


async def run_pipeline(
    handoff_input: Union[str, Path, Dict[str, Any]],
    base_dir: Optional[Path] = None,
    run_id: Optional[str] = None,
    llm_client: Optional[LLMClient] = None,
    scripted_responder: Optional[Callable[[str, Dict[str, Any]], Any]] = None,
) -> Dict[str, Any]:
    """Execute the complete S0 -> S8 handoff-to-code pipeline."""
    root_dir = Path(base_dir) if base_dir else _resolve_project_root()
    handoff_path: Optional[Path] = None

    if isinstance(handoff_input, (str, Path)):
        handoff_path = Path(handoff_input).resolve()
        raw_data = json.loads(handoff_path.read_text(encoding="utf-8"))
    elif isinstance(handoff_input, dict):
        raw_data = handoff_input
    else:
        raise ValueError("handoff_input must be a path or a dict")

    ts_slug = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = run_id or f"run_{ts_slug}_{uuid.uuid4().hex[:6]}"
    logs_dir = root_dir / "logs" / run_id
    logs_dir.mkdir(parents=True, exist_ok=True)

    tracer = TraceLogger(run_id=run_id, logs_dir=logs_dir)
    graph = TraceGraph()
    llm = llm_client or LLMClient(scripted_responder=scripted_responder)

    # -------------------------------------------------------------------------
    # Stage S0: Validate
    # -------------------------------------------------------------------------
    tracer.log(stage="S0", event="validation_started", level="info", ids={}, mode="serial", attempt=1)
    try:
        spec = parse_handoff(raw_data)
    except Exception as exc:
        tracer.log(
            stage="S0",
            event="validation_failed",
            level="error",
            ids={},
            mode="serial",
            attempt=1,
            data={"error": str(exc)},
        )
        summary_md = f"# Run `{run_id}` Failed at S0 Validation\n\n- **Error:** {exc}\n"
        (logs_dir / "summary.md").write_text(summary_md, encoding="utf-8")
        return {
            "run_id": run_id,
            "handoff_id": "invalid",
            "output_dir": "",
            "logs_dir": str(logs_dir),
            "status": "validation_failed",
            "checklist_mode": "serial",
            "passed": 0,
            "total": 0,
            "passed_total": "0/0",
            "errors": [{"code": "SCHEMA_PARSE_ERROR", "message": str(exc)}],
            "warnings": [],
        }

    validation = validate_handoff(spec)
    for w in validation.warnings:
        tracer.log(
            stage="S0",
            event="validation_warning_assumption",
            level="warning",
            ids=w.ids,
            mode="serial",
            attempt=1,
            data={"code": w.code, "message": w.message},
        )

    if not validation.valid:
        for err in validation.errors:
            tracer.log(
                stage="S0",
                event="validation_error",
                level="error",
                ids=err.ids,
                mode="serial",
                attempt=1,
                data={"code": err.code, "message": err.message},
            )
        summary_md = (
            f"# Run `{run_id}` Failed at S0 Validation (`{spec.handoff_id}`)\n\n"
            + "\n".join(f"- **`{e.code}`**: {e.message}" for e in validation.errors)
            + "\n"
        )
        (logs_dir / "summary.md").write_text(summary_md, encoding="utf-8")
        return {
            "run_id": run_id,
            "handoff_id": spec.handoff_id,
            "output_dir": "",
            "logs_dir": str(logs_dir),
            "status": "validation_failed",
            "checklist_mode": "serial",
            "passed": 0,
            "total": 0,
            "passed_total": "0/0",
            "errors": [e.dict() for e in validation.errors],
            "warnings": [w.dict() for w in validation.warnings],
        }

    tracer.log(
        stage="S0",
        event="validation_passed",
        level="info",
        ids={"handoff": spec.handoff_id},
        mode="serial",
        attempt=1,
        data={
            "handoff_id": spec.handoff_id,
            "handoff_version": spec.handoff_version,
            "warnings_count": len(validation.warnings),
        },
    )

    # Clear output/<handoff_id>/ at the start of each valid run (§10)
    output_dir = root_dir / "output" / spec.handoff_id
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # -------------------------------------------------------------------------
    # Stage S1: Intent
    # -------------------------------------------------------------------------
    intents = build_intents(spec, tracer=tracer, graph=graph)

    # -------------------------------------------------------------------------
    # Stage S2: Extraction (+ Extraction Intent Gate)
    # -------------------------------------------------------------------------
    extraction = await run_extraction(
        spec,
        llm=llm,
        tracer=tracer,
        graph=graph,
        handoff_path=handoff_path,
    )

    # -------------------------------------------------------------------------
    # Stage S3: Checklist (Topological Layers: Serial vs Parallel)
    # -------------------------------------------------------------------------
    checklist_doc = build_checklist(
        spec,
        extraction=extraction,
        tracer=tracer,
        graph=graph,
        logs_dir=logs_dir,
    )

    # -------------------------------------------------------------------------
    # Stage S4 + S5: Execute Checklist & Per-Item Intent-Match Gate with Retries
    # -------------------------------------------------------------------------
    async def _gate_item(chk_item: Dict[str, Any]) -> None:
        await verify_item_and_retry(
            chk_item,
            spec=spec,
            extraction=extraction,
            checklist_doc=checklist_doc,
            output_dir=output_dir,
            llm=llm,
            tracer=tracer,
            graph=graph,
        )

    await execute_all_layers(
        checklist_doc=checklist_doc,
        spec=spec,
        extraction=extraction,
        output_dir=output_dir,
        llm=llm,
        tracer=tracer,
        graph=graph,
        item_gate_fn=_gate_item,
    )

    # Update persisted checklist.json with final item statuses
    (logs_dir / "checklist.json").write_text(
        json.dumps(checklist_doc, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    # Full output gate before S7
    gate_summary = await run_full_output_gate(
        spec=spec,
        extraction=extraction,
        checklist_doc=checklist_doc,
        output_dir=output_dir,
        llm=llm,
        tracer=tracer,
        graph=graph,
    )

    # -------------------------------------------------------------------------
    # Stage S6: Graphify + TraceGraph
    # -------------------------------------------------------------------------
    graph_summary = run_graphify_stage(
        output_dir=output_dir,
        checklist_doc=checklist_doc,
        tracer=tracer,
        graph=graph,
        logs_dir=logs_dir,
    )

    # -------------------------------------------------------------------------
    # Stage S7: Review Checklist + Targeted Fix Loop
    # -------------------------------------------------------------------------
    review_summary = await run_review_loop(
        spec=spec,
        extraction=extraction,
        checklist_doc=checklist_doc,
        output_dir=output_dir,
        llm=llm,
        tracer=tracer,
        graph=graph,
    )

    # Save updated TraceGraph with review check links
    graph.save(logs_dir)

    # -------------------------------------------------------------------------
    # Stage S8: Summary
    # -------------------------------------------------------------------------
    summary_md = _write_summary_md(
        run_id=run_id,
        spec=spec,
        validation=validation,
        checklist_doc=checklist_doc,
        gate_summary=gate_summary,
        review_summary=review_summary,
        output_dir=output_dir,
        logs_dir=logs_dir,
        is_mock=llm.is_mock,
    )

    unmatched_items = gate_summary.get("unmatched_checklist_items", [])
    failures_left = review_summary.get("failures_left", [])
    overall_status = "completed" if (not unmatched_items and not failures_left) else "completed_with_warnings"

    result_payload = {
        "run_id": run_id,
        "handoff_id": spec.handoff_id,
        "output_dir": str(output_dir),
        "logs_dir": str(logs_dir),
        "status": overall_status,
        "checklist_mode": checklist_doc.get("workflow_mode", "mixed"),
        "passed": review_summary["passed"],
        "total": review_summary["total"],
        "passed_total": f"{review_summary['passed']}/{review_summary['total']}",
        "mock_mode": llm.is_mock,
        "checklist": checklist_doc,
        "review": review_summary,
        "graph": graph_summary,
        "intents_count": len(intents),
        "warnings": [w.dict() for w in validation.warnings],
        "summary_markdown": summary_md,
    }

    (logs_dir / "run_result.json").write_text(
        json.dumps(result_payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    tracer.log(
        stage="S8",
        event="pipeline_completed",
        level="info",
        ids={"handoff": spec.handoff_id},
        mode=checklist_doc.get("workflow_mode", "mixed"),
        attempt=1,
        data={
            "status": overall_status,
            "output_dir": str(output_dir),
            "logs_dir": str(logs_dir),
            "passed_total": f"{review_summary['passed']}/{review_summary['total']}",
        },
    )

    return result_payload


def get_run_summary(run_id: str, base_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Retrieve stored run summary and checklist/review metadata for `GET /runs/{run_id}`."""
    root_dir = Path(base_dir) if base_dir else _resolve_project_root()
    logs_dir = root_dir / "logs" / run_id
    if not logs_dir.exists():
        raise FileNotFoundError(f"Run '{run_id}' not found in {logs_dir}")

    result_file = logs_dir / "run_result.json"
    if result_file.exists():
        return json.loads(result_file.read_text(encoding="utf-8"))

    summary_file = logs_dir / "summary.md"
    checklist_file = logs_dir / "checklist.json"
    return {
        "run_id": run_id,
        "logs_dir": str(logs_dir),
        "summary_markdown": summary_file.read_text(encoding="utf-8") if summary_file.exists() else "",
        "checklist": json.loads(checklist_file.read_text(encoding="utf-8")) if checklist_file.exists() else {},
    }
