"""Stage S2: Domain & Architecture Extraction + Extraction Intent-Match Gate.

Extracts:
  - Entities (from glossary + story/invariant inference)
  - Invariants
  - NFRs
  - Components
  - Screens/routes
  - Build plan (database tables, REST endpoints, UI states)
  - Role permissions (inferred from ACs, invariants, screens, roles or loaded from override)

Includes the Extraction Gate (§7): verifies every story, AC, task, component,
screen, NFR, and invariant ID in the handoff appears in the extraction.
Misses trigger re-extraction with missing IDs as feedback up to INTENT_MAX_RETRIES.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from .llm import LLMClient
from .models import AcceptanceCriterionModel, HandoffSpec
from .tracing import TraceGraph, TraceLogger


def _slugify(name: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "_", name.strip().lower()).strip("_")
    return s or "entity"


def _pluralize(slug: str) -> str:
    if slug.endswith("s"):
        return slug
    if slug.endswith("y") and len(slug) > 1 and slug[-2] not in "aeiou":
        return slug[:-1] + "ies"
    return slug + "s"


def _infer_fields_for_entity(term: str, definition: str, raw_attrs: List[Any], invariants_text: str) -> List[Dict[str, str]]:
    fields: List[Dict[str, str]] = [{"name": "id", "type": "str"}]
    seen = {"id"}

    for attr in raw_attrs:
        if isinstance(attr, str):
            fname = _slugify(attr)
            ftype = "int" if any(k in fname for k in ("count", "capacity", "seats", "qty", "quantity", "stock", "age")) else "str"
        elif isinstance(attr, dict):
            fname = _slugify(str(attr.get("name") or attr.get("field") or "attr"))
            ftype = str(attr.get("type") or "str")
        else:
            continue
        if fname and fname not in seen:
            fields.append({"name": fname, "type": ftype})
            seen.add(fname)

    combined = f"{term} {definition} {invariants_text}".lower()
    # Generic attribute inference from definition text (no domain hardcoding, works for any domain keywords)
    candidate_tokens = [
        ("capacity", "int"),
        ("available_seats", "int"),
        ("seats_available", "int"),
        ("total_seats", "int"),
        ("seats", "int"),
        ("quantity", "int"),
        ("stock", "int"),
        ("origin", "str"),
        ("destination", "str"),
        ("departure_time", "str"),
        ("arrival_time", "str"),
        ("flight_number", "str"),
        ("email", "str"),
        ("name", "str"),
        ("full_name", "str"),
        ("phone", "str"),
        ("status", "str"),
        ("role", "str"),
        ("created_at", "str"),
        ("price", "float"),
        ("amount", "float"),
    ]
    for token, ftype in candidate_tokens:
        if token in combined and token not in seen:
            fields.append({"name": token, "type": ftype})
            seen.add(token)

    # Detect foreign key references to other entities mentioned in definition
    for fk_match in re.findall(r"\b([a-z]+)_id\b", combined):
        fk_col = f"{fk_match}_id"
        if fk_col not in seen:
            fields.append({"name": fk_col, "type": "str"})
            seen.add(fk_col)

    if len(fields) == 1:
        fields.extend([
            {"name": "name", "type": "str"},
            {"name": "status", "type": "str"},
            {"name": "capacity", "type": "int"},
            {"name": "created_at", "type": "str"},
        ])
    return fields


def _is_role_protected_ac(ac: AcceptanceCriterionModel, invariants_text: str) -> bool:
    if ac.role_protected is not None:
        return bool(ac.role_protected)
    txt = ac.full_text().lower()
    auth_keywords = (
        "authorized",
        "permission",
        "forbidden",
        "403",
        "unauthorized",
        "staff",
        "admin",
        "role",
        "access denied",
        "lacks permission",
        "non-authorized",
    )
    return any(k in txt for k in auth_keywords)


def infer_permissions(
    spec: HandoffSpec,
    handoff_path: Optional[Path] = None,
    is_mock: bool = False,
) -> Dict[str, Any]:
    """Build permissions structure according to §10:
    1. If permissions_override.json exists next to handoff.json, use that.
    2. If handoff JSON includes an explicit permissions section, use that.
    3. If mock mode (LLM_MODEL=mock): every role is allowed everything, clearly logged.
    4. Otherwise infer from ACs, invariants (e.g. INV-003), screens, and role names.
    """
    roles = spec.ui.role_names()
    if not roles:
        roles = ["admin", "staff", "user", "guest"]

    # Check override file next to handoff
    if handoff_path is not None:
        override_file = Path(handoff_path).parent / "permissions_override.json"
        if override_file.exists():
            try:
                override_data = json.loads(override_file.read_text(encoding="utf-8"))
                return {
                    "source": "permissions_override.json",
                    "assumption": False,
                    "auth_mode": os.getenv("AUTH_MODE", "header"),
                    "roles": roles,
                    "based_on_ids": [],
                    "matrix": override_data.get("matrix", override_data),
                }
            except Exception:
                pass

    # Check explicit permissions in handoff
    explicit_perms = spec.permissions or spec.ui.permissions
    if isinstance(explicit_perms, dict) and explicit_perms:
        return {
            "source": "handoff_explicit",
            "assumption": False,
            "auth_mode": os.getenv("AUTH_MODE", "header"),
            "roles": roles,
            "based_on_ids": [],
            "matrix": explicit_perms.get("matrix", explicit_perms),
        }

    based_on_ids: List[str] = []
    for inv in spec.invariants:
        txt = f"{inv.title} {inv.description} {inv.rule}".lower()
        if any(w in txt for w in ("role", "staff", "authorized", "permission", "access", "disclos", "confidential")):
            based_on_ids.append(inv.id)

    for st in spec.stories:
        for ac in st.acceptance_criteria:
            if _is_role_protected_ac(ac, ""):
                based_on_ids.append(ac.id)

    if is_mock:
        matrix = {
            role: {
                "allow_all": True,
                "allowed_actions": ["*"],
                "allowed_stories": [st.id for st in spec.stories],
                "allowed_acs": [ac.id for st in spec.stories for ac in st.acceptance_criteria],
            }
            for role in roles
        }
        return {
            "source": "mock_allow_all",
            "assumption": True,
            "note": "Mock mode (LLM_MODEL=mock): every role is allowed everything for dry-run traceability.",
            "auth_mode": os.getenv("AUTH_MODE", "header"),
            "roles": roles,
            "based_on_ids": based_on_ids,
            "matrix": matrix,
        }

    # Infer privileged vs restricted roles from role names and AC/INV text
    privileged_keywords = ("admin", "staff", "agent", "manager", "operator", "supervisor", "doctor", "nurse", "clerk", "support")
    restricted_keywords = ("guest", "anonymous", "public", "viewer", "unauthenticated", "passenger", "customer", "patient", "shopper")

    privileged_roles: List[str] = []
    standard_roles: List[str] = []
    for r in roles:
        rl = r.lower()
        if any(pk in rl for pk in privileged_keywords):
            privileged_roles.append(r)
        elif any(rk in rl for rk in restricted_keywords):
            standard_roles.append(r)
        else:
            privileged_roles.append(r)

    if not privileged_roles and roles:
        privileged_roles = [roles[0]]

    all_story_ids = [st.id for st in spec.stories]
    protected_ac_ids: List[str] = []
    public_ac_ids: List[str] = []
    protected_story_ids: Set[str] = set()

    for st in spec.stories:
        for ac in st.acceptance_criteria:
            if _is_role_protected_ac(ac, ""):
                protected_ac_ids.append(ac.id)
                protected_story_ids.add(st.id)
            else:
                public_ac_ids.append(ac.id)

    matrix: Dict[str, Any] = {}
    for r in roles:
        is_priv = r in privileged_roles
        matrix[r] = {
            "allow_all": is_priv,
            "is_authorized_staff": is_priv,
            "allowed_actions": ["read", "write", "manage", "history", "admin"] if is_priv else ["read", "search", "book"],
            "allowed_stories": all_story_ids if is_priv else [sid for sid in all_story_ids if sid not in protected_story_ids] or all_story_ids,
            "allowed_acs": (public_ac_ids + protected_ac_ids) if is_priv else public_ac_ids,
            "denied_acs": [] if is_priv else protected_ac_ids,
        }

    return {
        "source": "inferred_from_handoff",
        "assumption": True,
        "note": "Role permissions inferred from handoff ACs, invariants, screens, and role names.",
        "auth_mode": os.getenv("AUTH_MODE", "header"),
        "roles": roles,
        "privileged_roles": privileged_roles,
        "standard_roles": standard_roles,
        "protected_ac_ids": protected_ac_ids,
        "based_on_ids": based_on_ids,
        "matrix": matrix,
    }


def _collect_expected_ids(spec: HandoffSpec) -> Dict[str, Set[str]]:
    return {
        "stories": {st.id for st in spec.stories},
        "acs": {ac.id for st in spec.stories for ac in st.acceptance_criteria},
        "tasks": {t.id for t in spec.tasks},
        "components": {c.id for c in spec.components},
        "screens": {s.id for s in spec.ui.screens},
        "nfrs": {n.id for n in spec.nfrs},
        "invariants": {i.id for i in spec.invariants},
    }


def check_extraction_completeness(spec: HandoffSpec, extraction: Dict[str, Any]) -> List[str]:
    """Verify every story, AC, task, component, screen, NFR, and invariant ID in handoff appears in extraction."""
    expected = _collect_expected_ids(spec)
    missing: List[str] = []

    ext_stories = set(extraction.get("story_ids", []))
    ext_acs = set(extraction.get("ac_ids", []))
    ext_tasks = set(extraction.get("task_ids", []))
    ext_comps = {c["id"] for c in extraction.get("components", []) if isinstance(c, dict) and "id" in c}
    ext_screens = {s["id"] for s in extraction.get("screens", []) if isinstance(s, dict) and "id" in s}
    ext_nfrs = {n["id"] for n in extraction.get("nfrs", []) if isinstance(n, dict) and "id" in n}
    ext_invs = {i["id"] for i in extraction.get("invariants", []) if isinstance(i, dict) and "id" in i}

    for sid in sorted(expected["stories"] - ext_stories):
        missing.append(f"story:{sid}")
    for aid in sorted(expected["acs"] - ext_acs):
        missing.append(f"ac:{aid}")
    for tid in sorted(expected["tasks"] - ext_tasks):
        missing.append(f"task:{tid}")
    for cid in sorted(expected["components"] - ext_comps):
        missing.append(f"component:{cid}")
    for scid in sorted(expected["screens"] - ext_screens):
        missing.append(f"screen:{scid}")
    for nid in sorted(expected["nfrs"] - ext_nfrs):
        missing.append(f"nfr:{nid}")
    for iid in sorted(expected["invariants"] - ext_invs):
        missing.append(f"invariant:{iid}")

    return missing


def _build_deterministic_extraction(
    spec: HandoffSpec,
    handoff_path: Optional[Path] = None,
    is_mock: bool = False,
) -> Dict[str, Any]:
    invariants_text = " ".join(f"{i.title} {i.description} {i.rule}" for i in spec.invariants)

    # 1. Entities & Tables
    entities: List[Dict[str, Any]] = []
    tables: List[Dict[str, Any]] = []
    seen_slugs: Set[str] = set()

    for g in spec.glossary:
        slug = _slugify(g.term)
        if slug in seen_slugs:
            continue
        seen_slugs.add(slug)
        table_name = _pluralize(slug)
        fields = _infer_fields_for_entity(g.term, g.definition or "", g.attributes or [], invariants_text)
        entities.append({
            "id": g.id or f"ENT-{len(entities)+1:03d}",
            "term": g.term,
            "slug": slug,
            "table_name": table_name,
            "definition": g.definition or "",
            "fields": fields,
        })
        tables.append({
            "name": table_name,
            "entity": g.term,
            "slug": slug,
            "columns": fields,
        })

    # If glossary was empty, derive entities from story nouns / tasks
    if not entities:
        for idx, st in enumerate(spec.stories, start=1):
            slug = _slugify(st.title.split()[0] if st.title else f"item_{idx}")
            if slug in seen_slugs:
                slug = f"{slug}_{idx}"
            seen_slugs.add(slug)
            table_name = _pluralize(slug)
            fields = _infer_fields_for_entity(st.title, st.description or "", [], invariants_text)
            entities.append({
                "id": f"ENT-{idx:03d}",
                "term": st.title,
                "slug": slug,
                "table_name": table_name,
                "definition": st.description or "",
                "fields": fields,
            })
            tables.append({
                "name": table_name,
                "entity": st.title,
                "slug": slug,
                "columns": fields,
            })

    # Ensure cross-entity foreign keys if an invariant links entities (e.g. reservation needs flight + customer)
    entity_slugs = [e["slug"] for e in entities]
    for ent in entities:
        inv_lower = (ent["definition"] + " " + invariants_text).lower()
        existing_col_names = {f["name"] for f in ent["fields"]}
        for other_slug in entity_slugs:
            if other_slug != ent["slug"] and other_slug in inv_lower:
                fk_col = f"{other_slug}_id"
                if fk_col not in existing_col_names:
                    ent["fields"].append({"name": fk_col, "type": "str"})
                    existing_col_names.add(fk_col)

    # 2. Endpoints derived from entities, stories, ACs, and screens
    endpoints: List[Dict[str, Any]] = []
    seen_ep: Set[Tuple[str, str]] = set()

    def add_endpoint(
        method: str,
        path: str,
        summary: str,
        story_id: Optional[str] = None,
        ac_ids: Optional[List[str]] = None,
        task_ids: Optional[List[str]] = None,
        entity_slug: Optional[str] = None,
        role_protected: bool = False,
    ) -> None:
        key = (method.upper(), path)
        if key in seen_ep:
            for ep in endpoints:
                if (ep["method"], ep["path"]) == key:
                    for aid in (ac_ids or []):
                        if aid not in ep["ac_ids"]:
                            ep["ac_ids"].append(aid)
                    for tid in (task_ids or []):
                        if tid not in ep["task_ids"]:
                            ep["task_ids"].append(tid)
                    if role_protected:
                        ep["role_protected"] = True
            return
        seen_ep.add(key)
        endpoints.append({
            "method": method.upper(),
            "path": path,
            "summary": summary,
            "story_id": story_id,
            "ac_ids": list(ac_ids or []),
            "task_ids": list(task_ids or []),
            "entity_slug": entity_slug,
            "role_protected": role_protected,
        })

    # Entity CRUD + search + history endpoints
    for ent in entities:
        tname = ent["table_name"]
        slug = ent["slug"]
        add_endpoint("GET", f"/api/{tname}", f"List or search {tname}", entity_slug=slug)
        add_endpoint("POST", f"/api/{tname}", f"Create {slug}", entity_slug=slug)
        add_endpoint("GET", f"/api/{tname}/{{item_id}}", f"Get {slug} by ID", entity_slug=slug)

    # Map story/AC specifics onto endpoints
    for st in spec.stories:
        st_text = f"{st.title} {st.description}".lower()
        st_ac_ids = [ac.id for ac in st.acceptance_criteria]
        any_protected = any(_is_role_protected_ac(ac, invariants_text) for ac in st.acceptance_criteria)

        matched_ent = None
        for ent in entities:
            if ent["slug"] in st_text or ent["table_name"] in st_text:
                matched_ent = ent
                break
        if matched_ent is None and entities:
            matched_ent = entities[0]

        tname = matched_ent["table_name"] if matched_ent else "items"
        slug = matched_ent["slug"] if matched_ent else "item"

        if "history" in st_text:
            add_endpoint(
                "GET",
                f"/api/{tname}/history",
                f"Retrieve {st.title}",
                story_id=st.id,
                ac_ids=st_ac_ids,
                task_ids=list(st.task_ids),
                entity_slug=slug,
                role_protected=any_protected,
            )
            # Also support customer/entity-scoped history route
            add_endpoint(
                "GET",
                "/api/history",
                f"History endpoint for {st.title}",
                story_id=st.id,
                ac_ids=st_ac_ids,
                task_ids=list(st.task_ids),
                entity_slug=slug,
                role_protected=any_protected,
            )
        elif "search" in st_text:
            add_endpoint(
                "GET",
                f"/api/{tname}/search",
                f"Search {tname} for {st.title}",
                story_id=st.id,
                ac_ids=st_ac_ids,
                task_ids=list(st.task_ids),
                entity_slug=slug,
                role_protected=any_protected,
            )

        # Attach story ACs and tasks to the entity's main endpoints
        add_endpoint(
            "GET",
            f"/api/{tname}",
            f"List {tname}",
            story_id=st.id,
            ac_ids=st_ac_ids,
            task_ids=list(st.task_ids),
            entity_slug=slug,
            role_protected=False,
        )
        add_endpoint(
            "POST",
            f"/api/{tname}",
            f"Create {slug}",
            story_id=st.id,
            ac_ids=st_ac_ids,
            task_ids=list(st.task_ids),
            entity_slug=slug,
            role_protected=False,
        )

    # 3. Screens & UI states
    screens_extracted: List[Dict[str, Any]] = []
    ui_states: List[Dict[str, Any]] = []
    for scr in spec.ui.screens:
        states = list(scr.states) if scr.states else ["loading", "empty", "loaded", "error"]
        elements = [
            el if isinstance(el, str) else (el.get("id") or el.get("name") or str(el))
            for el in (scr.elements or [])
        ]
        s_dict = {
            "id": scr.id,
            "name": scr.name,
            "route": scr.route or f"/{_slugify(scr.name)}",
            "story_ids": list(scr.story_ids),
            "ac_ids": list(scr.ac_ids),
            "states": states,
            "elements": elements,
            "roles": list(scr.roles),
        }
        screens_extracted.append(s_dict)
        ui_states.append({
            "screen_id": scr.id,
            "route": s_dict["route"],
            "states": states,
            "elements": elements,
        })

    # 4. Invariants
    invariants_extracted = [
        {
            "id": inv.id,
            "title": inv.title or inv.id,
            "description": inv.description or inv.rule or "",
            "rule": inv.rule or inv.description or "",
            "applies_to_stories": list(inv.applies_to_stories),
            "entities": list(inv.entities),
        }
        for inv in spec.invariants
    ]

    # 5. NFRs
    nfrs_extracted = [
        {
            "id": nfr.id,
            "category": nfr.category or "general",
            "title": nfr.title or nfr.id,
            "description": nfr.description or "",
            "metric": nfr.metric,
            "comparator": nfr.comparator,
            "threshold": nfr.threshold,
            "unit": nfr.unit or "",
            "assumption": bool(nfr.assumption),
            "applies_to_stories": list(nfr.applies_to_stories),
        }
        for nfr in spec.nfrs
    ]

    # 6. Components
    components_extracted = [
        {
            "id": comp.id,
            "name": comp.name,
            "slug": _slugify(comp.name),
            "type": comp.type or "service",
            "technology_stack": comp.technology_stack,
            "stack_summary": comp.stack_summary(),
            "linked_task_ids": sorted(comp.get_all_linked_tasks()),
            "satisfies_nfrs": list(comp.satisfies_nfrs),
            "adr_ids": list(comp.adr_ids),
        }
        for comp in spec.components
    ]

    permissions = infer_permissions(spec, handoff_path=handoff_path, is_mock=is_mock)

    return {
        "handoff_id": spec.handoff_id,
        "story_ids": [st.id for st in spec.stories],
        "ac_ids": [ac.id for st in spec.stories for ac in st.acceptance_criteria],
        "task_ids": [t.id for t in spec.tasks],
        "entities": entities,
        "invariants": invariants_extracted,
        "nfrs": nfrs_extracted,
        "components": components_extracted,
        "screens": screens_extracted,
        "permissions": permissions,
        "build_plan": {
            "tables": tables,
            "endpoints": endpoints,
            "ui_states": ui_states,
        },
    }


async def run_extraction(
    spec: HandoffSpec,
    llm: LLMClient,
    tracer: TraceLogger,
    graph: TraceGraph,
    handoff_path: Optional[Path] = None,
    intent_max_retries: Optional[int] = None,
) -> Dict[str, Any]:
    """Run Stage S2 extraction and the Extraction Intent-Match Gate (§7)."""
    max_retries = int(
        intent_max_retries
        if intent_max_retries is not None
        else os.getenv("INTENT_MAX_RETRIES", "2")
    )
    baseline = _build_deterministic_extraction(spec, handoff_path=handoff_path, is_mock=llm.is_mock)

    feedback_missing: List[str] = []
    extraction = dict(baseline)

    for attempt in range(1, max_retries + 2):
        if not llm.is_mock and llm.scripted_responder is not None:
            # Allow scripted LLM in tests to simulate partial extraction on attempt 1 and full extraction on retry
            resp = await llm.complete_json(
                prompt=json.dumps({
                    "stage": "S2_extraction",
                    "handoff_id": spec.handoff_id,
                    "missing_feedback": feedback_missing,
                }),
                context={"stage": "S2", "feedback_missing": feedback_missing, "baseline": baseline},
                tracer=tracer,
                stage="S2",
                ids={"handoff": spec.handoff_id},
                mode="serial",
            )
            if isinstance(resp, dict) and "extraction_override" in resp:
                extraction = resp["extraction_override"]
            else:
                extraction = dict(baseline)
        else:
            extraction = dict(baseline)

        missing = check_extraction_completeness(spec, extraction)
        if not missing:
            tracer.log(
                stage="S2",
                event="extraction_completed",
                level="info",
                ids={
                    "story": extraction["story_ids"],
                    "ac": extraction["ac_ids"],
                    "task": extraction["task_ids"],
                    "component": [c["id"] for c in extraction["components"]],
                    "screen": [s["id"] for s in extraction["screens"]],
                    "nfr": [n["id"] for n in extraction["nfrs"]],
                    "invariant": [i["id"] for i in extraction["invariants"]],
                },
                mode="serial",
                attempt=attempt,
                data={
                    "entities_count": len(extraction["entities"]),
                    "tables_count": len(extraction["build_plan"]["tables"]),
                    "endpoints_count": len(extraction["build_plan"]["endpoints"]),
                    "screens_count": len(extraction["screens"]),
                    "permissions_source": extraction["permissions"]["source"],
                    "build_plan": extraction["build_plan"],
                },
            )
            tracer.log(
                stage="S2",
                event="extraction_gate_passed",
                level="info",
                ids={"handoff": spec.handoff_id},
                mode="serial",
                attempt=attempt,
                data={"attempt": f"{attempt}/{max_retries + 1}", "missing": []},
                stream="intent_match.jsonl",
            )
            break

        feedback_missing = missing
        tracer.log(
            stage="S2",
            event="extraction_gate_retry" if attempt <= max_retries else "extraction_gate_unmatched",
            level="warning" if attempt <= max_retries else "error",
            ids={"handoff": spec.handoff_id},
            mode="serial",
            attempt=attempt,
            data={
                "attempt": f"{attempt}/{max_retries + 1}",
                "missing": missing,
                "reason": f"Missing IDs in extraction: {missing}",
            },
            stream="intent_match.jsonl",
        )
        if attempt > max_retries:
            # Repair from deterministic baseline so downstream stages have complete metadata while preserving unmatched warning
            extraction = dict(baseline)
            extraction["unmatched_extraction_ids"] = missing

    # Log inferred permissions as an assumption in extraction.jsonl
    tracer.log(
        stage="S2",
        event="permissions_extracted",
        level="info",
        ids={"based_on": extraction["permissions"].get("based_on_ids", [])},
        mode="serial",
        attempt=1,
        data=extraction["permissions"],
    )

    return extraction
