"""Stage S1: Intent extraction per story.

Emits one intent record per story (goal, ACs, invariants, NFRs, screens,
components it touches) to `intent.jsonl` (and `trace.jsonl`) and adds
intent nodes/edges to the TraceGraph.
"""
from __future__ import annotations

from typing import Any, Dict, List
from .models import HandoffSpec
from .tracing import TraceGraph, TraceLogger


def build_intents(
    spec: HandoffSpec,
    tracer: TraceLogger,
    graph: TraceGraph,
) -> List[Dict[str, Any]]:
    """Build and log one intent record per story in the handoff."""
    intents: List[Dict[str, Any]] = []

    # Map task_id -> component_ids
    task_to_components: Dict[str, List[str]] = {}
    for comp in spec.components:
        for tid in comp.get_all_linked_tasks():
            task_to_components.setdefault(tid, []).append(comp.id)
    for t in spec.tasks:
        if t.component_id:
            comp_list = task_to_components.setdefault(t.id, [])
            if t.component_id not in comp_list:
                comp_list.append(t.component_id)

    # Map story_id -> invariants
    story_to_invariants: Dict[str, List[str]] = {st.id: list(st.invariant_ids) for st in spec.stories}
    for inv in spec.invariants:
        for sid in inv.applies_to_stories:
            inv_list = story_to_invariants.setdefault(sid, [])
            if inv.id not in inv_list:
                inv_list.append(inv.id)

    # Map story_id -> NFRs
    story_to_nfrs: Dict[str, List[str]] = {st.id: list(st.nfr_ids) for st in spec.stories}
    for nfr in spec.nfrs:
        for sid in nfr.applies_to_stories:
            nfr_list = story_to_nfrs.setdefault(sid, [])
            if nfr.id not in nfr_list:
                nfr_list.append(nfr.id)

    # Map story_id -> screens
    story_to_screens: Dict[str, List[str]] = {st.id: list(st.screen_ids) for st in spec.stories}
    ac_to_story: Dict[str, str] = {}
    for st in spec.stories:
        for ac in st.acceptance_criteria:
            ac_to_story[ac.id] = st.id

    for scr in spec.ui.screens:
        for sid in scr.story_ids:
            scr_list = story_to_screens.setdefault(sid, [])
            if scr.id not in scr_list:
                scr_list.append(scr.id)
        for aid in scr.ac_ids:
            sid = ac_to_story.get(aid)
            if sid:
                scr_list = story_to_screens.setdefault(sid, [])
                if scr.id not in scr_list:
                    scr_list.append(scr.id)

    # Add root handoff node
    graph.add_node(spec.handoff_id, "handoff", label=spec.project_name)

    for idx, st in enumerate(spec.stories, start=1):
        intent_id = f"INT-{idx:03d}"
        ac_ids = [ac.id for ac in st.acceptance_criteria]
        inv_ids = story_to_invariants.get(st.id, [])
        nfr_ids = list(story_to_nfrs.get(st.id, []))

        touched_components: List[str] = []
        for tid in st.task_ids:
            for cid in task_to_components.get(tid, []):
                if cid not in touched_components:
                    touched_components.append(cid)

        # Also inherit component-level NFRs if not explicitly listed on story
        for cid in touched_components:
            comp_obj = next((c for c in spec.components if c.id == cid), None)
            if comp_obj:
                for nid in comp_obj.satisfies_nfrs:
                    if nid not in nfr_ids:
                        nfr_ids.append(nid)

        screen_ids = story_to_screens.get(st.id, [])
        goal_parts = [st.title]
        if st.description:
            goal_parts.append(st.description)
        elif st.i_want:
            goal_parts.append(f"As a {st.as_a}, I want {st.i_want} so that {st.so_that}".strip())
        goal = " — ".join(p for p in goal_parts if p)

        intent_record = {
            "intent_id": intent_id,
            "story_id": st.id,
            "goal": goal,
            "ac_ids": ac_ids,
            "task_ids": list(st.task_ids),
            "invariant_ids": inv_ids,
            "nfr_ids": nfr_ids,
            "screen_ids": screen_ids,
            "component_ids": touched_components,
        }
        intents.append(intent_record)

        # Populate graph nodes & edges
        graph.add_node(st.id, "story", label=f"{st.id}: {st.title}")
        graph.add_edge(st.id, spec.handoff_id, "derives_from")

        graph.add_node(intent_id, "intent", label=f"{intent_id} ({st.id})")
        graph.add_edge(intent_id, st.id, "derives_from")

        for ac in st.acceptance_criteria:
            graph.add_node(ac.id, "ac", label=f"{ac.id}: {ac.title or ac.id}")
            graph.add_edge(ac.id, st.id, "derives_from")
            graph.add_edge(intent_id, ac.id, "covers")

        for tid in st.task_ids:
            graph.add_node(tid, "task", label=tid)
            graph.add_edge(tid, st.id, "implements")
            for aid in ac_ids:
                graph.add_edge(tid, aid, "implements")

        for iid in inv_ids:
            graph.add_node(iid, "invariant", label=iid)
            graph.add_edge(iid, st.id, "covers")

        for nid in nfr_ids:
            graph.add_node(nid, "nfr", label=nid)
            graph.add_edge(nid, st.id, "covers")

        for scid in screen_ids:
            graph.add_node(scid, "screen", label=scid)
            graph.add_edge(scid, st.id, "implements")

        for cid in touched_components:
            graph.add_node(cid, "component", label=cid)
            for tid in st.task_ids:
                if cid in task_to_components.get(tid, []):
                    graph.add_edge(cid, tid, "implements")

        tracer.log(
            stage="S1",
            event="story_intent_recorded",
            level="info",
            ids={
                "intent": intent_id,
                "story": st.id,
                "ac": ac_ids,
                "task": list(st.task_ids),
                "invariant": inv_ids,
                "nfr": nfr_ids,
                "screen": screen_ids,
                "component": touched_components,
            },
            mode="serial",
            attempt=1,
            data=intent_record,
        )

    return intents
