"""Environment-driven LLM client with mock mode and transport/format retry loop.

Reads configuration from environment variables:
  LLM_MODEL (default: openrouter/google/gemma-3-27b-it:free; "mock" = dry run)
  LLM_API_KEY (falls back to OPENROUTER_API_KEY / GEMINI_API_KEY)
  LLM_BASE_URL (default: https://openrouter.ai/api/v1)
  LLM_MAX_RETRIES (default: 3)
  MAX_PARALLEL (default: 3)
"""
from __future__ import annotations

import asyncio
import json
import os
import re
from typing import Any, Callable, Dict, Optional
import httpx


class LLMTransportError(Exception):
    """Raised when LLM transport or output format parsing fails."""


class LLMClient:
    """Async LLM client supporting OpenAI-compatible endpoints, Mock mode, and scripted testing."""

    def __init__(
        self,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        max_retries: Optional[int] = None,
        max_parallel: Optional[int] = None,
        scripted_responder: Optional[Callable[[str, Dict[str, Any]], Any]] = None,
    ) -> None:
        self.model = (model or os.getenv("LLM_MODEL") or "openrouter/google/gemma-3-27b-it:free").strip()
        self.api_key = (
            api_key
            or os.getenv("LLM_API_KEY")
            or os.getenv("OPENROUTER_API_KEY")
            or os.getenv("GEMINI_API_KEY")
            or ""
        ).strip()
        self.base_url = (base_url or os.getenv("LLM_BASE_URL") or "https://openrouter.ai/api/v1").strip().rstrip("/")
        self.max_retries = int(max_retries if max_retries is not None else os.getenv("LLM_MAX_RETRIES", "3"))
        self.max_parallel = int(max_parallel if max_parallel is not None else os.getenv("MAX_PARALLEL", "3"))
        self.semaphore = asyncio.Semaphore(max(1, self.max_parallel))
        self.scripted_responder = scripted_responder

    @property
    def is_mock(self) -> bool:
        return self.model.lower() == "mock"

    def _normalize_model_for_http(self) -> str:
        # Strip provider prefix if calling OpenRouter directly via HTTP chat/completions
        if "openrouter.ai" in self.base_url and self.model.startswith("openrouter/"):
            return self.model[len("openrouter/"):]
        return self.model

    async def complete_json(
        self,
        prompt: str,
        context: Optional[Dict[str, Any]] = None,
        tracer: Optional[Any] = None,
        stage: str = "S4",
        ids: Optional[Dict[str, Any]] = None,
        mode: str = "serial",
    ) -> Dict[str, Any]:
        """Request a structured JSON response from the LLM with transport/format retries."""
        context = context or {}
        if self.is_mock and self.scripted_responder is None:
            return {"mock": True}

        async with self.semaphore:
            last_err: Optional[Exception] = None
            for attempt in range(1, self.max_retries + 1):
                try:
                    if self.scripted_responder is not None:
                        raw_resp = self.scripted_responder(prompt, {**context, "attempt": attempt})
                        if asyncio.iscoroutine(raw_resp):
                            raw_resp = await raw_resp
                        if isinstance(raw_resp, dict):
                            return raw_resp
                        return self._parse_json(str(raw_resp))

                    raw_text = await self._http_chat_completion(prompt)
                    return self._parse_json(raw_text)
                except Exception as exc:
                    last_err = exc
                    if tracer is not None:
                        tracer.log(
                            stage=stage,
                            event="llm_transport_retry",
                            level="warning",
                            ids=ids or {},
                            mode=mode,
                            attempt=attempt,
                            data={
                                "attempt": f"{attempt}/{self.max_retries}",
                                "error": str(exc),
                                "model": self.model,
                            },
                        )
                    if attempt < self.max_retries:
                        await asyncio.sleep(0.05 * (2 ** (attempt - 1)))

            raise LLMTransportError(f"LLM call failed after {self.max_retries} attempts: {last_err}")

    async def _http_chat_completion(self, prompt: str) -> str:
        if not self.api_key or self.api_key == "your-key-here":
            raise LLMTransportError("No valid LLM_API_KEY configured for non-mock model.")
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self._normalize_model_for_http(),
            "messages": [
                {"role": "system", "content": "You are a precise code generation assistant. Always respond with valid JSON only."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.1,
        }
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            resp.raise_for_status()
            body = resp.json()
            return body["choices"][0]["message"]["content"]

    @staticmethod
    def _parse_json(text: str) -> Dict[str, Any]:
        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```[a-zA-Z0-9_-]*\s*", "", cleaned)
            cleaned = re.sub(r"\s*```$", "", cleaned)
        match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if match:
            cleaned = match.group(0)
        parsed = json.loads(cleaned)
        if not isinstance(parsed, dict):
            raise ValueError("Expected JSON object from LLM")
        return parsed
