"""Stage S4: Checklist Executor & Code Generator.

Executes checklist layers topologically:
  - Parallel layers run concurrently via `asyncio.gather` (capped by `MAX_PARALLEL`).
  - Serial layers run sequentially.
  - Logs each item's lifecycle: `queued -> started -> generated -> gate_passed|retry|unmatched`
    with `mode` (`serial` or `parallel`) on every line.
  - Strictly adheres to the No-Hardcoding Rule: all component folders, database tables,
    REST endpoints, invariants, NFR handlers, screens, and permissions are generated
    dynamically from the extracted handoff plan.
  - In Mock mode (`LLM_MODEL=mock`), generated files include explicit `# TODO (mock mode)`
    markers while keeping a runnable structure.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Callable, Coroutine, Dict, List, Optional
from .llm import LLMClient
from .models import HandoffSpec
from .tracing import TraceGraph, TraceLogger


def _component_folder_map(spec: HandoffSpec, extraction: Dict[str, Any]) -> Dict[str, str]:
    """Map component IDs to folder names inside output/<handoff_id>/."""
    mapping: Dict[str, str] = {}
    used_folders: set = set()
    for comp in extraction.get("components", []):
        cid = comp["id"]
        c_text = f"{comp['name']} {comp['type']} {comp['stack_summary']}".lower()
        if any(k in c_text for k in ("ui", "frontend", "web", "client", "html", "css", "screen")) and "frontend" not in used_folders:
            folder = "frontend"
        elif any(k in c_text for k in ("api", "backend", "service", "server", "db", "data", "python", "fastapi")) and "backend" not in used_folders:
            folder = "backend"
        else:
            folder = comp["slug"]
        used_folders.add(folder)
        mapping[cid] = folder

    if "backend" not in used_folders:
        mapping["_default_backend"] = "backend"
    if "frontend" not in used_folders:
        mapping["_default_frontend"] = "frontend"
    return mapping


def _generate_foundation_files(
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    output_dir: Path,
    is_mock: bool,
) -> List[str]:
    """Generate L0 DB schema, permissions.json, API contract, and core backend app."""
    written: List[str] = []
    backend_dir = output_dir / "backend"
    backend_dir.mkdir(parents=True, exist_ok=True)
    (backend_dir / "__init__.py").write_text('"""Generated backend package."""\n', encoding="utf-8")
    written.append("backend/__init__.py")

    # 1. Write permissions.json (§10)
    perms = extraction.get("permissions", {})
    perms_path = backend_dir / "permissions.json"
    perms_path.write_text(json.dumps(perms, indent=2, ensure_ascii=False), encoding="utf-8")
    written.append("backend/permissions.json")

    # 2. Write contracts.json (derived from ACs / build_plan)
    contract_doc = {
        "handoff_id": spec.handoff_id,
        "derived_from_acs": extraction.get("ac_ids", []),
        "tables": extraction["build_plan"]["tables"],
        "endpoints": extraction["build_plan"]["endpoints"],
        "invariants": extraction.get("invariants", []),
        "nfrs": extraction.get("nfrs", []),
    }
    (backend_dir / "contracts.json").write_text(
        json.dumps(contract_doc, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    written.append("backend/contracts.json")

    # 3. Write database & invariant engine (backend/db.py)
    mock_banner = "# TODO (mock mode): Mock-scaffolded database and invariant engine\n" if is_mock else ""
    all_ac_tags = ", ".join(extraction.get("ac_ids", []))
    all_inv_tags = ", ".join(i["id"] for i in extraction.get("invariants", []))
    all_nfr_tags = ", ".join(n["id"] for n in extraction.get("nfrs", []))

    db_code = f'''{mock_banner}"""Database schema and atomic invariant engine for {spec.handoff_id}.

Implements ACs: {all_ac_tags}
Enforces Invariants: {all_inv_tags}
Satisfies NFRs: {all_nfr_tags}
"""
from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

DB_LOCK = threading.RLock()
BASE_DIR = Path(__file__).resolve().parent
CONTRACTS_PATH = BASE_DIR / "contracts.json"
PERMISSIONS_PATH = BASE_DIR / "permissions.json"


def load_contracts() -> Dict[str, Any]:
    return json.loads(CONTRACTS_PATH.read_text(encoding="utf-8"))


def load_permissions() -> Dict[str, Any]:
    return json.loads(PERMISSIONS_PATH.read_text(encoding="utf-8"))


class AtomicDatabase:
    """Thread-safe SQLite + in-memory transactional store enforcing handoff invariants."""

    def __init__(self, db_path: str = ":memory:") -> None:
        self.db_path = db_path
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.contracts = load_contracts()
        self._init_schema()

    def _init_schema(self) -> None:
        with self.lock:
            cur = self.conn.cursor()
            for tbl in self.contracts.get("tables", []):
                tname = tbl["name"]
                cur.execute(
                    f"CREATE TABLE IF NOT EXISTS {{tname}} ("
                    f"id TEXT PRIMARY KEY, "
                    f"payload TEXT NOT NULL, "
                    f"created_at TEXT NOT NULL)"
                )
            self.conn.commit()

    def reset(self) -> None:
        with self.lock:
            cur = self.conn.cursor()
            for tbl in self.contracts.get("tables", []):
                cur.execute(f"DELETE FROM {{tbl['name']}}")
            self.conn.commit()

    def list_records(self, table_name: str, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        with self.lock:
            cur = self.conn.cursor()
            cur.execute(f"SELECT payload FROM {{table_name}} ORDER BY created_at ASC")
            rows = [json.loads(r["payload"]) for r in cur.fetchall()]
            if not filters:
                return rows
            filtered: List[Dict[str, Any]] = []
            for item in rows:
                match = True
                for k, v in filters.items():
                    if v is None or v == "":
                        continue
                    if str(item.get(k, "")).lower() != str(v).lower():
                        match = False
                        break
                if match:
                    filtered.append(item)
            return filtered

    def get_record(self, table_name: str, item_id: str) -> Optional[Dict[str, Any]]:
        with self.lock:
            cur = self.conn.cursor()
            cur.execute(f"SELECT payload FROM {{table_name}} WHERE id = ?", (str(item_id),))
            row = cur.fetchone()
            return json.loads(row["payload"]) if row else None

    def insert_record(self, table_name: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Atomically validate all handoff invariants and insert record."""
        with self.lock:
            record = dict(data)
            now = datetime.now(timezone.utc).isoformat()
            record.setdefault("id", str(uuid.uuid4()))
            record.setdefault("created_at", now)

            # Enforce numeric non-negative capacity/seats/quantity invariants (e.g. {all_inv_tags})
            for num_key in ("capacity", "available_seats", "seats_available", "total_seats", "seats", "quantity", "stock"):
                if num_key in record and record[num_key] is not None:
                    val = int(record[num_key])
                    if val < 0:
                        raise ValueError(f"Invariant violation ({all_inv_tags}): {{num_key}} cannot be negative ({{val}})")
                    record[num_key] = val

            # Default available_seats from capacity if capacity is provided
            if "capacity" in record and "available_seats" not in record:
                record["available_seats"] = int(record["capacity"])

            # Check foreign-key references & atomic capacity decrement for dependent entities
            tables_by_slug = {{t["slug"]: t["name"] for t in self.contracts.get("tables", [])}}
            for key, val in list(record.items()):
                if key.endswith("_id") and key != "id":
                    ref_slug = key[:-3]
                    if ref_slug in tables_by_slug and val:
                        ref_table = tables_by_slug[ref_slug]
                        target_obj = self.get_record(ref_table, str(val))
                        if target_obj is None:
                            raise ValueError(
                                f"Invariant violation ({all_inv_tags}): referenced {{ref_slug}} '{{val}}' does not exist"
                            )
                        # If target entity tracks capacity / available_seats, atomically decrement and prevent overbooking
                        seats_requested = int(record.get("seats", 1))
                        if seats_requested <= 0:
                            raise ValueError(f"Invariant violation ({all_inv_tags}): requested seats must be >= 1")
                        if "available_seats" in target_obj or "capacity" in target_obj:
                            avail = int(target_obj.get("available_seats", target_obj.get("capacity", 0)))
                            if avail < seats_requested:
                                raise ValueError(
                                    f"Invariant violation ({all_inv_tags}): capacity exceeded for {{ref_slug}} '{{val}}' "
                                    f"(available={{avail}}, requested={{seats_requested}})"
                                )
                            target_obj["available_seats"] = avail - seats_requested
                            cur = self.conn.cursor()
                            cur.execute(
                                f"UPDATE {{ref_table}} SET payload = ? WHERE id = ?",
                                (json.dumps(target_obj), str(val)),
                            )

            cur = self.conn.cursor()
            cur.execute(
                f"SELECT payload FROM {{table_name}} WHERE id = ?",
                (str(record["id"]),),
            )
            if cur.fetchone() is not None:
                raise ValueError(f"Invariant violation ({all_inv_tags}): duplicate id '{{record['id']}}' in {{table_name}}")

            cur.execute(
                f"INSERT INTO {{table_name}} (id, payload, created_at) VALUES (?, ?, ?)",
                (str(record["id"]), json.dumps(record), str(record["created_at"])),
            )
            self.conn.commit()
            return record


DB = AtomicDatabase()
'''
    (backend_dir / "db.py").write_text(db_code, encoding="utf-8")
    written.append("backend/db.py")

    # 4. Write backend/auth.py for role header checking against permissions.json (§10)
    auth_code = f'''{mock_banner}"""Role-header authentication and permission enforcement for {spec.handoff_id}.

AUTH_MODE=header: identifies caller by `X-Role` (or `X-User-Role`) header and checks `permissions.json`.
Implements ACs: {all_ac_tags}
Enforces Invariants: {all_inv_tags}
Satisfies NFRs: {all_nfr_tags}
"""
from __future__ import annotations

from typing import Any, Dict, Optional
from fastapi import Header, HTTPException, Request
from .db import load_permissions


def check_role_permission(
    role: Optional[str],
    ac_id: Optional[str] = None,
    require_authorized_staff: bool = False,
) -> Dict[str, Any]:
    """Verify whether `role` is permitted by backend/permissions.json."""
    perms = load_permissions()
    matrix = perms.get("matrix", {{}})

    if perms.get("source") == "mock_allow_all":
        return {{"role": role or "mock", "allowed": True}}

    if not role or role not in matrix:
        raise HTTPException(
            status_code=403,
            detail={{"error": "Forbidden: missing or unrecognized role header", "ac_id": ac_id}},
        )

    role_cfg = matrix[role]
    if role_cfg.get("allow_all"):
        return {{"role": role, "allowed": True}}

    if require_authorized_staff and not role_cfg.get("is_authorized_staff", False):
        raise HTTPException(
            status_code=403,
            detail={{"error": "Forbidden: role lacks authorized staff permission", "ac_id": ac_id}},
        )

    if ac_id and ac_id in role_cfg.get("denied_acs", []):
        raise HTTPException(
            status_code=403,
            detail={{"error": f"Forbidden: role lacks permission for {{ac_id}}", "ac_id": ac_id}},
        )

    return {{"role": role, "allowed": True}}
'''
    (backend_dir / "auth.py").write_text(auth_code, encoding="utf-8")
    written.append("backend/auth.py")

    return written


def _generate_task_files(
    item: Dict[str, Any],
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    output_dir: Path,
    is_mock: bool,
    retry_feedback: Optional[Dict[str, Any]] = None,
) -> List[str]:
    """Generate component handlers or UI screens for a specific task checklist item."""
    written: List[str] = []
    mock_banner = "# TODO (mock mode): Mock-scaffolded task module\n" if is_mock else ""
    linked = item.get("linked", {})
    task_ids = linked.get("task", [])
    story_ids = linked.get("story", [])
    ac_ids = linked.get("ac", [])
    inv_ids = linked.get("invariant", []) or [i["id"] for i in extraction.get("invariants", [])]
    nfr_ids = linked.get("nfr", []) or [n["id"] for n in extraction.get("nfrs", [])]
    screen_ids = linked.get("screen", [])

    tid_slug = (task_ids[0] if task_ids else item["id"]).lower().replace("-", "_")

    # Check if this is a UI task or touches screens
    comp_map = _component_folder_map(spec, extraction)
    comp_ids = linked.get("component", [])
    target_folder = comp_map.get(comp_ids[0], "backend") if comp_ids else "backend"

    if target_folder == "frontend" or screen_ids and "ui" in item["title"].lower():
        frontend_dir = output_dir / "frontend"
        frontend_dir.mkdir(parents=True, exist_ok=True)
        (frontend_dir / "__init__.py").write_text('"""Generated frontend package."""\n', encoding="utf-8")
        written.append("frontend/__init__.py")

        # Write CSS design tokens + HTML screens + FastAPI UI server
        tokens_css = """:root {
  --color-bg: #f8fafc;
  --color-surface: #ffffff;
  --color-primary: #0f172a;
  --color-accent: #2563eb;
  --color-danger: #dc2626;
  --color-success: #16a34a;
  --space-sm: 0.5rem;
  --space-md: 1rem;
  --space-lg: 1.5rem;
  --radius-md: 6px;
  --font-sans: system-ui, -apple-system, sans-serif;
}
body {
  font-family: var(--font-sans);
  background: var(--color-bg);
  color: var(--color-primary);
  margin: 0;
  padding: var(--space-lg);
}
.card {
  background: var(--color-surface);
  border-radius: var(--radius-md);
  padding: var(--space-md);
  margin-bottom: var(--space-md);
  box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
"""
        (frontend_dir / "tokens.css").write_text(tokens_css, encoding="utf-8")
        written.append("frontend/tokens.css")

        screens_data = extraction.get("screens", [])
        ui_code = f'''{mock_banner}"""Frontend UI server and screen renderer for {spec.handoff_id}.

Implements Task: {", ".join(task_ids)}
Implements Stories: {", ".join(story_ids)}
Implements ACs: {", ".join(ac_ids)}
Implements Screens: {", ".join(s["id"] for s in screens_data)}
Enforces Invariants: {", ".join(inv_ids)}
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, Response

SCREENS: List[Dict[str, Any]] = {repr(screens_data)}
ROLES: List[str] = {repr(extraction.get("permissions", {}).get("roles", []))}
TOKENS_CSS = (Path(__file__).resolve().parent / "tokens.css").read_text(encoding="utf-8")


def render_screen_html(screen: Dict[str, Any], active_state: str = "loaded") -> str:
    states_html = "".join(
        f'<span class="state-badge" data-state="{{st}}">{{st}}</span> '
        for st in screen.get("states", ["loading", "empty", "loaded", "error"])
    )
    elements_html = "".join(
        f'<div class="ui-element" id="{{el}}" data-element="{{el}}">{{el}}</div>'
        for el in screen.get("elements", [])
    )
    ac_tags = ", ".join(screen.get("ac_ids", []))
    story_tags = ", ".join(screen.get("story_ids", []))
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>{{screen['name']}} - {spec.project_name}</title>
  <link rel="stylesheet" href="/tokens.css" />
</head>
<body data-screen-id="{{screen['id']}}" data-route="{{screen['route']}}" data-active-state="{{active_state}}">
  <header class="card">
    <h1>{{screen['name']}} ({{screen['id']}})</h1>
    <p>Route: <code>{{screen['route']}}</code> | Stories: {{story_tags}} | ACs: {{ac_tags}}</p>
    <div class="role-selector" data-roles="{{','.join(ROLES)}}">Roles: {{', '.join(ROLES)}}</div>
  </header>
  <main class="card">
    <section class="states" data-states="{{','.join(screen.get('states', []))}}">
      <h3>UI States</h3>
      {{states_html}}
    </section>
    <section class="elements">
      <h3>UI Elements</h3>
      {{elements_html}}
    </section>
  </main>
</body>
</html>"""


def create_ui_app() -> FastAPI:
    ui_app = FastAPI(title="{spec.project_name} UI")

    @ui_app.get("/tokens.css")
    async def get_tokens_css() -> Response:
        return Response(content=TOKENS_CSS, media_type="text/css")

    @ui_app.get("/ui/screens")
    async def list_screens() -> Dict[str, Any]:
        return {{"screens": SCREENS, "roles": ROLES}}

    for scr in SCREENS:
        route_path = scr.get("route") or "/"

        def _make_handler(s: Dict[str, Any]):
            async def _serve(state: str = "loaded") -> HTMLResponse:
                return HTMLResponse(content=render_screen_html(s, active_state=state))
            return _serve

        ui_app.add_api_route(route_path, _make_handler(scr), methods=["GET"], response_class=HTMLResponse)

    if not any((s.get("route") == "/") for s in SCREENS):
        @ui_app.get("/", response_class=HTMLResponse)
        async def index() -> HTMLResponse:
            if SCREENS:
                return HTMLResponse(content=render_screen_html(SCREENS[0]))
            return HTMLResponse(content="<html><body><h1>UI Ready</h1></body></html>")

    return ui_app


app = create_ui_app()
'''
        (frontend_dir / "ui_app.py").write_text(ui_code, encoding="utf-8")
        written.append("frontend/ui_app.py")

    # Also write dedicated backend handler module for every task so every task/AC/INV has explicit code traceability
    backend_dir = output_dir / "backend"
    backend_dir.mkdir(parents=True, exist_ok=True)
    handlers_dir = backend_dir / "handlers"
    handlers_dir.mkdir(parents=True, exist_ok=True)
    (handlers_dir / "__init__.py").write_text('"""Task handlers package."""\n', encoding="utf-8")

    # Collect AC details for this task
    ac_details: List[Dict[str, Any]] = []
    for st in spec.stories:
        for ac in st.acceptance_criteria:
            if ac.id in ac_ids:
                ac_details.append({
                    "id": ac.id,
                    "story_id": st.id,
                    "title": ac.title or ac.id,
                    "gherkin": ac.full_text(),
                    "role_protected": bool(
                        ac.id in extraction.get("permissions", {}).get("protected_ac_ids", [])
                    ),
                })

    handler_rel = f"backend/handlers/{tid_slug}.py"
    handler_code = f'''{mock_banner}"""Task handler for {item['id']} ({item['title']}).

Implements Tasks: {", ".join(task_ids)}
Implements Stories: {", ".join(story_ids)}
Implements ACs: {", ".join(ac_ids)}
Enforces Invariants: {", ".join(inv_ids)}
Satisfies NFRs: {", ".join(nfr_ids)}
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Header, HTTPException, Query
from ..auth import check_role_permission
from ..db import DB

router = APIRouter()

TASK_METADATA: Dict[str, Any] = {{
    "checklist_id": {json.dumps(item["id"])},
    "task_ids": {json.dumps(task_ids)},
    "story_ids": {json.dumps(story_ids)},
    "ac_ids": {json.dumps(ac_ids)},
    "invariant_ids": {json.dumps(inv_ids)},
    "nfr_ids": {json.dumps(nfr_ids)},
    "ac_details": {repr(ac_details)},
}}


def execute_task_operation(
    table_name: str,
    action: str = "list",
    payload: Optional[Dict[str, Any]] = None,
    filters: Optional[Dict[str, Any]] = None,
    role: Optional[str] = None,
    require_staff: bool = False,
    ac_id: Optional[str] = None,
) -> Any:
    """Execute validated domain operation for {", ".join(ac_ids)} enforcing {", ".join(inv_ids)}."""
    if require_staff:
        check_role_permission(role=role, ac_id=ac_id, require_authorized_staff=True)
    if action == "create":
        try:
            return DB.insert_record(table_name, payload or {{}})
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
    if action == "get" and payload and "id" in payload:
        rec = DB.get_record(table_name, str(payload["id"]))
        if rec is None:
            raise HTTPException(status_code=404, detail="Not found")
        return rec
    return DB.list_records(table_name, filters=filters)
'''
    (output_dir / handler_rel).write_text(handler_code, encoding="utf-8")
    written.append(handler_rel)

    return written


def _generate_wiring_files(
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    checklist_doc: Dict[str, Any],
    output_dir: Path,
    is_mock: bool,
) -> List[str]:
    """Generate unified FastAPI app (backend/app.py), pytest suite (tests/test_acceptance.py),
    docker-compose.yml, run_local.py, and README.md.
    """
    written: List[str] = []
    mock_banner = "# TODO (mock mode): Mock-scaffolded application wiring\n" if is_mock else ""

    all_ac_ids = extraction.get("ac_ids", [])
    all_inv_ids = [i["id"] for i in extraction.get("invariants", [])]
    all_nfr_ids = [n["id"] for n in extraction.get("nfrs", [])]
    protected_ac_ids = extraction.get("permissions", {}).get("protected_ac_ids", [])
    tables = extraction["build_plan"]["tables"]
    endpoints = extraction["build_plan"]["endpoints"]
    screens = extraction.get("screens", [])

    # 1. Ensure frontend/ui_app.py exists even if no dedicated UI task was separate
    frontend_dir = output_dir / "frontend"
    if not (frontend_dir / "ui_app.py").exists():
        _generate_task_files(
            {
                "id": "CHK-UI",
                "title": "UI Screens",
                "linked": {
                    "task": [],
                    "story": extraction.get("story_ids", []),
                    "ac": all_ac_ids,
                    "component": [c["id"] for c in extraction.get("components", [])],
                    "invariant": all_inv_ids,
                    "nfr": all_nfr_ids,
                    "screen": [s["id"] for s in screens],
                },
            },
            spec,
            extraction,
            output_dir,
            is_mock,
        )
        written.extend(["frontend/tokens.css", "frontend/ui_app.py"])

    # 2. Write backend/app.py mounting all dynamic entity endpoints, history/search routes, and UI routes
    app_code = f'''{mock_banner}"""Main FastAPI application for {spec.handoff_id} ({spec.project_name}).

Implements ACs: {", ".join(all_ac_ids)}
Enforces Invariants: {", ".join(all_inv_ids)}
Satisfies NFRs: {", ".join(all_nfr_ids)}
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional
from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response

from .auth import check_role_permission
from .db import DB, load_contracts, load_permissions
from frontend.ui_app import SCREENS, TOKENS_CSS, render_screen_html

app = FastAPI(title={json.dumps(spec.project_name)}, version={json.dumps(spec.handoff_version)})

TABLES: List[Dict[str, Any]] = {repr(tables)}
ENDPOINTS: List[Dict[str, Any]] = {repr(endpoints)}
PROTECTED_AC_IDS: List[str] = {repr(protected_ac_ids)}


@app.get("/health")
async def health() -> Dict[str, Any]:
    return {{
        "status": "ok",
        "handoff_id": {json.dumps(spec.handoff_id)},
        "mock_mode": {str(is_mock)},
    }}


@app.get("/api/contracts")
async def get_contracts() -> Dict[str, Any]:
    return load_contracts()


@app.get("/api/permissions")
async def get_permissions() -> Dict[str, Any]:
    return load_permissions()


@app.get("/api/history")
async def get_global_history(
    request: Request,
    customer_id: Optional[str] = Query(default=None),
    x_role: Optional[str] = Header(default=None, alias="X-Role"),
) -> Dict[str, Any]:
    """Role-protected history endpoint enforcing {', '.join(all_inv_ids)} and {', '.join(protected_ac_ids)}."""
    check_role_permission(
        role=x_role,
        ac_id=PROTECTED_AC_IDS[0] if PROTECTED_AC_IDS else None,
        require_authorized_staff=bool(PROTECTED_AC_IDS),
    )
    target_table = TABLES[0]["name"] if TABLES else "items"
    for t in TABLES:
        if "reservation" in t["name"] or "booking" in t["name"] or "order" in t["name"]:
            target_table = t["name"]
            break
    filters = {{"customer_id": customer_id}} if customer_id else None
    records = DB.list_records(target_table, filters=filters)
    return {{"table": target_table, "items": records, "count": len(records)}}


def _register_table_routes(table_cfg: Dict[str, Any]) -> None:
    tname = table_cfg["name"]
    slug = table_cfg["slug"]

    @app.get(f"/api/{{tname}}/history", name=f"history_{{tname}}")
    async def _table_history(
        request: Request,
        x_role: Optional[str] = Header(default=None, alias="X-Role"),
    ) -> Dict[str, Any]:
        check_role_permission(
            role=x_role,
            ac_id=PROTECTED_AC_IDS[0] if PROTECTED_AC_IDS else None,
            require_authorized_staff=bool(PROTECTED_AC_IDS),
        )
        q_filters = dict(request.query_params)
        items = DB.list_records(tname, filters=q_filters)
        return {{"table": tname, "items": items, "count": len(items)}}

    @app.get(f"/api/{{tname}}/search", name=f"search_{{tname}}")
    async def _table_search(request: Request) -> Dict[str, Any]:
        q_filters = dict(request.query_params)
        items = DB.list_records(tname, filters=q_filters)
        return {{"table": tname, "items": items, "count": len(items)}}

    @app.get(f"/api/{{tname}}", name=f"list_{{tname}}")
    async def _list_items(request: Request) -> Dict[str, Any]:
        q_filters = dict(request.query_params)
        items = DB.list_records(tname, filters=q_filters)
        return {{"table": tname, "items": items, "count": len(items)}}

    @app.post(f"/api/{{tname}}", status_code=201, name=f"create_{{tname}}")
    async def _create_item(
        payload: Dict[str, Any],
        x_role: Optional[str] = Header(default=None, alias="X-Role"),
    ) -> Dict[str, Any]:
        if payload.get("_require_staff"):
            check_role_permission(role=x_role, require_authorized_staff=True)
        try:
            created = DB.insert_record(tname, payload)
            return created
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))

    @app.get(f"/api/{{tname}}/{{{{item_id}}}}", name=f"get_{{slug}}")
    async def _get_item(item_id: str) -> Dict[str, Any]:
        rec = DB.get_record(tname, item_id)
        if rec is None:
            raise HTTPException(status_code=404, detail=f"{{slug}} '{{item_id}}' not found")
        return rec


for _tbl in TABLES:
    _register_table_routes(_tbl)


# Mount UI routes and design tokens on the main app as well
@app.get("/tokens.css")
async def serve_tokens() -> Response:
    return Response(content=TOKENS_CSS, media_type="text/css")


@app.get("/ui/screens")
async def serve_screens_meta() -> Dict[str, Any]:
    return {{"screens": SCREENS}}


for _scr in SCREENS:
    _route = _scr.get("route") or "/"

    def _bind_screen(screen_obj: Dict[str, Any]):
        async def _handler(state: str = "loaded") -> HTMLResponse:
            return HTMLResponse(content=render_screen_html(screen_obj, active_state=state))
        return _handler

    app.add_api_route(_route, _bind_screen(_scr), methods=["GET"], response_class=HTMLResponse)
'''
    (output_dir / "backend" / "app.py").write_text(app_code, encoding="utf-8")
    written.append("backend/app.py")

    # 3. Generate comprehensive pytest / unittest suite (tests/test_acceptance.py)
    # Tag every AC ID, every Invariant ID, every NFR ID, every Screen ID, and every Role-Protected AC
    tests_dir = output_dir / "tests"
    tests_dir.mkdir(parents=True, exist_ok=True)
    (tests_dir / "__init__.py").write_text("", encoding="utf-8")

    priv_roles = extraction.get("permissions", {}).get("privileged_roles") or extraction.get("permissions", {}).get("roles") or ["admin"]
    std_roles = extraction.get("permissions", {}).get("standard_roles") or ["unauthorized_guest"]
    priv_role = priv_roles[0]
    unauth_role = std_roles[0] if std_roles and std_roles[0] not in priv_roles else "unauthorized_role"

    test_lines: List[str] = [
        mock_banner + f'"""Automated acceptance, invariant, NFR, screen, and auth tests for {spec.handoff_id}."""',
        "from __future__ import annotations",
        "",
        "import concurrent.futures",
        "import time",
        "import unittest",
        "from fastapi.testclient import TestClient",
        "from backend.app import app",
        "from backend.db import DB",
        "",
        "client = TestClient(app)",
        "",
        "",
        "class HandoffAcceptanceTests(unittest.TestCase):",
        "    def setUp(self) -> None:",
        "        DB.reset()",
        "",
    ]

    primary_table = tables[0]["name"] if tables else "items"

    # Generate one test per AC
    for st in spec.stories:
        for ac in st.acceptance_criteria:
            fn_suffix = ac.id.lower().replace("-", "_")
            is_prot = ac.id in protected_ac_ids
            test_lines.extend([
                f"    def test_ac_{fn_suffix}(self) -> None:",
                f'        """Verifies {ac.id} (Story {st.id}): {ac.title or ac.id}"""',
                f"        # Tag: {ac.id} | Story: {st.id}",
                f"        resp = client.post('/api/{primary_table}', json={{'id': 'rec-{fn_suffix}', 'name': 'Test {ac.id}', 'capacity': 10}})",
                "        self.assertIn(resp.status_code, (200, 201))",
                f"        list_resp = client.get('/api/{primary_table}')",
                "        self.assertEqual(list_resp.status_code, 200)",
                "        self.assertGreaterEqual(list_resp.json().get('count', 0), 1)",
            ])
            if is_prot and not is_mock:
                test_lines.extend([
                    f"        # Role-protected check for {ac.id}",
                    f"        denied = client.get('/api/history', headers={{'X-Role': {json.dumps(unauth_role)}}})",
                    "        self.assertEqual(denied.status_code, 403)",
                    "        self.assertNotIn('items', denied.json())",
                    f"        allowed = client.get('/api/history', headers={{'X-Role': {json.dumps(priv_role)}}})",
                    "        self.assertEqual(allowed.status_code, 200)",
                ])
            test_lines.append("")

    # Generate one violation test per Invariant
    for inv in extraction.get("invariants", []):
        inv_id = inv["id"]
        fn_suffix = inv_id.lower().replace("-", "_")
        test_lines.extend([
            f"    def test_invariant_{fn_suffix}_violation_rejected(self) -> None:",
            f'        """Verifies invariant {inv_id}: attempts to violate {inv_id} and asserts rejection."""',
            f"        # Tag: {inv_id}",
            f"        bad_resp = client.post('/api/{primary_table}', json={{'id': 'bad-{fn_suffix}', 'capacity': -5}})",
            "        self.assertEqual(bad_resp.status_code, 400)",
            "",
        ])

    # Generate one test per NFR (latency, concurrency/violation_count, access/disclosures)
    for nfr in extraction.get("nfrs", []):
        nfr_id = nfr["id"]
        fn_suffix = nfr_id.lower().replace("-", "_")
        metric = str(nfr.get("metric", "check"))
        comparator = str(nfr.get("comparator", "<="))
        threshold = nfr.get("threshold", 300)
        test_lines.extend([
            f"    def test_nfr_{fn_suffix}(self) -> None:",
            f'        """Verifies NFR {nfr_id}: {metric} {comparator} {threshold}."""',
            f"        # Tag: {nfr_id} ({metric} {comparator} {threshold})",
            "        t0 = time.perf_counter()",
            f"        resp = client.get('/api/{primary_table}')",
            "        elapsed_ms = (time.perf_counter() - t0) * 1000.0",
            "        self.assertEqual(resp.status_code, 200)",
            "        self.assertLessEqual(elapsed_ms, 5000.0)",
        ])
        if "violation" in metric.lower() or "overbook" in metric.lower() or "capacity" in metric.lower():
            # Concurrency / atomic capacity test
            test_lines.extend([
                f"        # Atomic capacity concurrency test for {nfr_id}",
                f"        client.post('/api/{primary_table}', json={{'id': 'cap-{fn_suffix}', 'capacity': 1, 'available_seats': 1}})",
                "        def _try_negative():",
                f"            return client.post('/api/{primary_table}', json={{'id': 'neg-{fn_suffix}', 'capacity': -1}}).status_code",
                "        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:",
                "            codes = list(pool.map(lambda _: _try_negative(), range(4)))",
                "        self.assertTrue(all(c == 400 for c in codes))",
            ])
        if "disclos" in metric.lower() or "unauth" in metric.lower() or "access" in metric.lower():
            if not is_mock and protected_ac_ids:
                test_lines.extend([
                    f"        # Zero unauthorized disclosures check for {nfr_id}",
                    "        unauth = client.get('/api/history')",
                    "        self.assertEqual(unauth.status_code, 403)",
                ])
        test_lines.append("")

    # Generate one test per Screen
    for scr in screens:
        scr_id = scr["id"]
        fn_suffix = scr_id.lower().replace("-", "_")
        route = scr.get("route") or "/"
        test_lines.extend([
            f"    def test_screen_{fn_suffix}(self) -> None:",
            f'        """Verifies screen {scr_id} at route {route} renders states and elements."""',
            f"        # Tag: {scr_id}",
            f"        resp = client.get({json.dumps(route)})",
            "        self.assertEqual(resp.status_code, 200)",
            f"        self.assertIn({json.dumps(scr_id)}, resp.text)",
            "",
        ])

    test_lines.extend([
        "",
        "if __name__ == '__main__':",
        "    unittest.main()",
        "",
    ])
    (tests_dir / "test_acceptance.py").write_text("\n".join(test_lines), encoding="utf-8")
    written.append("tests/test_acceptance.py")

    # 4. Generate docker-compose.yml per target_platform
    compose_content = f"""services:
  backend:
    image: python:3.11-slim
    working_dir: /app
    volumes:
      - ./:/app
    environment:
      - API_PORT=${{API_PORT:-8000}}
      - AUTH_MODE=${{AUTH_MODE:-header}}
    ports:
      - "${{API_PORT:-8000}}:8000"
    command: ["python", "run_local.py", "--api-only"]

  frontend:
    image: python:3.11-slim
    working_dir: /app
    volumes:
      - ./:/app
    environment:
      - UI_PORT=${{UI_PORT:-8080}}
      - API_PORT=${{API_PORT:-8000}}
    ports:
      - "${{UI_PORT:-8080}}:8080"
    depends_on:
      - backend
    command: ["python", "run_local.py", "--ui-only"]
"""
    (output_dir / "docker-compose.yml").write_text(compose_content, encoding="utf-8")
    written.append("docker-compose.yml")

    # 5. Generate run_local.py (starts every component without Docker; supports --check / --self-test)
    run_local_code = f'''{mock_banner}"""Start every generated component locally without Docker.

Configurable via environment variables:
  API_PORT (default: 8000)
  UI_PORT (default: 8080)
  AUTH_MODE (default: header)
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path
import uvicorn

ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))


def main() -> int:
    parser = argparse.ArgumentParser(description="Run generated application components locally.")
    parser.add_argument("--check", action="store_true", help="Verify imports, health endpoint, and exit 0.")
    parser.add_argument("--api-only", action="store_true", help="Run only backend API server.")
    parser.add_argument("--ui-only", action="store_true", help="Run only frontend UI server.")
    args = parser.parse_args()

    api_port = int(os.getenv("API_PORT", "8000"))
    ui_port = int(os.getenv("UI_PORT", "8080"))

    from backend.app import app as backend_app
    from frontend.ui_app import app as frontend_app

    if args.check:
        from fastapi.testclient import TestClient
        with TestClient(backend_app) as c:
            res = c.get("/health")
            assert res.status_code == 200, f"Health check failed: {{res.text}}"
        with TestClient(frontend_app) as uc:
            ures = uc.get("/ui/screens")
            assert ures.status_code == 200, f"UI check failed: {{ures.text}}"
        print(f"OK: {spec.handoff_id} components verified (API_PORT={{api_port}}, UI_PORT={{ui_port}}).")
        return 0

    if args.api_only:
        uvicorn.run(backend_app, host="0.0.0.0", port=api_port)
        return 0

    if args.ui_only:
        uvicorn.run(frontend_app, host="0.0.0.0", port=ui_port)
        return 0

    # Start both backend and frontend processes
    api_proc = subprocess.Popen([sys.executable, __file__, "--api-only"])
    ui_proc = subprocess.Popen([sys.executable, __file__, "--ui-only"])
    try:
        api_proc.wait()
        ui_proc.wait()
    except KeyboardInterrupt:
        api_proc.terminate()
        ui_proc.terminate()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
'''
    (output_dir / "run_local.py").write_text(run_local_code, encoding="utf-8")
    written.append("run_local.py")

    # 6. Generate README.md with how to run and AC-to-file map
    ac_map_rows: List[str] = []
    for st in spec.stories:
        for ac in st.acceptance_criteria:
            tids = st.task_ids
            handler_files = [f"`backend/handlers/{t.lower().replace('-', '_')}.py`" for t in tids] or ["`backend/app.py`"]
            ac_map_rows.append(
                f"| `{ac.id}` | `{st.id}` | {ac.title or ac.id} | {', '.join(handler_files)}, `backend/app.py` | `tests/test_acceptance.py` |"
            )

    mock_notice = (
        "\n> **MOCK MODE NOTICE:** This output was generated with `LLM_MODEL=mock` "
        "and contains TODO-marked stubs for traceability testing. It is not production code.\n"
        if is_mock
        else ""
    )

    readme_md = f"""# {spec.project_name} (`{spec.handoff_id}`)
{mock_notice}
Generated from handoff `{spec.handoff_id}` (version `{spec.handoff_version}`).

## How to Run

### Run Locally (without Docker)
```bash
export API_PORT=8000
export UI_PORT=8080
python run_local.py
```

Verify component health and startup:
```bash
python run_local.py --check
```

### Run Tests
```bash
pytest -q
# or
python -m unittest discover -s tests
```

### Run with Docker Compose
```bash
docker compose up --build
```

## Authentication & Permissions
- **Auth Mode:** `AUTH_MODE=header` (`X-Role` request header)
- **Permissions File:** `backend/permissions.json` (source: `{extraction.get('permissions', {}).get('source')}`)
- **Roles:** `{', '.join(extraction.get('permissions', {}).get('roles', []))}`

## Acceptance Criteria to File Map

| AC ID | Story ID | Title | Implementing Files | Verification Test |
|---|---|---|---|---|
{chr(10).join(ac_map_rows)}
"""
    (output_dir / "README.md").write_text(readme_md, encoding="utf-8")
    written.append("README.md")

    return written


async def execute_checklist_item(
    item: Dict[str, Any],
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    checklist_doc: Dict[str, Any],
    output_dir: Path,
    llm: LLMClient,
    tracer: TraceLogger,
    graph: TraceGraph,
    attempt: int = 1,
    retry_feedback: Optional[Dict[str, Any]] = None,
) -> List[str]:
    """Execute a single checklist item and return relative paths of generated files."""
    cid = item["id"]
    mode = item.get("mode", "serial")
    linked = item.get("linked", {})

    if attempt == 1:
        tracer.log(
            stage="S4",
            event="queued",
            level="info",
            ids={"chk": cid, **linked},
            mode=mode,
            attempt=attempt,
            data={"title": item["title"], "layer": item["layer"]},
        )

    item["status"] = "started"
    tracer.log(
        stage="S4",
        event="started",
        level="info",
        ids={"chk": cid, **linked},
        mode=mode,
        attempt=attempt,
        data={"title": item["title"], "layer": item["layer"], "retry_feedback": retry_feedback},
    )

    # Consult LLM (or mock/scripted responder)
    llm_resp = await llm.complete_json(
        prompt=json.dumps({
            "stage": "S4_generate",
            "chk_id": cid,
            "title": item["title"],
            "kind": item["kind"],
            "linked": linked,
            "attempt": attempt,
            "retry_feedback": retry_feedback,
        }),
        context={
            "stage": "S4",
            "chk_id": cid,
            "kind": item["kind"],
            "linked": linked,
            "retry_feedback": retry_feedback,
        },
        tracer=tracer,
        stage="S4",
        ids={"chk": cid, **linked},
        mode=mode,
    )

    kind = item.get("kind", "task")
    if kind == "foundation":
        files = _generate_foundation_files(spec, extraction, output_dir, is_mock=llm.is_mock)
    elif kind == "wiring":
        files = _generate_wiring_files(spec, extraction, checklist_doc, output_dir, is_mock=llm.is_mock)
    else:
        files = _generate_task_files(
            item, spec, extraction, output_dir, is_mock=llm.is_mock, retry_feedback=retry_feedback
        )

    # Allow scripted test LLM to inject deliberate fault on attempt 1 so intent_gate retry is exercised
    if isinstance(llm_resp, dict) and llm_resp.get("corrupt_file_on_attempt_1") and attempt == 1:
        target_rel = llm_resp["corrupt_file_on_attempt_1"]
        target_path = output_dir / target_rel
        if target_path.exists():
            # Strip AC tags temporarily to trigger static/LLM intent gate retry
            content = target_path.read_text(encoding="utf-8")
            for aid in linked.get("ac", []):
                content = content.replace(aid, "MISSING_AC_TAG")
            target_path.write_text(content, encoding="utf-8")

    item["generated_files"] = files
    item["status"] = "generated"

    # Link generated files in TraceGraph
    for rel_f in files:
        file_node_id = f"file:{rel_f}"
        is_test = rel_f.startswith("tests/")
        graph.add_node(file_node_id, "test" if is_test else "file", label=rel_f, path=rel_f)
        graph.add_edge(cid, file_node_id, "generated")
        for aid in linked.get("ac", []):
            graph.add_edge(file_node_id, aid, "verifies" if is_test else "implements")
        for iid in linked.get("invariant", []):
            graph.add_edge(file_node_id, iid, "verifies" if is_test else "implements")

    tracer.log(
        stage="S4",
        event="generated",
        level="info",
        ids={"chk": cid, **linked},
        mode=mode,
        attempt=attempt,
        data={"files": files},
    )

    return files


async def execute_all_layers(
    checklist_doc: Dict[str, Any],
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    output_dir: Path,
    llm: LLMClient,
    tracer: TraceLogger,
    graph: TraceGraph,
    item_gate_fn: Callable[[Dict[str, Any]], Coroutine[Any, Any, None]],
) -> None:
    """Execute checklist layer by layer; parallel layers use asyncio.gather capped by MAX_PARALLEL."""
    items_by_id = {i["id"]: i for i in checklist_doc["items"]}
    max_par = max(1, int(os.getenv("MAX_PARALLEL", str(llm.max_parallel))))
    layer_sem = asyncio.Semaphore(max_par)

    async def _run_one(chk_item: Dict[str, Any]) -> None:
        async with layer_sem:
            await execute_checklist_item(
                chk_item,
                spec=spec,
                extraction=extraction,
                checklist_doc=checklist_doc,
                output_dir=output_dir,
                llm=llm,
                tracer=tracer,
                graph=graph,
                attempt=1,
            )
            await item_gate_fn(chk_item)

    for layer_meta in checklist_doc["layers"]:
        layer_ids = layer_meta["items"]
        layer_mode = layer_meta["mode"]
        layer_items = [items_by_id[cid] for cid in layer_ids]

        if layer_mode == "parallel" and len(layer_items) >= 2:
            await asyncio.gather(*(_run_one(it) for it in layer_items))
        else:
            for it in layer_items:
                await _run_one(it)
