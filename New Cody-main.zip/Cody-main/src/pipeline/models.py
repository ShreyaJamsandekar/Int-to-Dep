"""Pydantic handoff schema and cross-reference validation (Stage S0).

Nothing domain-specific lives here. Any domain handoff JSON following the
handoff v1.x schema is parsed and cross-checked generically.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from pydantic import BaseModel, Field


class BaseHandoffModel(BaseModel):
    """Base model allowing extra fields so arbitrary domain extensions are preserved."""
    class Config:
        extra = "allow"


class GlossaryTermModel(BaseHandoffModel):
    id: Optional[str] = None
    term: str
    definition: Optional[str] = ""
    attributes: Optional[List[Any]] = Field(default_factory=list)
    entity_type: Optional[str] = "entity"


class InvariantModel(BaseHandoffModel):
    id: str
    title: Optional[str] = ""
    description: Optional[str] = ""
    rule: Optional[str] = ""
    applies_to_stories: List[str] = Field(default_factory=list)
    entities: List[str] = Field(default_factory=list)


class AcceptanceCriterionModel(BaseHandoffModel):
    id: str
    title: Optional[str] = ""
    description: Optional[str] = ""
    given: Optional[str] = ""
    when: Optional[str] = ""
    then: Optional[str] = ""
    gherkin: Optional[str] = ""
    contract_ref: Optional[str] = None
    role_protected: Optional[bool] = None
    allowed_roles: Optional[List[str]] = None

    def full_text(self) -> str:
        parts = [
            self.title or "",
            self.description or "",
            self.gherkin or "",
            f"Given {self.given}" if self.given else "",
            f"When {self.when}" if self.when else "",
            f"Then {self.then}" if self.then else "",
        ]
        return " ".join(p for p in parts if p).strip()


class TaskItemModel(BaseHandoffModel):
    id: str
    title: Optional[str] = ""
    description: Optional[str] = ""
    story_id: Optional[str] = None
    component_id: Optional[str] = None
    ac_ids: List[str] = Field(default_factory=list)
    depends_on: List[str] = Field(default_factory=list)
    type: Optional[str] = None


class StoryModel(BaseHandoffModel):
    id: str
    title: str
    description: Optional[str] = ""
    as_a: Optional[str] = ""
    i_want: Optional[str] = ""
    so_that: Optional[str] = ""
    acceptance_criteria: List[AcceptanceCriterionModel] = Field(default_factory=list)
    task_ids: List[str] = Field(default_factory=list)
    nfr_ids: List[str] = Field(default_factory=list)
    invariant_ids: List[str] = Field(default_factory=list)
    screen_ids: List[str] = Field(default_factory=list)


class NFRModel(BaseHandoffModel):
    id: str
    category: Optional[str] = "general"
    title: Optional[str] = ""
    description: Optional[str] = ""
    metric: str = "check"
    comparator: str = "=="
    threshold: Union[float, int, str] = 0
    unit: Optional[str] = ""
    assumption: bool = False
    applies_to_stories: List[str] = Field(default_factory=list)


class ADRModel(BaseHandoffModel):
    id: str
    title: str
    status: Optional[str] = "accepted"
    context: Optional[str] = ""
    decision: Optional[str] = ""
    consequences: Optional[str] = ""


class ComponentModel(BaseHandoffModel):
    id: str
    name: str
    type: Optional[str] = "service"
    description: Optional[str] = ""
    technology_stack: Union[str, List[str], Dict[str, Any]] = "python"
    responsibilities: List[str] = Field(default_factory=list)
    linked_task_ids: List[str] = Field(default_factory=list)
    traceability: Optional[Dict[str, Any]] = Field(default_factory=dict)
    satisfies_nfrs: List[str] = Field(default_factory=list)
    adr_ids: List[str] = Field(default_factory=list)
    interfaces: List[Any] = Field(default_factory=list)

    def get_all_linked_tasks(self) -> Set[str]:
        tasks = set(self.linked_task_ids or [])
        if isinstance(self.traceability, dict):
            for key in ("task_ids", "linked_task_ids", "tasks"):
                val = self.traceability.get(key)
                if isinstance(val, list):
                    tasks.update(str(x) for x in val)
        return tasks

    def stack_summary(self) -> str:
        if isinstance(self.technology_stack, str):
            return self.technology_stack
        if isinstance(self.technology_stack, list):
            return ", ".join(str(x) for x in self.technology_stack)
        if isinstance(self.technology_stack, dict):
            return ", ".join(f"{k}: {v}" for k, v in self.technology_stack.items())
        return str(self.technology_stack)


class DependencyEdgeModel(BaseHandoffModel):
    id: Optional[str] = None
    source: Optional[str] = None
    target: Optional[str] = None
    from_component: Optional[str] = None
    to_component: Optional[str] = None
    depends_on: Optional[str] = None
    type: Optional[str] = "depends_on"
    description: Optional[str] = ""

    def endpoints(self) -> Tuple[Optional[str], Optional[str]]:
        src = self.source or self.from_component or getattr(self, "from", None)
        tgt = self.target or self.to_component or self.depends_on or getattr(self, "to", None)
        return src, tgt


class ScreenModel(BaseHandoffModel):
    id: str
    name: str
    route: str = "/"
    description: Optional[str] = ""
    story_ids: List[str] = Field(default_factory=list)
    ac_ids: List[str] = Field(default_factory=list)
    states: List[str] = Field(default_factory=list)
    elements: List[Any] = Field(default_factory=list)
    roles: List[str] = Field(default_factory=list)


class UIModel(BaseHandoffModel):
    design_system: Optional[Union[str, Dict[str, Any]]] = "HTML5 / CSS Design Tokens"
    roles: List[Any] = Field(default_factory=list)
    screens: List[ScreenModel] = Field(default_factory=list)
    permissions: Optional[Dict[str, Any]] = None

    def role_names(self) -> List[str]:
        names: List[str] = []
        for r in self.roles:
            if isinstance(r, str):
                names.append(r)
            elif isinstance(r, dict):
                name = r.get("name") or r.get("role") or r.get("id")
                if name:
                    names.append(str(name))
        return names


class ValidationIssue(BaseModel):
    level: str  # "error" | "warning"
    code: str
    message: str
    ids: Dict[str, Any] = Field(default_factory=dict)


class ValidationResult(BaseModel):
    valid: bool
    errors: List[ValidationIssue] = Field(default_factory=list)
    warnings: List[ValidationIssue] = Field(default_factory=list)


class HandoffSpec(BaseHandoffModel):
    """Normalized representation of a handoff JSON after parsing."""
    handoff_id: str
    handoff_version: str
    project_name: str = "Generated Application"
    domain: str = "general"
    description: str = ""
    prd_sha256: Optional[str] = None
    target_platform: Union[str, Dict[str, Any], List[Any]] = "docker-compose"
    glossary: List[GlossaryTermModel] = Field(default_factory=list)
    invariants: List[InvariantModel] = Field(default_factory=list)
    stories: List[StoryModel] = Field(default_factory=list)
    tasks: List[TaskItemModel] = Field(default_factory=list)
    nfrs: List[NFRModel] = Field(default_factory=list)
    adrs: List[ADRModel] = Field(default_factory=list)
    components: List[ComponentModel] = Field(default_factory=list)
    dependencies: List[DependencyEdgeModel] = Field(default_factory=list)
    contracts: List[Dict[str, Any]] = Field(default_factory=list)
    ui: UIModel = Field(default_factory=UIModel)
    permissions: Optional[Dict[str, Any]] = None
    raw: Dict[str, Any] = Field(default_factory=dict)


def _extract_list(data: Dict[str, Any], *keys: str) -> List[Any]:
    for k in keys:
        parts = k.split(".")
        curr: Any = data
        for p in parts:
            if isinstance(curr, dict) and p in curr:
                curr = curr[p]
            else:
                curr = None
                break
        if isinstance(curr, list):
            return curr
    return []


def parse_handoff(raw_data: Dict[str, Any]) -> HandoffSpec:
    """Normalize flexible v1 handoff JSON layouts into a unified HandoffSpec."""
    if not isinstance(raw_data, dict):
        raise ValueError("Handoff payload must be a JSON object")

    meta = raw_data.get("metadata") or raw_data.get("meta") or {}
    handoff_id = (
        raw_data.get("handoff_id")
        or raw_data.get("id")
        or meta.get("handoff_id")
        or meta.get("id")
        or ""
    )
    handoff_version = str(
        raw_data.get("handoff_version")
        or raw_data.get("version")
        or meta.get("handoff_version")
        or meta.get("version")
        or ""
    )
    project_name = (
        raw_data.get("project_name")
        or raw_data.get("name")
        or raw_data.get("title")
        or meta.get("project_name")
        or meta.get("name")
        or (handoff_id or "Generated Application")
    )
    domain = (
        raw_data.get("domain")
        or meta.get("domain")
        or "general"
    )
    description = (
        raw_data.get("description")
        or raw_data.get("summary")
        or meta.get("description")
        or ""
    )
    prd_sha256 = (
        raw_data.get("prd_sha256")
        or meta.get("prd_sha256")
        or (raw_data.get("source") or {}).get("prd_sha256")
        or (raw_data.get("provenance") or {}).get("prd_sha256")
    )
    target_platform = (
        raw_data.get("target_platform")
        or (raw_data.get("architecture") or {}).get("target_platform")
        or (raw_data.get("deployment") or {}).get("target_platform")
        or "docker-compose"
    )

    # Glossary / Entities
    raw_glossary = _extract_list(
        raw_data,
        "glossary",
        "domain_model.glossary",
        "domain.glossary",
        "entities",
        "domain_model.entities",
    )
    glossary: List[GlossaryTermModel] = []
    for idx, item in enumerate(raw_glossary):
        if isinstance(item, str):
            glossary.append(GlossaryTermModel(id=f"GLS-{idx+1:03d}", term=item))
        elif isinstance(item, dict):
            term_name = item.get("term") or item.get("name") or item.get("entity") or f"Entity_{idx+1}"
            glossary.append(GlossaryTermModel(
                id=item.get("id") or f"GLS-{idx+1:03d}",
                term=term_name,
                definition=item.get("definition") or item.get("description") or "",
                attributes=item.get("attributes") or item.get("fields") or [],
                **{k: v for k, v in item.items() if k not in ("id", "term", "definition", "attributes")}
            ))

    # Invariants
    raw_invariants = _extract_list(
        raw_data,
        "invariants",
        "domain_model.invariants",
        "business_rules",
        "requirements.invariants",
    )
    invariants = [InvariantModel(**inv) if isinstance(inv, dict) else InvariantModel(id=str(inv)) for inv in raw_invariants]

    # Stories & ACs
    raw_stories = _extract_list(
        raw_data,
        "stories",
        "user_stories",
        "requirements.stories",
        "requirements.user_stories",
        "backlog.stories",
    )
    stories: List[StoryModel] = []
    for st_item in raw_stories:
        if not isinstance(st_item, dict):
            continue
        st_copy = dict(st_item)
        raw_acs = st_copy.pop("acceptance_criteria", None) or st_copy.pop("acs", None) or []
        parsed_acs: List[AcceptanceCriterionModel] = []
        for ac in raw_acs:
            if isinstance(ac, dict):
                ac_copy = dict(ac)
                if "id" not in ac_copy and "ac_id" in ac_copy:
                    ac_copy["id"] = ac_copy.pop("ac_id")
                parsed_acs.append(AcceptanceCriterionModel(**ac_copy))
        if "id" not in st_copy and "story_id" in st_copy:
            st_copy["id"] = st_copy.pop("story_id")
        if "title" not in st_copy:
            st_copy["title"] = st_copy.get("name") or st_copy.get("id") or "Untitled Story"
        stories.append(StoryModel(acceptance_criteria=parsed_acs, **st_copy))

    # Tasks
    raw_tasks = _extract_list(
        raw_data,
        "tasks",
        "engineering_tasks",
        "backlog.tasks",
        "work_items",
        "implementation.tasks",
    )
    tasks: List[TaskItemModel] = []
    seen_task_ids: Set[str] = set()
    for t in raw_tasks:
        if isinstance(t, dict):
            t_copy = dict(t)
            if "id" not in t_copy and "task_id" in t_copy:
                t_copy["id"] = t_copy.pop("task_id")
            ti = TaskItemModel(**t_copy)
            tasks.append(ti)
            seen_task_ids.add(ti.id)

    # Also collect inline tasks from stories if tasks list was not top-level
    for st in stories:
        inline_tasks = getattr(st, "tasks", None)
        if isinstance(inline_tasks, list):
            for t in inline_tasks:
                if isinstance(t, dict):
                    t_copy = dict(t)
                    if "id" not in t_copy and "task_id" in t_copy:
                        t_copy["id"] = t_copy.pop("task_id")
                    t_copy.setdefault("story_id", st.id)
                    if t_copy.get("id") not in seen_task_ids:
                        ti = TaskItemModel(**t_copy)
                        tasks.append(ti)
                        seen_task_ids.add(ti.id)
                    if t_copy.get("id") and t_copy["id"] not in st.task_ids:
                        st.task_ids.append(t_copy["id"])

    # NFRs
    raw_nfrs = _extract_list(
        raw_data,
        "nfrs",
        "non_functional_requirements",
        "requirements.nfrs",
        "quality_attributes",
    )
    nfrs: List[NFRModel] = []
    for n in raw_nfrs:
        if isinstance(n, dict):
            n_copy = dict(n)
            if "id" not in n_copy and "nfr_id" in n_copy:
                n_copy["id"] = n_copy.pop("nfr_id")
            nfrs.append(NFRModel(**n_copy))

    # ADRs
    raw_adrs = _extract_list(
        raw_data,
        "adrs",
        "architecture_decisions",
        "architecture.adrs",
        "architecture.decisions",
    )
    adrs: List[ADRModel] = []
    for a in raw_adrs:
        if isinstance(a, dict):
            a_copy = dict(a)
            if "id" not in a_copy and "adr_id" in a_copy:
                a_copy["id"] = a_copy.pop("adr_id")
            if "title" not in a_copy:
                a_copy["title"] = a_copy.get("name") or a_copy.get("id") or "ADR"
            adrs.append(ADRModel(**a_copy))

    # Components
    raw_components = _extract_list(
        raw_data,
        "components",
        "architecture.components",
        "system.components",
    )
    components: List[ComponentModel] = []
    for c in raw_components:
        if isinstance(c, dict):
            c_copy = dict(c)
            if "id" not in c_copy and "component_id" in c_copy:
                c_copy["id"] = c_copy.pop("component_id")
            if "name" not in c_copy:
                c_copy["name"] = c_copy.get("title") or c_copy.get("id") or "component"
            components.append(ComponentModel(**c_copy))

    # Dependencies / Relationships
    raw_deps = (
        _extract_list(raw_data, "dependencies", "architecture.dependencies")
        + _extract_list(raw_data, "relationships", "architecture.relationships")
    )
    dependencies: List[DependencyEdgeModel] = []
    for d in raw_deps:
        if isinstance(d, dict):
            dependencies.append(DependencyEdgeModel(**d))

    # Also inspect component-level depends_on / relationships
    for comp in components:
        comp_deps = getattr(comp, "depends_on", None) or getattr(comp, "dependencies", None) or []
        if isinstance(comp_deps, list):
            for target_id in comp_deps:
                if isinstance(target_id, str):
                    dependencies.append(
                        DependencyEdgeModel(source=comp.id, target=target_id, type="depends_on")
                    )
                elif isinstance(target_id, dict):
                    d_copy = dict(target_id)
                    d_copy.setdefault("source", comp.id)
                    dependencies.append(DependencyEdgeModel(**d_copy))

    # Contracts
    raw_contracts = _extract_list(
        raw_data,
        "contracts",
        "api_contracts",
        "architecture.contracts",
        "interfaces.contracts",
    )
    contracts = [c for c in raw_contracts if isinstance(c, dict)]

    # UI
    raw_ui = raw_data.get("ui") or raw_data.get("user_interface") or {}
    if not isinstance(raw_ui, dict):
        raw_ui = {}
    raw_screens = raw_ui.get("screens") or raw_data.get("screens") or []
    screens: List[ScreenModel] = []
    for s in raw_screens:
        if isinstance(s, dict):
            s_copy = dict(s)
            if "id" not in s_copy and "screen_id" in s_copy:
                s_copy["id"] = s_copy.pop("screen_id")
            if "name" not in s_copy:
                s_copy["name"] = s_copy.get("title") or s_copy.get("id") or "Screen"
            screens.append(ScreenModel(**s_copy))
    roles = raw_ui.get("roles") or raw_data.get("roles") or []
    design_system = (
        raw_ui.get("design_system")
        or raw_data.get("design_system")
        or "HTML5 / CSS Design Tokens"
    )
    ui_permissions = raw_ui.get("permissions") or raw_data.get("permissions")
    ui_model = UIModel(
        design_system=design_system,
        roles=roles,
        screens=screens,
        permissions=ui_permissions,
    )

    return HandoffSpec(
        handoff_id=str(handoff_id),
        handoff_version=str(handoff_version),
        project_name=str(project_name),
        domain=str(domain),
        description=str(description),
        prd_sha256=prd_sha256,
        target_platform=target_platform,
        glossary=glossary,
        invariants=invariants,
        stories=stories,
        tasks=tasks,
        nfrs=nfrs,
        adrs=adrs,
        components=components,
        dependencies=dependencies,
        contracts=contracts,
        ui=ui_model,
        permissions=ui_permissions,
        raw=raw_data,
    )


def validate_handoff(spec: HandoffSpec) -> ValidationResult:
    """Perform Stage S0 validation and cross-reference checks.

    Errors stop the run:
    - Missing/duplicate IDs; handoff_version major != 1.
    - A story's task_ids not matched by component linked_task_ids / traceability.
    - Screen story_ids / ac_ids that don't exist; invariants applies_to_stories that don't exist.
    - Component satisfies_nfrs / adr_ids that don't exist; dependency/relationship pointing to unknown components.

    Warnings are logged as assumptions and run continues:
    - contract_ref (e.g. CON-001) referenced but never defined -> API contract derived from ACs.
    - prd_sha256 is a placeholder value -> recorded, not verified.
    - Role permissions are not defined -> inferred from ACs/invariants/roles.
    """
    errors: List[ValidationIssue] = []
    warnings: List[ValidationIssue] = []

    # 1. Check handoff_id & handoff_version major == 1
    if not spec.handoff_id or not spec.handoff_id.strip():
        errors.append(ValidationIssue(
            level="error",
            code="MISSING_HANDOFF_ID",
            message="handoff_id is missing or empty.",
        ))

    version_str = (spec.handoff_version or "").strip().lstrip("vV")
    major_match = re.match(r"^(\d+)(?:\.\d+)*", version_str)
    if not major_match or int(major_match.group(1)) != 1:
        errors.append(ValidationIssue(
            level="error",
            code="INVALID_HANDOFF_VERSION",
            message=f"handoff_version '{spec.handoff_version}' major version must be 1.",
            ids={"handoff_version": spec.handoff_version},
        ))

    # 2. Check missing or duplicate IDs across collections
    def check_collection_ids(items: List[Any], label: str) -> Set[str]:
        seen: Set[str] = set()
        for item in items:
            item_id = getattr(item, "id", None)
            if not item_id or not str(item_id).strip():
                errors.append(ValidationIssue(
                    level="error",
                    code=f"MISSING_{label.upper()}_ID",
                    message=f"A {label} entry is missing its 'id'.",
                ))
                continue
            item_id_str = str(item_id).strip()
            if item_id_str in seen:
                errors.append(ValidationIssue(
                    level="error",
                    code=f"DUPLICATE_{label.upper()}_ID",
                    message=f"Duplicate {label} ID '{item_id_str}'.",
                    ids={label: item_id_str},
                ))
            seen.add(item_id_str)
        return seen

    story_ids = check_collection_ids(spec.stories, "story")
    inv_ids = check_collection_ids(spec.invariants, "invariant")
    nfr_ids = check_collection_ids(spec.nfrs, "nfr")
    adr_ids = check_collection_ids(spec.adrs, "adr")
    comp_ids = check_collection_ids(spec.components, "component")
    screen_ids = check_collection_ids(spec.ui.screens, "screen")
    task_ids_from_tasks = check_collection_ids(spec.tasks, "task")

    all_acs: List[AcceptanceCriterionModel] = []
    for st in spec.stories:
        all_acs.extend(st.acceptance_criteria)
    ac_ids = check_collection_ids(all_acs, "ac")

    # 3. Story task_ids matched by component linked_task_ids / traceability
    component_linked_tasks: Set[str] = set()
    for comp in spec.components:
        component_linked_tasks.update(comp.get_all_linked_tasks())

    for st in spec.stories:
        for tid in st.task_ids:
            if tid not in component_linked_tasks:
                errors.append(ValidationIssue(
                    level="error",
                    code="UNLINKED_STORY_TASK",
                    message=f"Story '{st.id}' references task '{tid}' which is not matched by any component linked_task_ids or traceability.",
                    ids={"story": st.id, "task": tid},
                ))

    # Synthesize TaskItemModels if stories/components define task_ids not listed in top-level tasks
    known_task_ids = set(task_ids_from_tasks)
    for st in spec.stories:
        for tid in st.task_ids:
            if tid not in known_task_ids:
                # Find component that links this task
                comp_for_task = next(
                    (c.id for c in spec.components if tid in c.get_all_linked_tasks()),
                    None,
                )
                spec.tasks.append(
                    TaskItemModel(
                        id=tid,
                        title=f"{st.title} ({tid})",
                        description=st.description or st.title,
                        story_id=st.id,
                        component_id=comp_for_task,
                        ac_ids=[ac.id for ac in st.acceptance_criteria],
                    )
                )
                known_task_ids.add(tid)

    # Ensure existing tasks have story_id / component_id / ac_ids populated if omitted
    for task_obj in spec.tasks:
        if not task_obj.story_id:
            for st in spec.stories:
                if task_obj.id in st.task_ids:
                    task_obj.story_id = st.id
                    if not task_obj.ac_ids:
                        task_obj.ac_ids = [ac.id for ac in st.acceptance_criteria]
                    break
        if not task_obj.component_id:
            for comp in spec.components:
                if task_obj.id in comp.get_all_linked_tasks():
                    task_obj.component_id = comp.id
                    break

    # 4. Screen story_ids / ac_ids existence
    for scr in spec.ui.screens:
        for sid in scr.story_ids:
            if sid not in story_ids:
                errors.append(ValidationIssue(
                    level="error",
                    code="UNKNOWN_SCREEN_STORY",
                    message=f"Screen '{scr.id}' references non-existent story_id '{sid}'.",
                    ids={"screen": scr.id, "story": sid},
                ))
        for aid in scr.ac_ids:
            if aid not in ac_ids:
                errors.append(ValidationIssue(
                    level="error",
                    code="UNKNOWN_SCREEN_AC",
                    message=f"Screen '{scr.id}' references non-existent ac_id '{aid}'.",
                    ids={"screen": scr.id, "ac": aid},
                ))

    # 5. Invariants applies_to_stories existence
    for inv in spec.invariants:
        for sid in inv.applies_to_stories:
            if sid not in story_ids:
                errors.append(ValidationIssue(
                    level="error",
                    code="UNKNOWN_INVARIANT_STORY",
                    message=f"Invariant '{inv.id}' applies_to_stories references non-existent story '{sid}'.",
                    ids={"invariant": inv.id, "story": sid},
                ))

    # 6. Component satisfies_nfrs / adr_ids existence
    for comp in spec.components:
        for nid in comp.satisfies_nfrs:
            if nid not in nfr_ids:
                errors.append(ValidationIssue(
                    level="error",
                    code="UNKNOWN_COMPONENT_NFR",
                    message=f"Component '{comp.id}' satisfies_nfrs references non-existent NFR '{nid}'.",
                    ids={"component": comp.id, "nfr": nid},
                ))
        for aid in comp.adr_ids:
            if aid not in adr_ids:
                errors.append(ValidationIssue(
                    level="error",
                    code="UNKNOWN_COMPONENT_ADR",
                    message=f"Component '{comp.id}' adr_ids references non-existent ADR '{aid}'.",
                    ids={"component": comp.id, "adr": aid},
                ))

    # 7. Dependency/relationship pointing to unknown components (or tasks)
    valid_dep_targets = comp_ids | known_task_ids
    for dep in spec.dependencies:
        src, tgt = dep.endpoints()
        if src and src not in valid_dep_targets:
            errors.append(ValidationIssue(
                level="error",
                code="UNKNOWN_DEPENDENCY_SOURCE",
                message=f"Dependency source '{src}' is not a known component or task.",
                ids={"source": src, "target": tgt},
            ))
        if tgt and tgt not in valid_dep_targets:
            errors.append(ValidationIssue(
                level="error",
                code="UNKNOWN_DEPENDENCY_TARGET",
                message=f"Dependency target '{tgt}' is not a known component or task.",
                ids={"source": src, "target": tgt},
            ))

    # 8. Warnings (logged as assumptions, run continues)
    # 8a. Undefined contract_ref (e.g. CON-001)
    defined_contracts: Set[str] = set()
    for c in spec.contracts:
        cid = c.get("id") or c.get("contract_id")
        if cid:
            defined_contracts.add(str(cid))

    referenced_contracts: Dict[str, List[str]] = {}
    for st in spec.stories:
        for ac in st.acceptance_criteria:
            cref = ac.contract_ref or getattr(ac, "contract_id", None)
            if cref and cref not in defined_contracts:
                referenced_contracts.setdefault(str(cref), []).append(ac.id)
    for comp in spec.components:
        for iface in comp.interfaces:
            if isinstance(iface, dict):
                cref = iface.get("contract_ref") or iface.get("contract_id")
                if cref and cref not in defined_contracts:
                    referenced_contracts.setdefault(str(cref), []).append(comp.id)

    for cref, refs in referenced_contracts.items():
        warnings.append(ValidationIssue(
            level="warning",
            code="UNDEFINED_CONTRACT_REF",
            message=f"contract_ref '{cref}' is referenced by {refs} but never defined in handoff -> API contract will be derived from the ACs.",
            ids={"contract_ref": cref, "referenced_by": refs},
        ))

    # 8b. prd_sha256 placeholder check
    if spec.prd_sha256:
        sha = str(spec.prd_sha256).strip()
        is_hex64 = bool(re.fullmatch(r"[0-9a-fA-F]{64}", sha)) and len(set(sha.lower())) > 4
        if not is_hex64 or "placeholder" in sha.lower() or "0000" in sha.lower() or "todo" in sha.lower():
            warnings.append(ValidationIssue(
                level="warning",
                code="PLACEHOLDER_PRD_SHA256",
                message=f"prd_sha256 '{sha}' is a placeholder value; recorded as assumption, not verified.",
                ids={"prd_sha256": sha},
            ))
    else:
        warnings.append(ValidationIssue(
            level="warning",
            code="MISSING_PRD_SHA256",
            message="prd_sha256 is not set; recorded, not verified.",
        ))

    # 8c. Role permissions check
    if not spec.permissions and not spec.ui.permissions:
        warnings.append(ValidationIssue(
            level="warning",
            code="UNDEFINED_ROLE_PERMISSIONS",
            message="Explicit role permissions are not defined in handoff; permissions will be inferred from ACs, invariants, screens, and roles (or loaded from permissions_override.json).",
            ids={"roles": spec.ui.role_names()},
        ))

    return ValidationResult(
        valid=(len(errors) == 0),
        errors=errors,
        warnings=warnings,
    )
