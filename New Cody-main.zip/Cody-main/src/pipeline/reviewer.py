"""Stage S7: Review Checklist & Automated Fix Loop.

Reads `config/review_checklist.yaml` (which holds only the fixed checks and the
templates used to derive the rest) and derives domain-agnostic checks from the handoff:
- Fixed:
  1. app imports
  2. pytest passes (or `skipped (mock)` in mock mode)
  3. docker-compose.yml parses
  4. no secrets in code
- Per AC: code exists and a test tags the AC ID.
- Per Invariant (INV): an enforcing code location exists and a test tries to violate it.
- Per NFR: its metric / comparator / threshold becomes a check. NFRs marked `assumption: true` are reported but non-blocking.
- Per Screen: its route exists and implements its listed states and elements.
- Per Role-Protected AC: a request without permission returns 403 and no protected data.

Loop:
  Failed checks -> targeted fix of only the affected files -> re-review.
  Max `MAX_REVIEW_ITERATIONS`.
  Every iteration logs the checks run, which passed, which were fixed.
  The final event logs `review_checklist_done: N/M passed` plus the list of failures left.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import yaml

from .executor import _generate_foundation_files, _generate_task_files, _generate_wiring_files
from .llm import LLMClient
from .models import HandoffSpec
from .tracing import TraceGraph, TraceLogger


def _load_review_config() -> Dict[str, Any]:
    candidates = [
        Path(__file__).resolve().parent.parent.parent / "config" / "review_checklist.yaml",
        Path("/app/config/review_checklist.yaml"),
        Path("config/review_checklist.yaml"),
    ]
    for c in candidates:
        if c.exists():
            return yaml.safe_load(c.read_text(encoding="utf-8")) or {}
    return {}


def build_review_checks(
    spec: HandoffSpec,
    extraction: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Derive all fixed and handoff-driven review checks using config/review_checklist.yaml."""
    cfg = _load_review_config()
    checks: List[Dict[str, Any]] = []

    for fc in cfg.get("fixed_checks", []):
        checks.append({
            "id": fc["id"],
            "title": fc["title"],
            "category": fc.get("category", "fixed"),
            "type": fc["type"],
            "blocking": bool(fc.get("blocking", True)),
            "linked": {},
        })

    templates = cfg.get("derived_templates", {})

    # 1. Per AC
    ac_tpl = templates.get("per_ac", {"id_pattern": "REV-AC-{ac_id}", "title_pattern": "AC {ac_id} implemented and tested"})
    for st in spec.stories:
        for ac in st.acceptance_criteria:
            checks.append({
                "id": ac_tpl["id_pattern"].format(ac_id=ac.id),
                "title": ac_tpl["title_pattern"].format(ac_id=ac.id),
                "category": "acceptance_criterion",
                "type": "per_ac",
                "blocking": True,
                "linked": {"ac": ac.id, "story": st.id},
            })

    # 2. Per Invariant
    inv_tpl = templates.get("per_invariant", {"id_pattern": "REV-INV-{inv_id}", "title_pattern": "Invariant {inv_id} enforced and tested"})
    for inv in extraction.get("invariants", []):
        iid = inv["id"]
        checks.append({
            "id": inv_tpl["id_pattern"].format(inv_id=iid),
            "title": inv_tpl["title_pattern"].format(inv_id=iid),
            "category": "invariant",
            "type": "per_invariant",
            "blocking": True,
            "linked": {"inv": iid},
        })

    # 3. Per NFR
    nfr_tpl = templates.get("per_nfr", {"id_pattern": "REV-NFR-{nfr_id}", "title_pattern": "NFR {nfr_id} ({metric} {comparator} {threshold}) verified"})
    for nfr in extraction.get("nfrs", []):
        nid = nfr["id"]
        is_assumption = bool(nfr.get("assumption", False))
        checks.append({
            "id": nfr_tpl["id_pattern"].format(nfr_id=nid),
            "title": nfr_tpl["title_pattern"].format(
                nfr_id=nid,
                metric=nfr.get("metric", "metric"),
                comparator=nfr.get("comparator", "<="),
                threshold=nfr.get("threshold", 0),
            ),
            "category": "nfr",
            "type": "per_nfr",
            "blocking": not is_assumption,
            "assumption": is_assumption,
            "nfr": nfr,
            "linked": {"nfr": nid},
        })

    # 4. Per Screen
    scr_tpl = templates.get("per_screen", {"id_pattern": "REV-SCR-{screen_id}", "title_pattern": "Screen {screen_id} ({route}) implements states and elements"})
    for scr in extraction.get("screens", []):
        scid = scr["id"]
        checks.append({
            "id": scr_tpl["id_pattern"].format(screen_id=scid),
            "title": scr_tpl["title_pattern"].format(screen_id=scid, route=scr.get("route", "/")),
            "category": "screen",
            "type": "per_screen",
            "blocking": True,
            "screen": scr,
            "linked": {"screen": scid},
        })

    # 5. Per Role-Protected AC
    auth_tpl = templates.get("per_role_protected_ac", {"id_pattern": "REV-AUTH-{ac_id}", "title_pattern": "Role-protected AC {ac_id} returns 403 without permission"})
    protected_ac_ids = extraction.get("permissions", {}).get("protected_ac_ids", [])
    for aid in protected_ac_ids:
        checks.append({
            "id": auth_tpl["id_pattern"].format(ac_id=aid),
            "title": auth_tpl["title_pattern"].format(ac_id=aid),
            "category": "auth",
            "type": "per_role_protected_ac",
            "blocking": True,
            "linked": {"ac": aid},
        })

    return checks


def _evaluate_single_check(
    chk: Dict[str, Any],
    output_dir: Path,
    is_mock: bool,
    extraction: Dict[str, Any],
) -> Tuple[str, str, List[str]]:
    """Return (status, evidence, affected_files) where status is 'passed', 'failed', 'skipped (mock)', or 'non_blocking_warning'."""
    ctype = chk["type"]

    # Collect text of generated files
    code_files: Dict[str, str] = {}
    test_files: Dict[str, str] = {}
    for p in output_dir.rglob("*"):
        if not p.is_file() or "__pycache__" in p.parts or p.suffix in (".pyc", ".pyo"):
            continue
        rel = p.relative_to(output_dir).as_posix()
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if rel.startswith("tests/"):
            test_files[rel] = txt
        else:
            code_files[rel] = txt

    if ctype == "app_imports":
        proc = subprocess.run(
            [sys.executable, "run_local.py", "--check"],
            cwd=str(output_dir),
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
        if proc.returncode == 0:
            return "passed", proc.stdout.strip() or "run_local.py --check succeeded", ["backend/app.py", "frontend/ui_app.py"]
        return "failed", f"Import/check failed: {proc.stderr.strip() or proc.stdout.strip()}", ["backend/app.py", "frontend/ui_app.py"]

    if ctype == "pytest_passes":
        if is_mock:
            return "skipped (mock)", "Mock mode (LLM_MODEL=mock): review tests logged as skipped (mock).", ["tests/test_acceptance.py"]
        pytest_bin = shutil.which("pytest")
        cmd = [pytest_bin, "-q"] if pytest_bin else [sys.executable, "-m", "unittest", "discover", "-s", "tests"]
        proc = subprocess.run(
            cmd,
            cwd=str(output_dir),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        if proc.returncode == 0:
            return "passed", "Automated test suite passed (0 failures).", ["tests/test_acceptance.py", "backend/app.py"]
        return "failed", f"Tests failed: {(proc.stdout + proc.stderr).strip()[:400]}", ["tests/test_acceptance.py", "backend/app.py"]

    if ctype == "docker_compose_parses":
        compose_path = output_dir / "docker-compose.yml"
        if not compose_path.exists():
            return "failed", "docker-compose.yml is missing.", ["docker-compose.yml"]
        try:
            parsed = yaml.safe_load(compose_path.read_text(encoding="utf-8"))
            if isinstance(parsed, dict) and "services" in parsed and parsed["services"]:
                return "passed", f"docker-compose.yml valid with services: {list(parsed['services'].keys())}", ["docker-compose.yml"]
            return "failed", "docker-compose.yml missing 'services' mapping.", ["docker-compose.yml"]
        except Exception as exc:
            return "failed", f"YAML parse error: {exc}", ["docker-compose.yml"]

    if ctype == "no_secrets":
        secret_patterns = [
            re.compile(r"sk-[a-zA-Z0-9]{20,}"),
            re.compile(r"BEGIN (?:RSA |OPENSSH )?PRIVATE KEY"),
            re.compile(r"AIza[0-9A-Za-z\-_]{35}"),
        ]
        offending: List[str] = []
        for rel, txt in code_files.items():
            for pat in secret_patterns:
                if pat.search(txt):
                    offending.append(rel)
                    break
        if offending:
            return "failed", f"Hardcoded secret pattern found in {offending}", offending
        return "passed", "Scanned all generated source files; 0 hardcoded secrets found.", []

    if ctype == "per_ac":
        aid = chk["linked"]["ac"]
        impl_files = [rel for rel, txt in code_files.items() if aid in txt and rel.endswith(".py")]
        test_matches = [rel for rel, txt in test_files.items() if aid in txt]
        if impl_files and test_matches:
            return "passed", f"Implemented in {impl_files}; tested in {test_matches}", impl_files + test_matches
        missing_parts = []
        if not impl_files:
            missing_parts.append("implementing Python file")
        if not test_matches:
            missing_parts.append("test tagging AC ID")
        return "failed", f"Missing {', '.join(missing_parts)} for {aid}", ["backend/app.py", "tests/test_acceptance.py"]

    if ctype == "per_invariant":
        iid = chk["linked"]["inv"]
        impl_files = [rel for rel, txt in code_files.items() if iid in txt and rel.endswith(".py")]
        viol_tests = [rel for rel, txt in test_files.items() if iid in txt and "violation" in txt.lower()]
        if impl_files and viol_tests:
            return "passed", f"Enforced in {impl_files}; violation tested in {viol_tests}", impl_files + viol_tests
        return "failed", f"Invariant {iid} missing enforcing location or violation test.", ["backend/db.py", "tests/test_acceptance.py"]

    if ctype == "per_nfr":
        nid = chk["linked"]["nfr"]
        nfr_obj = chk.get("nfr", {})
        is_assumption = bool(chk.get("assumption", False))
        test_matches = [rel for rel, txt in test_files.items() if nid in txt]
        if test_matches:
            note = " (non-blocking assumption)" if is_assumption else ""
            return (
                "passed",
                f"NFR {nid} ({nfr_obj.get('metric')} {nfr_obj.get('comparator')} {nfr_obj.get('threshold')}) verified in {test_matches}{note}",
                test_matches,
            )
        if is_assumption:
            return (
                "passed",
                f"NFR {nid} marked assumption=true; reported as non-blocking.",
                ["tests/test_acceptance.py"],
            )
        return "failed", f"NFR {nid} threshold check missing from test suite.", ["tests/test_acceptance.py"]

    if ctype == "per_screen":
        scr = chk.get("screen", {})
        scid = scr.get("id", "")
        route = scr.get("route", "/")
        ui_txt = code_files.get("frontend/ui_app.py", "") + code_files.get("backend/app.py", "")
        missing_states = [st for st in scr.get("states", []) if st not in ui_txt]
        missing_elems = [el for el in scr.get("elements", []) if str(el) not in ui_txt]
        if scid in ui_txt and route in ui_txt and not missing_states and not missing_elems:
            return (
                "passed",
                f"Screen {scid} route '{route}' implements states {scr.get('states', [])} and elements {scr.get('elements', [])}.",
                ["frontend/ui_app.py"],
            )
        return (
            "failed",
            f"Screen {scid} missing route '{route}', states {missing_states}, or elements {missing_elems}.",
            ["frontend/ui_app.py", "backend/app.py"],
        )

    if ctype == "per_role_protected_ac":
        aid = chk["linked"]["ac"]
        if is_mock:
            return "skipped (mock)", f"Mock mode: role-protected check for {aid} skipped (mock).", ["backend/auth.py"]
        # Verify via live TestClient call that request without permission returns 403 and leaks no protected data
        code_snippet = (
            "import sys; sys.path.insert(0, '.'); "
            "from fastapi.testclient import TestClient; "
            "from backend.app import app; "
            "c = TestClient(app); "
            "r = c.get('/api/history', headers={'X-Role': 'unauthorized_probe'}); "
            "assert r.status_code == 403, f'Expected 403 got {r.status_code}'; "
            "assert 'items' not in r.json(), 'Leaked items in 403 response'; "
            "print('403_VERIFIED')"
        )
        proc = subprocess.run(
            [sys.executable, "-c", code_snippet],
            cwd=str(output_dir),
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
        if proc.returncode == 0 and "403_VERIFIED" in proc.stdout:
            return "passed", f"Unauthorized request for {aid} returned 403 with zero protected data leaked.", ["backend/auth.py", "backend/app.py"]
        return "failed", f"Role-protection check failed for {aid}: {proc.stderr.strip() or proc.stdout.strip()}", ["backend/auth.py", "backend/app.py"]

    return "passed", "Check evaluated.", []


async def _apply_targeted_fix(
    failed_checks: List[Dict[str, Any]],
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    checklist_doc: Dict[str, Any],
    output_dir: Path,
    llm: LLMClient,
    tracer: TraceLogger,
    iteration: int,
) -> List[str]:
    """Repair only the affected files for failed review checks."""
    affected_files: List[str] = []
    for fc in failed_checks:
        for f in fc.get("affected_files", []):
            if f not in affected_files:
                affected_files.append(f)

    await llm.complete_json(
        prompt=json.dumps({
            "stage": "S7_targeted_fix",
            "iteration": iteration,
            "failed_checks": [c["id"] for c in failed_checks],
            "affected_files": affected_files,
        }),
        context={"stage": "S7_fix", "iteration": iteration, "failed_checks": failed_checks},
        tracer=tracer,
        stage="S7",
        ids={"check": [c["id"] for c in failed_checks]},
        mode="serial",
    )

    repaired: List[str] = []
    if any(f.startswith("backend/db") or f.startswith("backend/auth") or f.startswith("backend/permissions") for f in affected_files):
        repaired.extend(_generate_foundation_files(spec, extraction, output_dir, is_mock=llm.is_mock))
    if any(f.startswith("frontend/") for f in affected_files):
        for item in checklist_doc.get("items", []):
            if item.get("kind") == "task" and "ui" in item.get("title", "").lower():
                repaired.extend(_generate_task_files(item, spec, extraction, output_dir, is_mock=llm.is_mock))
    if any(f in ("backend/app.py", "tests/test_acceptance.py", "docker-compose.yml", "run_local.py", "README.md") for f in affected_files) or not repaired:
        repaired.extend(_generate_wiring_files(spec, extraction, checklist_doc, output_dir, is_mock=llm.is_mock))

    return sorted(set(repaired))


async def run_review_loop(
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    checklist_doc: Dict[str, Any],
    output_dir: Path,
    llm: LLMClient,
    tracer: TraceLogger,
    graph: TraceGraph,
    max_review_iterations: Optional[int] = None,
) -> Dict[str, Any]:
    """Execute Stage S7 Review Checklist + Targeted Fix Loop."""
    max_iters = int(
        max_review_iterations
        if max_review_iterations is not None
        else os.getenv("MAX_REVIEW_ITERATIONS", "2")
    )
    checks = build_review_checks(spec, extraction)

    # Allow scripted LLM test to inject a synthetic fixable defect before iteration 1
    if not llm.is_mock and llm.scripted_responder is not None:
        probe = await llm.complete_json(
            prompt=json.dumps({"stage": "S7_pre_review_hook", "handoff_id": spec.handoff_id}),
            context={"stage": "S7_pre_review_hook"},
            tracer=tracer,
            stage="S7",
            ids={"handoff": spec.handoff_id},
            mode="serial",
        )
        if isinstance(probe, dict) and probe.get("break_compose_before_iter_1"):
            (output_dir / "docker-compose.yml").write_text("invalid_yaml: [unclosed", encoding="utf-8")

    final_results: List[Dict[str, Any]] = []
    fixed_across_iterations: List[str] = []
    previously_failed_ids: set = set()

    for iteration in range(1, max_iters + 1):
        iter_results: List[Dict[str, Any]] = []
        failed_blocking: List[Dict[str, Any]] = []
        newly_fixed_this_iter: List[str] = []

        for chk in checks:
            status, evidence, affected = _evaluate_single_check(
                chk, output_dir=output_dir, is_mock=llm.is_mock, extraction=extraction
            )
            record = {
                "id": chk["id"],
                "title": chk["title"],
                "category": chk["category"],
                "status": status,
                "blocking": chk.get("blocking", True),
                "evidence": evidence,
                "linked": chk.get("linked", {}),
                "affected_files": affected,
                "iteration": iteration,
            }
            iter_results.append(record)

            # Log each check to review.jsonl (and trace.jsonl)
            tracer.log(
                stage="S7",
                event="review_check",
                level="info" if status in ("passed", "skipped (mock)") else "warning",
                ids={"check": chk["id"], **chk.get("linked", {})},
                mode="serial",
                attempt=iteration,
                data={
                    "id": chk["id"],
                    "status": status,
                    "evidence": evidence,
                    "linked": chk.get("linked", {}),
                },
            )

            if status in ("passed", "skipped (mock)") and chk["id"] in previously_failed_ids:
                newly_fixed_this_iter.append(chk["id"])
                if chk["id"] not in fixed_across_iterations:
                    fixed_across_iterations.append(chk["id"])

            if status == "failed" and chk.get("blocking", True):
                failed_blocking.append(record)
                previously_failed_ids.add(chk["id"])

        final_results = iter_results
        passed_ids = [r["id"] for r in iter_results if r["status"] in ("passed", "skipped (mock)")]
        failed_ids = [r["id"] for r in failed_blocking]

        tracer.log(
            stage="S7",
            event="review_iteration_summary",
            level="info" if not failed_blocking else "warning",
            ids={"passed": passed_ids, "failed": failed_ids, "fixed": newly_fixed_this_iter},
            mode="serial",
            attempt=iteration,
            data={
                "iteration": f"{iteration}/{max_iters}",
                "checks_run": len(iter_results),
                "passed_count": len(passed_ids),
                "failed_count": len(failed_ids),
                "passed_ids": passed_ids,
                "failed_ids": failed_ids,
                "fixed_ids": newly_fixed_this_iter,
            },
        )

        if not failed_blocking:
            break

        if iteration < max_iters:
            repaired_files = await _apply_targeted_fix(
                failed_blocking,
                spec=spec,
                extraction=extraction,
                checklist_doc=checklist_doc,
                output_dir=output_dir,
                llm=llm,
                tracer=tracer,
                iteration=iteration,
            )
            tracer.log(
                stage="S7",
                event="review_targeted_fix_applied",
                level="info",
                ids={"failed_checks": failed_ids},
                mode="serial",
                attempt=iteration,
                data={"repaired_files": repaired_files},
            )

    # Link review checks in TraceGraph (story -> AC -> task -> checklist item -> file -> test -> review check)
    for r in final_results:
        rc_id = r["id"]
        graph.add_node(rc_id, "review_check", label=f"{rc_id} ({r['status']})", status=r["status"])
        linked = r.get("linked", {})
        if "ac" in linked:
            graph.add_edge("file:tests/test_acceptance.py", rc_id, "reviewed_by")
            graph.add_edge(rc_id, linked["ac"], "verifies")
        if "inv" in linked:
            graph.add_edge("file:tests/test_acceptance.py", rc_id, "reviewed_by")
            graph.add_edge(rc_id, linked["inv"], "verifies")
        if "nfr" in linked:
            graph.add_edge("file:tests/test_acceptance.py", rc_id, "reviewed_by")
            graph.add_edge(rc_id, linked["nfr"], "verifies")
        if "screen" in linked:
            graph.add_edge("file:frontend/ui_app.py", rc_id, "reviewed_by")
            graph.add_edge(rc_id, linked["screen"], "verifies")

    passed_total = sum(1 for r in final_results if r["status"] in ("passed", "skipped (mock)"))
    total_checks = len(final_results)
    failures_left = [r for r in final_results if r["status"] == "failed"]

    tracer.log(
        stage="S7",
        event=f"review_checklist_done: {passed_total}/{total_checks} passed",
        level="info" if not failures_left else "error",
        ids={"failed": [f["id"] for f in failures_left]},
        mode="serial",
        attempt=1,
        data={
            "summary": f"review_checklist_done: {passed_total}/{total_checks} passed",
            "passed": passed_total,
            "total": total_checks,
            "fixed_checks": fixed_across_iterations,
            "failures_left": [
                {"id": f["id"], "title": f["title"], "evidence": f["evidence"]}
                for f in failures_left
            ],
        },
    )

    return {
        "passed": passed_total,
        "total": total_checks,
        "fixed_checks": fixed_across_iterations,
        "failures_left": failures_left,
        "checks": final_results,
    }
