"""Stage S6: Graphify code-graph adapter + AST fallback merger.

Runs `graphify update output/<handoff_id> --no-cluster` (when `USE_GRAPHIFY=true`)
and merges its code nodes (files, functions, classes) into the TraceGraph,
linking file nodes to the checklist items that produced them.

If `graphify` CLI/package is missing or fails, logs a warning and falls back
 cleanly while preserving the own TraceGraph (and AST function links).
"""
from __future__ import annotations

import ast
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List
from .tracing import TraceGraph, TraceLogger


def _merge_ast_symbols(output_dir: Path, graph: TraceGraph) -> int:
    """Parse Python files in output_dir to add function/class nodes linked to their file nodes."""
    added = 0
    for py_file in sorted(output_dir.rglob("*.py")):
        if "__pycache__" in py_file.parts:
            continue
        rel = py_file.relative_to(output_dir).as_posix()
        file_node_id = f"file:{rel}"
        if file_node_id not in graph.nodes:
            graph.add_node(file_node_id, "file", label=rel, path=rel)

        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                fn_id = f"func:{rel}:{node.name}"
                graph.add_node(fn_id, "function", label=f"{rel}::{node.name}", file=rel)
                graph.add_edge(file_node_id, fn_id, "generated")
                added += 1
            elif isinstance(node, ast.ClassDef):
                cls_id = f"class:{rel}:{node.name}"
                graph.add_node(cls_id, "class", label=f"{rel}::{node.name}", file=rel)
                graph.add_edge(file_node_id, cls_id, "generated")
                added += 1
    return added


def run_graphify_stage(
    output_dir: Path,
    checklist_doc: Dict[str, Any],
    tracer: TraceLogger,
    graph: TraceGraph,
    logs_dir: Path,
    use_graphify: Optional[bool] = None,
) -> Dict[str, Any]:
    """Run Stage S6: merge code graph into TraceGraph and write graph.json + graph.mmd."""
    if use_graphify is None:
        use_graphify = os.getenv("USE_GRAPHIFY", "true").strip().lower() in ("1", "true", "yes")

    # Map file -> checklist item IDs
    file_to_chks: Dict[str, List[str]] = {}
    for item in checklist_doc.get("items", []):
        for rel_f in item.get("generated_files", []):
            file_to_chks.setdefault(rel_f, []).append(item["id"])

    graphify_status = "skipped"
    graphify_nodes_merged = 0

    if use_graphify:
        graphify_bin = shutil.which("graphify")
        if graphify_bin:
            try:
                proc = subprocess.run(
                    [graphify_bin, "update", str(output_dir), "--no-cluster"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                    check=False,
                )
                if proc.returncode == 0:
                    graphify_status = "merged_cli"
                    # Check if graphify wrote a graph JSON file in output_dir or .graphify
                    for candidate in (
                        output_dir / ".graphify" / "graph.json",
                        output_dir / "graphify.json",
                        output_dir / "graph.json",
                    ):
                        if candidate.exists():
                            try:
                                gdata = json.loads(candidate.read_text(encoding="utf-8"))
                                for gnode in gdata.get("nodes", []):
                                    nid = str(gnode.get("id") or gnode.get("name"))
                                    ntype = str(gnode.get("type") or "code_symbol")
                                    graph.add_node(f"graphify:{nid}", ntype, label=nid)
                                    graphify_nodes_merged += 1
                            except Exception:
                                pass
                else:
                    graphify_status = "fallback_warning"
                    tracer.log(
                        stage="S6",
                        event="graphify_warning",
                        level="warning",
                        ids={},
                        mode="serial",
                        attempt=1,
                        data={"reason": f"graphify exited with code {proc.returncode}: {proc.stderr.strip()}"},
                    )
            except Exception as exc:
                graphify_status = "fallback_warning"
                tracer.log(
                    stage="S6",
                    event="graphify_warning",
                    level="warning",
                    ids={},
                    mode="serial",
                    attempt=1,
                    data={"reason": f"graphify execution failed: {exc}"},
                )
        else:
            graphify_status = "missing_binary_warning"
            tracer.log(
                stage="S6",
                event="graphify_warning",
                level="warning",
                ids={},
                mode="serial",
                attempt=1,
                data={"reason": "graphify CLI not installed in environment; continuing with own TraceGraph + AST symbols."},
            )

    ast_symbols_count = _merge_ast_symbols(output_dir, graph)

    # Ensure every file node in output_dir is linked to the checklist item(s) that produced it
    for rel_f, chks in file_to_chks.items():
        f_node = f"file:{rel_f}"
        for cid in chks:
            graph.add_edge(cid, f_node, "generated")

    graph.save(logs_dir)

    summary = {
        "use_graphify": use_graphify,
        "graphify_status": graphify_status,
        "graphify_nodes_merged": graphify_nodes_merged,
        "ast_symbols_merged": ast_symbols_count,
        "total_nodes": len(graph.nodes),
        "total_edges": len(graph.links),
    }

    tracer.log(
        stage="S6",
        event="graph_built",
        level="info",
        ids={},
        mode="serial",
        attempt=1,
        data=summary,
    )
    return summary
