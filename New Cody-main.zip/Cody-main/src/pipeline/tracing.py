"""TraceLogger (JSONL streams) and TraceGraph (graph.json + graph.mmd).

Every event is written as one JSON line with schema:
  ts, run_id, stage, event, level, ids{story,ac,task,chk,...}, mode, attempt, data
All stage logs are mirrored into trace.jsonl in chronological order.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


class TraceLogger:
    """Writes structured JSONL traceability events per stage and mirrors all to trace.jsonl."""

    STAGE_STREAMS = {
        "S0": "trace.jsonl",
        "S1": "intent.jsonl",
        "S2": "extraction.jsonl",
        "S3": "trace.jsonl",
        "S4": "trace.jsonl",
        "S5": "intent_match.jsonl",
        "S6": "trace.jsonl",
        "S7": "review.jsonl",
        "S8": "trace.jsonl",
    }

    def __init__(self, run_id: str, logs_dir: Path) -> None:
        self.run_id = run_id
        self.logs_dir = Path(logs_dir)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.trace_path = self.logs_dir / "trace.jsonl"
        self.events: List[Dict[str, Any]] = []

        # Ensure all standard JSONL stream files exist even if a stage has few events
        for stream_name in ("trace.jsonl", "intent.jsonl", "extraction.jsonl", "intent_match.jsonl", "review.jsonl"):
            stream_file = self.logs_dir / stream_name
            if not stream_file.exists():
                stream_file.write_text("", encoding="utf-8")

    def log(
        self,
        stage: str,
        event: str,
        level: str = "info",
        ids: Optional[Dict[str, Any]] = None,
        mode: Optional[str] = None,
        attempt: Optional[int] = None,
        data: Optional[Dict[str, Any]] = None,
        stream: Optional[str] = None,
    ) -> Dict[str, Any]:
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "run_id": self.run_id,
            "stage": stage,
            "event": event,
            "level": level,
            "ids": ids or {},
            "mode": mode or "serial",
            "attempt": attempt if attempt is not None else 1,
            "data": data or {},
        }
        self.events.append(record)
        line = json.dumps(record, ensure_ascii=False) + "\n"

        # Always append to trace.jsonl
        with open(self.trace_path, "a", encoding="utf-8") as f:
            f.write(line)

        # Also append to stage-specific stream if different from trace.jsonl
        target_stream = stream or self.STAGE_STREAMS.get(stage, "trace.jsonl")
        if target_stream != "trace.jsonl":
            stage_path = self.logs_dir / target_stream
            with open(stage_path, "a", encoding="utf-8") as f:
                f.write(line)

        return record


class TraceGraph:
    """Source-of-truth traceability graph exported to graph.json and graph.mmd.

    Nodes: handoff, story, ac, task, component, invariant, nfr, screen,
           intent, checklist_item, file, test, review_check (plus function/class from graphify).
    Edges: derives_from, implements, depends_on, generated, verifies, reviewed_by, covers.
    Chain a reader can follow:
      story -> AC -> task -> checklist item -> file -> test -> review check.
    """

    def __init__(self) -> None:
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self.links: List[Dict[str, Any]] = []
        self._edge_keys: set = set()

    def add_node(self, node_id: str, node_type: str, label: Optional[str] = None, **attrs: Any) -> None:
        if not node_id:
            return
        existing = self.nodes.get(node_id, {})
        merged = {
            **existing,
            "id": node_id,
            "type": node_type,
            "label": label or existing.get("label") or node_id,
            **attrs,
        }
        self.nodes[node_id] = merged

    def add_edge(self, source: str, target: str, relation: str, **attrs: Any) -> None:
        if not source or not target:
            return
        key = (source, target, relation)
        if key in self._edge_keys:
            return
        self._edge_keys.add(key)
        self.links.append({
            "source": source,
            "target": target,
            "relation": relation,
            **attrs,
        })

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": list(self.nodes.values()),
            "links": list(self.links),
        }

    def to_mermaid(self) -> str:
        lines = ["flowchart LR"]

        def safe_id(raw: str) -> str:
            cleaned = "".join(ch if ch.isalnum() else "_" for ch in str(raw))
            if cleaned and cleaned[0].isdigit():
                cleaned = "N_" + cleaned
            return cleaned or "NODE"

        for nid, n in self.nodes.items():
            sid = safe_id(nid)
            ntype = n.get("type", "node")
            lbl = str(n.get("label", nid)).replace('"', "'")
            lines.append(f'    {sid}["[{ntype}] {lbl}"]')

        for edge in self.links:
            s_id = safe_id(edge["source"])
            t_id = safe_id(edge["target"])
            rel = edge["relation"]
            lines.append(f"    {s_id} -->|{rel}| {t_id}")

        return "\n".join(lines) + "\n"

    def save(self, logs_dir: Path) -> None:
        logs_dir = Path(logs_dir)
        logs_dir.mkdir(parents=True, exist_ok=True)
        (logs_dir / "graph.json").write_text(
            json.dumps(self.to_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        (logs_dir / "graph.mmd").write_text(
            self.to_mermaid(),
            encoding="utf-8",
        )
