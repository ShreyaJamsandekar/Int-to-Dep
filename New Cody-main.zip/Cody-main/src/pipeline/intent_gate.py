"""Stage S5: Intent-Match Gate with retries (per-item and full-output gate before S7).

Checks generated output against intent (§7):
- Static evidence:
  - each AC has >=1 implementing file and >=1 test that tags the AC ID
  - each endpoint/screen in the plan exists
  - each INV has an enforcing code location
- LLM judge (when model != mock):
  - per AC, "does this code satisfy this Gherkin?" -> yes/no + reason
- Failing items are regenerated with the gate's findings as feedback, up to `INTENT_MAX_RETRIES`.
  Each attempt logs `attempt n/N`, `missing[]`, `reason` to `intent_match.jsonl` and `trace.jsonl`.
- After retries run out, the item is marked `unmatched`, carried into review, and flagged in `summary.md`.
  It is never silently passed.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple
from .executor import execute_checklist_item
from .llm import LLMClient
from .models import HandoffSpec
from .tracing import TraceGraph, TraceLogger


def _scan_output_files(output_dir: Path) -> Tuple[Dict[str, str], Dict[str, str]]:
    """Return (code_files_content, test_files_content) keyed by relative path."""
    code_files: Dict[str, str] = {}
    test_files: Dict[str, str] = {}
    if not output_dir.exists():
        return code_files, test_files

    for p in output_dir.rglob("*"):
        if not p.is_file() or "__pycache__" in p.parts or p.suffix in (".pyc", ".pyo"):
            continue
        rel = p.relative_to(output_dir).as_posix()
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if rel.startswith("tests/"):
            test_files[rel] = txt
        elif p.suffix in (".py", ".html", ".css", ".js", ".json", ".yaml", ".yml"):
            code_files[rel] = txt
    return code_files, test_files


async def verify_item_and_retry(
    item: Dict[str, Any],
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    checklist_doc: Dict[str, Any],
    output_dir: Path,
    llm: LLMClient,
    tracer: TraceLogger,
    graph: TraceGraph,
    intent_max_retries: Optional[int] = None,
) -> Dict[str, Any]:
    """Run the per-item intent-match gate after S4 generation, retrying up to INTENT_MAX_RETRIES."""
    max_retries = int(
        intent_max_retries
        if intent_max_retries is not None
        else os.getenv("INTENT_MAX_RETRIES", "2")
    )
    total_attempts = max_retries + 1
    cid = item["id"]
    mode = item.get("mode", "serial")
    linked = item.get("linked", {})

    ac_map = {
        ac.id: ac
        for st in spec.stories
        for ac in st.acceptance_criteria
    }

    for attempt in range(1, total_attempts + 1):
        missing: List[str] = []
        reasons: List[str] = []

        code_files, test_files = _scan_output_files(output_dir)
        item_files = item.get("generated_files", [])

        # 1. Verify generated files exist and are non-empty
        for rel_f in item_files:
            full_p = output_dir / rel_f
            if not full_p.exists() or full_p.stat().st_size == 0:
                missing.append(f"file:{rel_f}")
                reasons.append(f"Expected generated file '{rel_f}' is missing or empty.")

        # 2. For task items or wiring, check AC implementation tags in code files
        if item.get("kind") in ("task", "wiring"):
            for aid in linked.get("ac", []):
                has_impl = any(aid in content for rel, content in code_files.items() if not rel.endswith(".json"))
                if not has_impl:
                    missing.append(f"ac_impl:{aid}")
                    reasons.append(f"AC '{aid}' has no implementing code file tagging '{aid}'.")
                if item.get("kind") == "wiring":
                    has_test = any(aid in content for content in test_files.values())
                    if not has_test:
                        missing.append(f"ac_test:{aid}")
                        reasons.append(f"AC '{aid}' has no test tagging '{aid}'.")

        # 3. Check invariants have enforcing code locations
        for iid in linked.get("invariant", []):
            has_inv = any(iid in content for rel, content in code_files.items() if rel.endswith(".py"))
            if not has_inv:
                missing.append(f"invariant:{iid}")
                reasons.append(f"Invariant '{iid}' has no enforcing Python code location.")

        # 4. LLM judge per AC when model != mock
        if not llm.is_mock and item.get("kind") == "task" and not missing:
            for aid in linked.get("ac", []):
                ac_obj = ac_map.get(aid)
                gherkin_txt = ac_obj.full_text() if ac_obj else aid
                judge_resp = await llm.complete_json(
                    prompt=json.dumps({
                        "stage": "S5_llm_judge",
                        "question": "Does this code satisfy this Gherkin?",
                        "chk_id": cid,
                        "ac_id": aid,
                        "gherkin": gherkin_txt,
                        "attempt": attempt,
                    }),
                    context={
                        "stage": "S5",
                        "chk_id": cid,
                        "ac_id": aid,
                        "gherkin": gherkin_txt,
                        "attempt": attempt,
                    },
                    tracer=tracer,
                    stage="S5",
                    ids={"chk": cid, "ac": aid},
                    mode=mode,
                )
                satisfied = judge_resp.get("satisfied", True)
                judge_reason = judge_resp.get("reason", "Code satisfies Gherkin criteria.")
                tracer.log(
                    stage="S5",
                    event="llm_judge_ac",
                    level="info" if satisfied else "warning",
                    ids={"chk": cid, "ac": aid},
                    mode=mode,
                    attempt=attempt,
                    data={
                        "ac_id": aid,
                        "satisfied": bool(satisfied),
                        "reason": judge_reason,
                        "attempt": f"{attempt}/{total_attempts}",
                    },
                )
                if not satisfied:
                    missing.append(f"llm_judge:{aid}")
                    reasons.append(f"LLM Judge rejected {aid}: {judge_reason}")

        if not missing:
            item["status"] = "gate_passed"
            tracer.log(
                stage="S4",
                event="gate_passed",
                level="info",
                ids={"chk": cid, **linked},
                mode=mode,
                attempt=attempt,
                data={"attempt": f"{attempt}/{total_attempts}", "missing": [], "reason": "All static and intent checks passed."},
                stream="intent_match.jsonl",
            )
            return {"status": "gate_passed", "attempt": attempt, "missing": []}

        reason_str = "; ".join(reasons)
        if attempt <= max_retries:
            item["status"] = "retry"
            tracer.log(
                stage="S5",
                event="retry",
                level="warning",
                ids={"chk": cid, **linked},
                mode=mode,
                attempt=attempt,
                data={
                    "attempt": f"{attempt}/{total_attempts}",
                    "missing": missing,
                    "reason": reason_str,
                },
            )
            await execute_checklist_item(
                item,
                spec=spec,
                extraction=extraction,
                checklist_doc=checklist_doc,
                output_dir=output_dir,
                llm=llm,
                tracer=tracer,
                graph=graph,
                attempt=attempt + 1,
                retry_feedback={"missing": missing, "reason": reason_str},
            )
        else:
            item["status"] = "unmatched"
            item["unmatched_missing"] = missing
            item["unmatched_reason"] = reason_str
            tracer.log(
                stage="S5",
                event="unmatched",
                level="error",
                ids={"chk": cid, **linked},
                mode=mode,
                attempt=attempt,
                data={
                    "attempt": f"{attempt}/{total_attempts}",
                    "missing": missing,
                    "reason": reason_str,
                },
            )
            return {"status": "unmatched", "attempt": attempt, "missing": missing, "reason": reason_str}

    return {"status": item["status"], "attempt": total_attempts, "missing": []}


async def run_full_output_gate(
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    checklist_doc: Dict[str, Any],
    output_dir: Path,
    llm: LLMClient,
    tracer: TraceLogger,
    graph: TraceGraph,
) -> Dict[str, Any]:
    """Run comprehensive Stage S5 output intent-match verification across all ACs, endpoints, screens, and invariants before S7."""
    code_files, test_files = _scan_output_files(output_dir)
    all_code_text = "\n".join(txt for rel, txt in code_files.items() if not rel.endswith(".json"))
    all_test_text = "\n".join(test_files.values())

    ac_coverage: Dict[str, Dict[str, Any]] = {}
    missing_global: List[str] = []

    for st in spec.stories:
        for ac in st.acceptance_criteria:
            impl_files = [rel for rel, txt in code_files.items() if ac.id in txt and not rel.endswith(".json")]
            test_matches = [rel for rel, txt in test_files.items() if ac.id in txt]
            covered = bool(impl_files and test_matches)
            ac_coverage[ac.id] = {
                "ac_id": ac.id,
                "story_id": st.id,
                "implementing_files": impl_files,
                "test_files": test_matches,
                "covered": covered,
            }
            if not covered:
                missing_global.append(f"ac:{ac.id}")

    for ep in extraction["build_plan"]["endpoints"]:
        ep_path = ep["path"]
        base_segment = ep_path.split("/{")[0]
        if base_segment not in all_code_text:
            missing_global.append(f"endpoint:{ep['method']} {ep_path}")

    for scr in extraction.get("screens", []):
        route = scr.get("route") or "/"
        if scr["id"] not in all_code_text or route not in all_code_text:
            missing_global.append(f"screen:{scr['id']}({route})")

    for inv in extraction.get("invariants", []):
        if inv["id"] not in all_code_text:
            missing_global.append(f"invariant:{inv['id']}")

    unmatched_items = [
        i["id"] for i in checklist_doc.get("items", []) if i.get("status") == "unmatched"
    ]

    gate_summary = {
        "passed": len(missing_global) == 0 and len(unmatched_items) == 0,
        "ac_coverage": ac_coverage,
        "missing": missing_global,
        "unmatched_checklist_items": unmatched_items,
    }

    tracer.log(
        stage="S5",
        event="output_intent_gate_completed",
        level="info" if gate_summary["passed"] else "warning",
        ids={
            "ac": list(ac_coverage.keys()),
            "unmatched_chk": unmatched_items,
        },
        mode="serial",
        attempt=1,
        data=gate_summary,
    )

    return gate_summary
