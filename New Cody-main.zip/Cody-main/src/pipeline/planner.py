"""Stage S3: Dependency Layer Planner & Checklist Builder (serial vs parallel).

Each checklist item has:
  id (CHK-nnn), title, mode (serial|parallel), layer, depends_on,
  linked {story, ac, task, component, invariant, nfr, screen}, status.

Planner rules (§6):
1. Dependency edges come from:
   - handoff `dependencies` / `relationships`
   - task `depends_on`
   - invariants that reference multiple entities (e.g., INV-002: reservation needs flight + customer)
   - tasks that build on other tasks' entities (e.g., history/audit tasks depending on reservation + customer)
   - shared output files / schema contracts (L0 DB schema + API contract precedes L1+ tasks; L4 wiring depends on all tasks)
2. Topologically layer the items:
   - A layer with 1 item = `serial`
   - A layer with 2+ independent items = `parallel`
3. Records top-level `workflow_mode` (`serial`, `parallel`, or `mixed`) with the reason.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple
from .models import HandoffSpec, TaskItemModel
from .tracing import TraceGraph, TraceLogger


def _task_entity_mentions(task: TaskItemModel, story_text: str, entity_slugs: List[str]) -> Set[str]:
    own_text = f"{task.title or ''} {task.description or ''}".strip().lower()
    mentioned: Set[str] = set()
    for slug in entity_slugs:
        if slug in own_text or f"{slug}s" in own_text:
            mentioned.add(slug)
    if not mentioned:
        st_lower = story_text.lower()
        for slug in entity_slugs:
            if slug in st_lower or f"{slug}s" in st_lower:
                mentioned.add(slug)
    return mentioned


def _is_history_or_report_task(task: TaskItemModel, story_text: str, is_ui: bool = False) -> bool:
    if is_ui:
        return False
    text = f"{task.title or ''} {task.description or ''} {story_text}".lower()
    return any(k in text for k in ("history", "audit", "past ", "log", "report", "archive"))


def _is_ui_task(task: TaskItemModel, comp_map: Dict[str, Any], spec: HandoffSpec) -> bool:
    comp = comp_map.get(task.component_id or "")
    if comp:
        c_text = f"{comp.name} {comp.type} {comp.stack_summary()}".lower()
        if any(k in c_text for k in ("ui", "frontend", "web", "client", "html", "css", "screen", "spa")):
            return True
    t_text = f"{task.title or ''} {task.description or ''}".lower()
    return bool(re.search(r"\b(ui|frontend|screen|screens|interface|css|html)\b", t_text))


def build_checklist(
    spec: HandoffSpec,
    extraction: Dict[str, Any],
    tracer: TraceLogger,
    graph: TraceGraph,
    logs_dir: Path,
) -> Dict[str, Any]:
    """Construct topologically layered serial/parallel checklist and save checklist.json."""
    comp_map = {c.id: c for c in spec.components}
    story_map = {s.id: s for s in spec.stories}
    entity_slugs = [e["slug"] for e in extraction.get("entities", [])]

    all_story_ids = [s.id for s in spec.stories]
    all_ac_ids = [ac.id for s in spec.stories for ac in s.acceptance_criteria]
    all_inv_ids = [i.id for i in spec.invariants]
    all_nfr_ids = [n.id for n in spec.nfrs]
    all_screen_ids = [s.id for s in spec.ui.screens]
    all_comp_ids = [c.id for c in spec.components]

    # Step 1: L0 Foundation item (DB schema + API contract)
    chk_l0_id = "CHK-001"
    raw_items: List[Dict[str, Any]] = [
        {
            "id": chk_l0_id,
            "kind": "foundation",
            "title": "DB schema + API contract",
            "depends_on": set(),
            "linked": {
                "story": all_story_ids,
                "ac": all_ac_ids,
                "task": [],
                "component": all_comp_ids,
                "invariant": all_inv_ids,
                "nfr": all_nfr_ids,
                "screen": [],
            },
        }
    ]

    # Map tasks to checklist items
    task_to_chk: Dict[str, str] = {}
    task_entities: Dict[str, Set[str]] = {}
    primary_entity_owners: Dict[str, List[str]] = {}  # entity_slug -> [task_id]

    sorted_tasks = sorted(spec.tasks, key=lambda t: t.id)
    for idx, t in enumerate(sorted_tasks, start=2):
        chk_id = f"CHK-{idx:03d}"
        task_to_chk[t.id] = chk_id
        st = story_map.get(t.story_id or "")
        st_text = f"{st.title} {st.description}" if st else ""
        mentions = _task_entity_mentions(t, st_text, entity_slugs)
        task_entities[t.id] = mentions

        is_ui = _is_ui_task(t, comp_map, spec)
        is_hist = _is_history_or_report_task(t, st_text, is_ui=is_ui)

        # Single-entity foundational domain tasks own that entity
        if len(mentions) == 1 and not is_ui and not is_hist:
            only_ent = next(iter(mentions))
            primary_entity_owners.setdefault(only_ent, []).append(t.id)

        ac_list = list(t.ac_ids) if t.ac_ids else ([ac.id for ac in st.acceptance_criteria] if st else [])
        inv_list = [
            inv.id
            for inv in spec.invariants
            if (st and st.id in inv.applies_to_stories) or (st and inv.id in st.invariant_ids)
        ]
        nfr_list = [
            nfr.id
            for nfr in spec.nfrs
            if (st and st.id in nfr.applies_to_stories) or (st and nfr.id in st.nfr_ids)
        ]
        scr_list = [
            scr.id
            for scr in spec.ui.screens
            if (st and st.id in scr.story_ids) or any(aid in scr.ac_ids for aid in ac_list)
        ]
        if is_ui and not scr_list:
            scr_list = list(all_screen_ids)

        raw_items.append({
            "id": chk_id,
            "kind": "task",
            "task_id": t.id,
            "title": f"{t.id}: {t.title or (st.title if st else t.id)}",
            "depends_on": {chk_l0_id},
            "is_ui": is_ui,
            "is_history": is_hist,
            "entities": mentions,
            "linked": {
                "story": [t.story_id] if t.story_id else [],
                "ac": ac_list,
                "task": [t.id],
                "component": [t.component_id] if t.component_id else [],
                "invariant": inv_list,
                "nfr": nfr_list,
                "screen": scr_list,
            },
        })

    # Step 2: Derive dependency edges between task checklist items
    item_by_task = {item["task_id"]: item for item in raw_items if item.get("kind") == "task"}

    # 2a. Explicit task.depends_on
    for t in sorted_tasks:
        item = item_by_task[t.id]
        for dep_tid in t.depends_on:
            if dep_tid in task_to_chk and dep_tid != t.id:
                item["depends_on"].add(task_to_chk[dep_tid])

    # 2b. Invariant-driven & multi-entity dependencies:
    # Expand task entity mentions with entities linked via invariants on the task's story
    for t in sorted_tasks:
        item = item_by_task[t.id]
        if item["is_ui"]:
            continue
        inv_ids_for_task = set(item["linked"].get("invariant", []))
        expanded_entities = set(item["entities"])
        for inv in spec.invariants:
            if inv.id in inv_ids_for_task:
                inv_txt = f"{inv.title} {inv.description} {inv.rule} {' '.join(inv.entities)}".lower()
                for slug in entity_slugs:
                    if slug in inv_txt or f"{slug}s" in inv_txt:
                        expanded_entities.add(slug)
        item["expanded_entities"] = expanded_entities

    for t in sorted_tasks:
        item = item_by_task[t.id]
        if item["is_ui"] or item["is_history"]:
            continue
        direct_mentions = item["entities"]
        expanded = item.get("expanded_entities", direct_mentions)
        # A task that touches >1 entities directly or via invariants depends on single-entity foundational tasks
        if len(expanded) > 1 and len(direct_mentions) > 1:
            for ent_slug in expanded:
                for owner_tid in primary_entity_owners.get(ent_slug, []):
                    if owner_tid != t.id:
                        item["depends_on"].add(task_to_chk[owner_tid])

    # 2c. History / audit tasks depend on composite/transactional tasks and entity tasks they reference
    for t in sorted_tasks:
        item = item_by_task[t.id]
        if item["is_history"]:
            for other_t in sorted_tasks:
                if other_t.id == t.id:
                    continue
                other_item = item_by_task[other_t.id]
                if other_item["is_ui"] or other_item["is_history"]:
                    continue
                other_exp = other_item.get("expanded_entities", other_item["entities"])
                item_exp = item.get("expanded_entities", item["entities"])
                if other_exp & item_exp or not item_exp:
                    item["depends_on"].add(task_to_chk[other_t.id])

    # Step 3: Add final wiring item (compose, run_local.py, README, tests) depending on all previous items
    wiring_id = f"CHK-{len(raw_items)+1:03d}"
    all_prior_ids = {item["id"] for item in raw_items}
    raw_items.append({
        "id": wiring_id,
        "kind": "wiring",
        "title": "Wiring: docker-compose, run_local.py, README, tests",
        "depends_on": all_prior_ids,
        "linked": {
            "story": all_story_ids,
            "ac": all_ac_ids,
            "task": [t.id for t in sorted_tasks],
            "component": all_comp_ids,
            "invariant": all_inv_ids,
            "nfr": all_nfr_ids,
            "screen": all_screen_ids,
        },
    })

    # Step 4: Topological layering
    remaining = {item["id"]: item for item in raw_items}
    completed: Set[str] = set()
    layers: List[List[Dict[str, Any]]] = []

    while remaining:
        ready_ids = sorted(
            cid for cid, item in remaining.items() if item["depends_on"].issubset(completed)
        )
        if not ready_ids:
            # Break any cycle deterministically
            ready_ids = [sorted(remaining.keys())[0]]

        layer_idx = len(layers)
        layer_mode = "parallel" if len(ready_ids) >= 2 else "serial"
        layer_items: List[Dict[str, Any]] = []

        for cid in ready_ids:
            raw = remaining.pop(cid)
            chk_item = {
                "id": raw["id"],
                "title": raw["title"],
                "kind": raw["kind"],
                "mode": layer_mode,
                "layer": layer_idx,
                "depends_on": sorted(raw["depends_on"]),
                "linked": raw["linked"],
                "status": "queued",
            }
            layer_items.append(chk_item)
            completed.add(cid)

        layers.append(layer_items)

    flat_items = [item for layer in layers for item in layer]
    modes_present = {item["mode"] for item in flat_items}
    if modes_present == {"serial"}:
        workflow_mode = "serial"
        workflow_reason = "Every dependency layer has a single item."
    elif modes_present == {"parallel"}:
        workflow_mode = "parallel"
        workflow_reason = "All dependency layers contain multiple independent items."
    else:
        parallel_layers = [f"L{idx} ({len(l)} items)" for idx, l in enumerate(layers) if len(l) >= 2]
        serial_layers = [f"L{idx}" for idx, l in enumerate(layers) if len(l) == 1]
        workflow_mode = "mixed"
        workflow_reason = (
            f"Topological sort produced {len(layers)} layers: "
            f"serial layers [{', '.join(serial_layers)}] and "
            f"parallel independent layers [{', '.join(parallel_layers)}]."
        )

    checklist_doc = {
        "handoff_id": spec.handoff_id,
        "workflow_mode": workflow_mode,
        "workflow_reason": workflow_reason,
        "total_items": len(flat_items),
        "layers": [
            {
                "layer": idx,
                "mode": "parallel" if len(layer) >= 2 else "serial",
                "items": [i["id"] for i in layer],
            }
            for idx, layer in enumerate(layers)
        ],
        "items": flat_items,
    }

    # Save checklist.json
    logs_dir = Path(logs_dir)
    logs_dir.mkdir(parents=True, exist_ok=True)
    (logs_dir / "checklist.json").write_text(
        json.dumps(checklist_doc, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    # Add checklist nodes & edges to TraceGraph
    for item in flat_items:
        cid = item["id"]
        graph.add_node(cid, "checklist_item", label=f"{cid} (L{item['layer']} {item['mode']}): {item['title']}")
        for dep_id in item["depends_on"]:
            graph.add_edge(cid, dep_id, "depends_on")
        for tid in item["linked"].get("task", []):
            graph.add_edge(cid, tid, "implements")
        for aid in item["linked"].get("ac", []):
            graph.add_edge(cid, aid, "implements")
        for sid in item["linked"].get("story", []):
            graph.add_edge(cid, sid, "implements")

    tracer.log(
        stage="S3",
        event="checklist_planned",
        level="info",
        ids={"chk": [i["id"] for i in flat_items]},
        mode=workflow_mode,
        attempt=1,
        data={
            "workflow_mode": workflow_mode,
            "workflow_reason": workflow_reason,
            "layers": checklist_doc["layers"],
        },
    )

    return checklist_doc
