"""CLI entry point for Cody Handoff JSON -> Traceable Code Generation.

Usage:
    python main.py path/to/handoff.json
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parent
SRC_DIR = ROOT_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

load_dotenv(ROOT_DIR / ".env")

from pipeline.run import run_pipeline


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Cody — Handoff JSON to Traceable Code Generation CLI"
    )
    parser.add_argument(
        "handoff_json",
        nargs="?",
        help="Path to the handoff.json file",
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help="Optional custom run_id for traceability logs",
    )
    args = parser.parse_args(argv)

    if not args.handoff_json:
        parser.print_help()
        return 1

    handoff_path = Path(args.handoff_json).resolve()
    if not handoff_path.exists():
        print(f"Error: handoff file not found: {handoff_path}", file=sys.stderr)
        return 1

    result = asyncio.run(
        run_pipeline(
            handoff_input=handoff_path,
            base_dir=ROOT_DIR,
            run_id=args.run_id,
        )
    )

    summary_out = {
        "run_id": result["run_id"],
        "output_dir": result["output_dir"],
        "logs_dir": result["logs_dir"],
        "status": result["status"],
        "checklist_mode": result["checklist_mode"],
        "passed/total": result["passed_total"],
    }
    print(json.dumps(summary_out, indent=2))
    return 0 if result["status"] != "validation_failed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
