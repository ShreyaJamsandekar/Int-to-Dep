"""Turn a handoff spec (JSON like library_inventory_system.json) or free text into prompt text."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_spec(path: str | None, prompt: str | None) -> tuple[dict | None, str]:
    if path:
        raw = Path(path).read_text(encoding="utf-8")
        try:
            data = json.loads(raw)
            if isinstance(data, dict):
                return data, render_spec(data)
        except json.JSONDecodeError:
            pass
        return None, raw
    if prompt:
        return None, prompt
    raise ValueError("provide a spec file or a prompt")


def _bullets(items: list[dict], keys: tuple[str, ...]) -> str:
    return "\n".join("- " + " | ".join(str(i[k]) for k in keys if i.get(k) not in (None, "")) for i in items)


def render_spec(s: dict[str, Any]) -> str:
    out = [f"# {s.get('project_name', 'Project')}", s.get("description", "")]
    if s.get("domain"):
        out.append(f"Domain: {s['domain']}")
    if ts := s.get("technology_stack"):
        out.append("## Technology stack (mandatory)\n" + "\n".join(f"- {k}: {v}" for k, v in ts.items()))
    if st := s.get("stories"):
        out.append("## User stories\n" + _bullets(st, ("id", "title", "description")))
    if inv := s.get("invariants"):
        out.append("## Invariants (business rules that must always hold)\n" + _bullets(inv, ("id", "title", "description")))
    if ui := s.get("ui"):
        out.append("## UI")
        for k in ("design_system", "roles"):
            if k in ui:
                out.append(f"- {k}: {ui[k]}")
        for sc in ui.get("screens", []):
            out.append(
                f"- {sc.get('id')} {sc.get('name')} [{sc.get('route')}] stories={sc.get('story_ids')}: "
                f"{sc.get('description')} | states={sc.get('states')} | elements={sc.get('elements')}"
            )
    if nf := s.get("nfrs"):
        out.append("## Non-functional requirements\n" + _bullets(nf, ("id", "category", "title", "description")))
    known = {"handoff_id", "handoff_version", "project_name", "domain", "description",
             "technology_stack", "stories", "invariants", "ui", "nfrs"}
    rest = {k: v for k, v in s.items() if k not in known}
    if rest:
        out.append("## Other\n```json\n" + json.dumps(rest, indent=1) + "\n```")
    return "\n\n".join(x for x in out if x)


def per_file_requirements(spec: dict | None, spec_text: str, story_ids: list[str], limit: int = 5000) -> str:
    """The slice of the spec that matters for one file (keeps Cody's prompt small)."""
    if not spec:
        return spec_text[:limit]
    ids = set(story_ids)
    parts = []
    stories = [x for x in spec.get("stories", []) if not ids or x.get("id") in ids]
    if stories:
        parts.append("Stories:\n" + _bullets(stories, ("id", "title", "description")))
    if spec.get("invariants"):
        parts.append("Invariants (enforce those relevant to this file):\n"
                     + _bullets(spec["invariants"], ("id", "title", "description")))
    screens = [sc for sc in spec.get("ui", {}).get("screens", []) if ids & set(sc.get("story_ids", []))]
    if screens:
        parts.append("Screens:\n" + "\n".join(
            f"- {sc['name']} [{sc.get('route')}]: {sc.get('description')} | states={sc.get('states')} "
            f"| elements={sc.get('elements')}" for sc in screens))
    if spec.get("nfrs"):
        parts.append("NFRs:\n" + _bullets(spec["nfrs"], ("id", "title", "description")))
    return "\n\n".join(parts)[:limit]
