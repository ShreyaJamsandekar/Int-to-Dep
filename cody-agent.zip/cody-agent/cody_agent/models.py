"""Pydantic models for the file plan the planner LLM produces."""
from __future__ import annotations

import posixpath
import re

from pydantic import BaseModel, Field, field_validator, model_validator

LANG_BY_EXT = {
    ".go": "Go", ".py": "Python", ".js": "JavaScript", ".mjs": "JavaScript",
    ".ts": "TypeScript", ".html": "HTML", ".css": "CSS", ".sql": "SQL",
    ".java": "Java", ".cpp": "C++", ".h": "C++", ".md": "Markdown",
    ".json": "JSON", ".yaml": "YAML", ".yml": "YAML",
}


def normalize_path(p: str) -> str:
    p = posixpath.normpath(p.strip().replace("\\", "/"))
    while p.startswith("./"):
        p = p[2:]
    if p.startswith("/") or p == ".." or p.startswith("../") or "/../" in p:
        raise ValueError(f"path must be relative and stay inside the project: {p!r}")
    return p


class FilePlan(BaseModel):
    path: str = Field(description="Project-relative POSIX path, e.g. internal/store/store.go")
    purpose: str = Field(description="One or two sentences: what this file is responsible for")
    language: str = Field(default="", description="Derived from the extension if left blank")
    depends_on: list[str] = Field(
        default_factory=list,
        description="Paths of OTHER planned files whose public interface/content this file needs",
    )
    exports: list[str] = Field(
        default_factory=list,
        description="Names of top-level symbols this file must define for others to use",
    )
    story_ids: list[str] = Field(default_factory=list)
    import_ref: str = Field(default="", description="Derived: how other files import this one")

    @field_validator("path")
    @classmethod
    def _path(cls, v: str) -> str:
        return normalize_path(v)

    @field_validator("depends_on")
    @classmethod
    def _deps(cls, v: list[str]) -> list[str]:
        return [normalize_path(x) for x in v]


class ProjectPlan(BaseModel):
    project_name: str
    root_package: str = Field(
        default="app", description="Go module path / top-level Python package / app name"
    )
    conventions: str = Field(
        default="", description="Short rules shared by every file (naming, error handling, JSON shapes, routes)"
    )
    external_dependencies: list[str] = Field(
        default_factory=list, description="Third-party packages allowed, e.g. github.com/mattn/go-sqlite3"
    )
    files: list[FilePlan]

    @model_validator(mode="after")
    def _finalize(self) -> "ProjectPlan":
        if not self.files:
            raise ValueError("plan has no files")
        paths = [f.path for f in self.files]
        dupes = {p for p in paths if paths.count(p) > 1}
        if dupes:
            raise ValueError(f"duplicate file paths: {sorted(dupes)}")
        known = set(paths)
        for f in self.files:
            ext = posixpath.splitext(f.path)[1].lower()
            f.language = LANG_BY_EXT.get(ext) or f.language or "Text"
            unknown = [d for d in f.depends_on if d not in known]
            if unknown:
                raise ValueError(f"{f.path}: depends_on references unplanned files {unknown}")
            f.depends_on = sorted({d for d in f.depends_on if d != f.path})
            f.import_ref = self._import_ref(f)
        return self

    def _import_ref(self, f: FilePlan) -> str:
        d = posixpath.dirname(f.path)
        if f.language == "Go":  # Go imports packages (directories), not files
            return self.root_package if not d else f"{self.root_package}/{d}"
        if f.language == "Python":
            mod = f.path[:-3].replace("/", ".")
            return re.sub(r"\.__init__$", "", mod)
        return f.path

    def file(self, path: str) -> FilePlan:
        return next(f for f in self.files if f.path == path)
