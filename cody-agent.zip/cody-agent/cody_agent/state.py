from __future__ import annotations

from typing import TypedDict


class AgentState(TypedDict, total=False):
    # inputs
    spec_path: str
    prompt: str
    # parsed
    spec: dict | None
    spec_text: str
    # planning / graphify
    plan: dict                 # ProjectPlan.model_dump(), cycle-free after `graphify`
    order: list[str]           # generation order (topological)
    cursor: int                # index into `order`
    # per-file loop
    attempt: int
    candidate: str             # last code returned by Cody
    from_disk: bool
    feedback: list[str]        # validation errors fed back to Cody on retry
    verdict: str               # "retry" | "accept"
    # results
    files: dict[str, dict]     # path -> {code, symbols, attempts, issues}
    warnings: list[str]
    out_dir: str
    summary: str
