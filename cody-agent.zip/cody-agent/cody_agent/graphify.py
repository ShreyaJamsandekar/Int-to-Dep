"""
"Graphify": a file-level dependency graph of the project being generated.

Three jobs:
  1. ORDER      - topological order, so every file is generated after the files it imports.
  2. INTERFACES - after a file is generated, extract its public symbols (signatures, struct
                  fields, SQL tables, HTML ids...). Dependents get these pasted into Cody's
                  prompt, which is how Cody "knows" the other files without seeing them.
  3. VERIFY     - check a freshly generated file's imports/selectors against the graph, so a
                  hallucinated import or function name triggers a retry instead of shipping.
"""
from __future__ import annotations

import ast
import posixpath
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from urllib.parse import urlparse

import networkx as nx

from .models import FilePlan, ProjectPlan


# --------------------------------------------------------------------------- symbols
@dataclass
class Symbol:
    name: str
    kind: str          # func | method | struct | interface | type | const | var | class | table | id | ...
    signature: str
    exported: bool = True

    def to_dict(self) -> dict:
        return asdict(self)


def _cap(text: str, n: int = 1500) -> str:
    return text if len(text) <= n else text[:n] + "\n...[truncated]"


def _go_sig(line: str) -> str:
    """`func F(x interface{}) error { return nil }` -> `func F(x interface{}) error` (drop the body)."""
    depth = 0
    for i, ch in enumerate(line):
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        elif ch == "{" and depth == 0 and not re.search(r"(interface|struct)\s*$", line[:i]):
            return line[:i].rstrip()
    return line.rstrip()


def _go_symbols(code: str) -> list[Symbol]:
    out: list[Symbol] = []
    lines = code.splitlines()
    pkg = re.search(r"^package\s+(\w+)", code, re.M)
    if pkg:
        out.append(Symbol(pkg.group(1), "package", f"package {pkg.group(1)}"))
    i = 0
    while i < len(lines):
        ln = lines[i]
        if m := re.match(r"type\s+(\w+)\s+(struct|interface)\s*\{\s*$", ln):
            block = [ln]
            i += 1
            while i < len(lines) and not lines[i].startswith("}"):
                block.append(lines[i])
                i += 1
            block.append("}")
            out.append(Symbol(m[1], m[2], _cap("\n".join(block)), m[1][0].isupper()))
        elif m := re.match(r"type\s+(\w+)\s+(struct|interface)\b", ln):  # one-line struct/interface
            out.append(Symbol(m[1], m[2], ln.strip(), m[1][0].isupper()))
        elif m := re.match(r"type\s+(\w+)\b", ln):
            out.append(Symbol(m[1], "type", ln.strip(), m[1][0].isupper()))
        elif m := re.match(r"func\s+(\(([^)]*)\)\s*)?(\w+)", ln):
            sig = _go_sig(ln)
            kind = "method" if m[1] else "func"
            out.append(Symbol(m[3], kind, sig, m[3][0].isupper()))
        elif re.match(r"(const|var)\s*\(\s*$", ln):
            block = [ln]
            i += 1
            while i < len(lines) and not lines[i].startswith(")"):
                block.append(lines[i])
                if nm := re.match(r"\s+(\w+)", lines[i]):
                    out.append(Symbol(nm[1], "const", lines[i].strip(), nm[1][0].isupper()))
                i += 1
        elif m := re.match(r"(const|var)\s+(\w+)", ln):
            out.append(Symbol(m[2], m[1], ln.strip(), m[2][0].isupper()))
        i += 1
    return out


def _py_symbols(code: str) -> list[Symbol]:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return [Symbol(m[1], "func", m[0].rstrip(":")) for m in re.finditer(r"^(?:async\s+)?def\s+(\w+)[^\n]*", code, re.M)]
    out: list[Symbol] = []

    def fsig(n: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
        pre = "async def" if isinstance(n, ast.AsyncFunctionDef) else "def"
        ret = f" -> {ast.unparse(n.returns)}" if n.returns else ""
        return f"{pre} {n.name}({ast.unparse(n.args)}){ret}"

    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            out.append(Symbol(n.name, "func", fsig(n), not n.name.startswith("_")))
        elif isinstance(n, ast.ClassDef):
            bases = f"({', '.join(ast.unparse(b) for b in n.bases)})" if n.bases else ""
            body = [f"class {n.name}{bases}:"]
            for b in n.body:
                if isinstance(b, ast.AnnAssign):
                    body.append(f"    {ast.unparse(b)}")
                elif isinstance(b, (ast.FunctionDef, ast.AsyncFunctionDef)) and (
                    not b.name.startswith("_") or b.name == "__init__"
                ):
                    body.append(f"    {fsig(b)}")
            out.append(Symbol(n.name, "class", _cap("\n".join(body)), not n.name.startswith("_")))
        elif isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    out.append(Symbol(t.id, "var", f"{t.id} = {_cap(ast.unparse(n.value), 80)}", not t.id.startswith("_")))
        elif isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name):
            out.append(Symbol(n.target.id, "var", ast.unparse(n), not n.target.id.startswith("_")))
    return out


def _js_symbols(code: str) -> list[Symbol]:
    out: list[Symbol] = []
    lines = code.splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i]
        exp = bool(re.match(r"export\b", ln))
        if m := re.match(r"(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*(\w+)\s*\(([^)]*)\)", ln):
            out.append(Symbol(m[1], "func", f"function {m[1]}({m[2].strip()})", True))
        elif m := re.match(r"(?:export\s+)?(?:default\s+)?class\s+(\w+)(\s+extends\s+[\w.]+)?", ln):
            methods = []
            j = i + 1
            while j < len(lines) and not lines[j].startswith("}"):
                if mm := re.match(r"\s+((?:static\s+)?(?:async\s+)?(?!if\b|for\b|while\b|switch\b|catch\b)\w+)\s*\(([^)]*)\)\s*\{", lines[j]):
                    methods.append(f"  {mm[1]}({mm[2].strip()})")
                j += 1
            sig = f"class {m[1]}{m[2] or ''} " + "{\n" + "\n".join(methods) + "\n}"
            out.append(Symbol(m[1], "class", _cap(sig), True))
        elif m := re.match(r"(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:\(([^)]*)\)|(\w+))\s*=>", ln):
            out.append(Symbol(m[1], "func", f"const {m[1]} = ({(m[2] if m[2] is not None else m[3]).strip()}) =>", True))
        elif m := re.match(r"(?:export\s+)?(const|let|var)\s+(\w+)\s*=", ln):
            out.append(Symbol(m[2], "var", ln.strip()[:120], True))
        elif m := re.match(r"export\s*\{([^}]*)\}", ln):
            for part in m[1].split(","):
                nm = part.strip().split(" as ")[-1].strip()
                if nm:
                    out.append(Symbol(nm, "var", f"export {{ {nm} }}", True))
        elif m := re.match(r"module\.exports\s*=\s*\{([^}]*)\}", ln):
            for part in m[1].split(","):
                nm = part.strip().split(":")[0].strip()
                if nm:
                    out.append(Symbol(nm, "var", f"module.exports.{nm}", True))
        elif m := re.match(r"exports\.(\w+)\s*=", ln):
            out.append(Symbol(m[1], "var", f"exports.{m[1]}", True))
        elif exp and re.match(r"export\s+default\b", ln):
            out.append(Symbol("default", "var", ln.strip()[:120], True))
        i += 1
    seen, uniq = set(), []
    for s in out:  # keep first occurrence
        if (s.name, s.kind) not in seen:
            seen.add((s.name, s.kind))
            uniq.append(s)
    return uniq


def _html_symbols(code: str) -> list[Symbol]:
    out: list[Symbol] = []
    for m in re.finditer(r"<(\w+)\b[^>]*?\bid\s*=\s*[\"']([^\"']+)[\"']", code):
        out.append(Symbol(m[2], "id", f"#{m[2]}  <{m[1].lower()}>"))
    for m in re.finditer(r"<(input|select|textarea|button)\b[^>]*?\bname\s*=\s*[\"']([^\"']+)[\"']", code):
        out.append(Symbol(m[2], "field", f"[name={m[2]}]  <{m[1].lower()}>"))
    classes: list[str] = []
    for m in re.finditer(r"\bclass\s*=\s*[\"']([^\"']+)[\"']", code):
        for c in m[1].split():
            if c not in classes:
                classes.append(c)
    for c in classes[:80]:
        out.append(Symbol(c, "class", f".{c}"))
    for m in re.finditer(r"<script[^>]+\bsrc\s*=\s*[\"']([^\"']+)[\"']", code):
        out.append(Symbol(m[1], "script", f'<script src="{m[1]}">'))
    for m in re.finditer(r"<link[^>]+\bhref\s*=\s*[\"']([^\"']+)[\"']", code):
        out.append(Symbol(m[1], "stylesheet", f'<link href="{m[1]}">'))
    return out


def _css_symbols(code: str) -> list[Symbol]:
    out, seen = [], set()
    for sel in re.findall(r"([^{}]+)\{", re.sub(r"/\*.*?\*/", "", code, flags=re.S)):
        for c in re.findall(r"\.([A-Za-z_][\w-]*)", sel):
            if c not in seen:
                seen.add(c)
                out.append(Symbol(c, "class", f".{c}"))
    for v in dict.fromkeys(re.findall(r"(--[\w-]+)\s*:", code)):
        out.append(Symbol(v, "var", f"{v}: ..."))
    return out


def _sql_symbols(code: str) -> list[Symbol]:
    out = []
    pat = r"CREATE\s+(?:UNIQUE\s+)?(TABLE|VIEW|INDEX)\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w.\"`]+)(.*?);"
    for m in re.finditer(pat, code, re.S | re.I):
        out.append(Symbol(m[2].strip('"`'), m[1].lower(), _cap(m[0].strip(), 1800)))
    return out


def extract_symbols(language: str, code: str) -> list[Symbol]:
    fn = {"Go": _go_symbols, "Python": _py_symbols, "JavaScript": _js_symbols, "TypeScript": _js_symbols,
          "HTML": _html_symbols, "CSS": _css_symbols, "SQL": _sql_symbols}.get(language)
    if fn:
        return fn(code)
    head = "\n".join(code.splitlines()[:15])
    return [Symbol("(content)", "text", head)]


def render_interface(f: FilePlan, symbols: list[dict], max_chars: int) -> str:
    """Compact text description of a generated file, pasted into prompts of its dependents."""
    syms = [Symbol(**s) for s in symbols]
    if f.language == "Go":
        pkg = next((s.name for s in syms if s.kind == "package"), "?")
        head = f"package {pkg}   // import \"{f.import_ref}\""
        body = [s.signature for s in syms if s.kind != "package" and (s.exported or s.kind in ("struct", "interface"))]
    elif f.language == "Python":
        head = f"module {f.import_ref}"
        body = [s.signature for s in syms if s.exported]
    elif f.language in ("JavaScript", "TypeScript"):
        head = f"module {f.path}"
        body = [s.signature for s in syms]
    elif f.language == "HTML":
        head = f"HTML page {f.path} (DOM hooks you may rely on)"
        body = [s.signature for s in syms]
    elif f.language == "CSS":
        head = f"stylesheet {f.path} (defined selectors)"
        body = [s.signature for s in syms]
    else:
        head = f"{f.language} file {f.path}"
        body = [s.signature for s in syms]
    text = head + "\n" + "\n".join(body)
    return text if len(text) <= max_chars else text[:max_chars] + "\n...[interface truncated]"


# --------------------------------------------------------------------------- the graph
class CodeGraph:
    """Edge dep -> dependent means: `dep` must exist before `dependent` is generated."""

    def __init__(self, plan: ProjectPlan):
        self.plan = plan
        self.g = nx.DiGraph()
        self.g.add_nodes_from(f.path for f in plan.files)
        for f in plan.files:
            for d in f.depends_on:
                self.g.add_edge(d, f.path)
        self.removed_edges = self._break_cycles()
        for f in plan.files:  # write the cycle-free edge set back into the plan
            f.depends_on = sorted(self.g.predecessors(f.path))

    def _break_cycles(self) -> list[tuple[str, str]]:
        removed = []
        while True:
            try:
                cycle = nx.find_cycle(self.g)
            except nx.NetworkXNoCycle:
                return removed
            u, v = cycle[-1][:2]
            self.g.remove_edge(u, v)
            removed.append((u, v))

    def order(self) -> list[str]:
        return list(nx.lexicographical_topological_sort(self.g))

    def deps(self, path: str) -> list[str]:
        return sorted(self.g.predecessors(path))

    def edges(self) -> list[tuple[str, str]]:
        return sorted(self.g.edges)

    def package_files(self, import_ref: str) -> list[FilePlan]:
        return [f for f in self.plan.files if f.import_ref == import_ref]

    def mermaid(self) -> str:
        ids = {p: f"n{i}" for i, p in enumerate(sorted(self.g.nodes))}
        lines = ["graph LR"] + [f'  {i}["{p}"]' for p, i in ids.items()]
        lines += [f"  {ids[v]} --> {ids[u]}" for u, v in self.edges()]  # importer --> imported
        return "\n".join(lines)


# --------------------------------------------------------------------------- imports
@dataclass
class Import:
    spec: str
    names: list[str] = field(default_factory=list)
    alias: str = ""
    level: int = 0       # python relative level


def extract_imports(language: str, code: str) -> list[Import]:
    out: list[Import] = []
    if language == "Go":
        block = re.search(r"^import\s*\((.*?)^\)", code, re.S | re.M)
        entries = re.findall(r'^\s*(?:(\w+|\.|_)\s+)?"([^"]+)"', block[1], re.M) if block else []
        entries += re.findall(r'^import\s+(?:(\w+|\.|_)\s+)?"([^"]+)"', code, re.M)
        out = [Import(spec=s, alias=a) for a, s in entries]
    elif language == "Python":
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return []
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom):
                out.append(Import(spec=n.module or "", names=[a.name for a in n.names], level=n.level))
            elif isinstance(n, ast.Import):
                out += [Import(spec=a.name) for a in n.names]
    elif language in ("JavaScript", "TypeScript"):
        for m in re.finditer(r"import\s+(?:([\w$]+)\s*,?\s*)?(?:\{([^}]*)\}\s*)?(?:\*\s+as\s+[\w$]+\s*)?from\s*['\"]([^'\"]+)['\"]", code):
            names = [p.strip().split(" as ")[0].strip() for p in (m[2] or "").split(",") if p.strip()]
            out.append(Import(spec=m[3], names=names))
        for m in re.finditer(r"^\s*import\s*['\"]([^'\"]+)['\"]", code, re.M):
            out.append(Import(spec=m[1]))
        for m in re.finditer(r"(?:const|let|var)\s*\{([^}]*)\}\s*=\s*require\(\s*['\"]([^'\"]+)['\"]\s*\)", code):
            out.append(Import(spec=m[2], names=[p.strip().split(":")[0].strip() for p in m[1].split(",") if p.strip()]))
        for m in re.finditer(r"(?:const|let|var)\s+[\w$]+\s*=\s*require\(\s*['\"]([^'\"]+)['\"]\s*\)", code):
            out.append(Import(spec=m[1]))
    elif language == "HTML":
        for m in re.finditer(r"<script[^>]+\bsrc\s*=\s*[\"']([^\"']+)[\"']", code):
            out.append(Import(spec=m[1]))
        for m in re.finditer(r"<link[^>]+\bhref\s*=\s*[\"']([^\"']+)[\"']", code):
            out.append(Import(spec=m[1]))
    return out


# --------------------------------------------------------------------------- validation
@dataclass
class Issue:
    level: str   # "error" blocks and triggers a Cody retry; "warn" is reported only
    message: str


def _is_web_external(spec: str) -> bool:
    return bool(urlparse(spec).scheme) or spec.startswith("//") or spec.startswith("data:")


def _resolve_web(plan: ProjectPlan, from_path: str, spec: str, strict: bool = False) -> str | None:
    spec = spec.split("?")[0].split("#")[0]
    paths = {f.path for f in plan.files}
    base = posixpath.dirname(from_path)
    cands = [posixpath.normpath(posixpath.join(base, spec))] if not spec.startswith("/") else []
    cands += [spec.lstrip("/")]
    ext_try = ["", ".js", ".mjs", "/index.js"]
    for c in cands:
        for e in ext_try:
            if c + e in paths:
                return c + e
    if strict:
        return None
    tail = spec.lstrip("./").lstrip("/")  # served from a web root: match by suffix
    return next((p for p in sorted(paths) if tail and (p == tail or p.endswith("/" + tail))), None)


def check_imports(
    plan: ProjectPlan,
    graph: CodeGraph,
    f: FilePlan,
    code: str,
    generated: dict[str, list[dict]],
) -> list[Issue]:
    """Verify imports/selectors against the graph. `generated` maps path -> extracted symbols."""
    issues: list[Issue] = []
    deps = set(graph.deps(f.path))
    ext_prefixes = tuple(plan.external_dependencies)
    syms_of = lambda p: {s["name"] for s in generated.get(p, [])}  # noqa: E731

    def note_undeclared(target_paths: list[str], label: str) -> None:
        if target_paths and not (set(target_paths) & deps) and f.language != "HTML":
            issues.append(Issue("warn", f"{f.path} imports {label} but does not declare it in depends_on, "
                                        "so its interface was not provided to Cody."))

    if f.language == "Go":
        root = plan.root_package
        for imp in extract_imports("Go", code):
            s = imp.spec
            if s == root or s.startswith(root + "/"):
                pkg_files = graph.package_files(s)
                if not pkg_files:
                    known = sorted({p.import_ref for p in plan.files if p.language == "Go"})
                    issues.append(Issue("error", f'import "{s}" does not exist in this project. '
                                                 f"Valid internal packages: {known}"))
                    continue
                if s == f.import_ref:
                    issues.append(Issue("error", f'file imports its own package "{s}"; call its symbols directly.'))
                    continue
                note_undeclared([p.path for p in pkg_files], f'"{s}"')
                if all(p.path in generated for p in pkg_files) and imp.alias not in (".", "_"):
                    pkg_name = next((x["name"] for p in pkg_files for x in generated[p.path] if x["kind"] == "package"),
                                    s.rsplit("/", 1)[-1])
                    alias = imp.alias or pkg_name
                    available = {x["name"] for p in pkg_files for x in generated[p.path] if x["kind"] != "method"}
                    for used in sorted(set(re.findall(rf"\b{re.escape(alias)}\.([A-Z]\w*)", code))):
                        if used not in available:
                            issues.append(Issue("error", f"{alias}.{used} is not defined in package {s}. "
                                                         f"Exported names there: {sorted(n for n in available if n[:1].isupper())}"))
            elif "." in s.split("/")[0] and not s.startswith(ext_prefixes or ("\0",)):
                issues.append(Issue("warn", f'imports third-party "{s}" which is not in external_dependencies.'))
        if not re.search(r"^package\s+\w+", code, re.M):
            issues.append(Issue("error", "missing `package` clause."))

    elif f.language == "Python":
        roots = {p.import_ref.split(".")[0] for p in plan.files if p.language == "Python"}
        pkg = f.import_ref.rsplit(".", 1)[0] if "." in f.import_ref else ""
        for imp in extract_imports("Python", code):
            mod = imp.spec
            if imp.level:
                parts = pkg.split(".") if pkg else []
                parts = parts[: len(parts) - (imp.level - 1)] if imp.level > 1 else parts
                mod = ".".join(parts + ([imp.spec] if imp.spec else []))
            if mod.split(".")[0] not in roots:
                if mod.split(".")[0] not in sys.stdlib_module_names and mod and plan.external_dependencies and \
                        mod.split(".")[0].lower() not in {d.split("[")[0].replace("-", "_").lower() for d in plan.external_dependencies}:
                    issues.append(Issue("warn", f"imports third-party module `{mod}` not listed in external_dependencies."))
                continue
            targets = [p for p in plan.files if p.language == "Python" and p.import_ref == mod]
            sub = {n: p for n in imp.names for p in plan.files if p.language == "Python" and p.import_ref == f"{mod}.{n}"}
            if not targets and not (imp.names and len(sub) == len(imp.names)):
                known = sorted(p.import_ref for p in plan.files if p.language == "Python")
                issues.append(Issue("error", f"module `{mod}` does not exist in this project. Valid modules: {known}"))
                continue
            note_undeclared([p.path for p in targets] + [p.path for p in sub.values()], f"`{mod}`")
            for t in targets:
                if t.path in generated:
                    missing = [n for n in imp.names if n != "*" and n not in syms_of(t.path) and n not in sub]
                    if missing:
                        issues.append(Issue("error", f"`from {mod} import {', '.join(missing)}`: not defined in {t.path}. "
                                                     f"Available: {sorted(syms_of(t.path))}"))
        try:
            ast.parse(code)
        except SyntaxError as e:
            issues.append(Issue("error", f"Python syntax error: {e}"))

    elif f.language in ("JavaScript", "TypeScript"):
        for imp in extract_imports(f.language, code):
            if not imp.spec.startswith("."):
                continue
            target = _resolve_web(plan, f.path, imp.spec, strict=True)
            if not target or target == f.path:
                issues.append(Issue("error", f"import '{imp.spec}' does not match any planned file. "
                                             f"Planned: {sorted(p.path for p in plan.files if p.language == f.language)}"))
                continue
            note_undeclared([target], f"'{imp.spec}'")
            if target in generated and imp.names:
                missing = [n for n in imp.names if n not in syms_of(target)]
                if missing:
                    issues.append(Issue("error", f"import {{ {', '.join(missing)} }} from '{imp.spec}': not exported by {target}. "
                                                 f"Available: {sorted(syms_of(target))}"))

    elif f.language == "HTML":
        for imp in extract_imports("HTML", code):
            if _is_web_external(imp.spec) or imp.spec.startswith("#"):
                continue
            if not _resolve_web(plan, f.path, imp.spec):
                issues.append(Issue("error", f"references '{imp.spec}' which is not a planned file. "
                                             f"Planned assets: {sorted(p.path for p in plan.files if p.language in ('JavaScript', 'CSS'))}"))

    # contract: symbols the plan promised other files would find here
    if f.language in ("Go", "Python", "JavaScript", "TypeScript") and f.exports:
        have = {s.name for s in extract_symbols(f.language, code)}
        missing = [e for e in f.exports if e not in have]
        if missing:
            issues.append(Issue("error", f"must define these top-level symbols that other files rely on: {missing}"))
    return issues


def syntax_check(language: str, code: str) -> list[Issue]:
    """Best-effort native syntax check; silently skipped if the toolchain isn't installed."""
    try:
        if language == "Go" and (gofmt := shutil.which("gofmt")):
            r = subprocess.run([gofmt, "-e"], input=code, capture_output=True, text=True, timeout=30)
            if r.returncode != 0:
                return [Issue("error", f"gofmt syntax error: {r.stderr.strip()[:600]}")]
        elif language == "JavaScript" and (node := shutil.which("node")):
            is_esm = bool(re.search(r"^\s*(import|export)\s", code, re.M))
            with tempfile.TemporaryDirectory() as d:
                p = Path(d) / ("m.mjs" if is_esm else "m.js")
                p.write_text(code)
                r = subprocess.run([node, "--check", str(p)], capture_output=True, text=True, timeout=30)
            if r.returncode != 0:
                return [Issue("error", f"node syntax error: {r.stderr.strip()[:600]}")]
    except (subprocess.SubprocessError, OSError):
        pass
    return []


def normalize_code(language: str, code: str) -> str:
    """Cody strips ``` fences but can leave chatty prose; trim what we can identify safely."""
    code = re.sub(r"```[a-zA-Z0-9+_-]*", "", code).strip("\n")
    if language == "Go":
        if m := re.search(r"^package\s+\w+", code, re.M):
            code = code[m.start():]
    elif language == "HTML":
        if m := re.search(r"<!doctype|<html", code, re.I):
            code = code[m.start():]
        if (m := list(re.finditer(r"</html>", code, re.I))):
            code = code[: m[-1].end()]
    return code.strip() + "\n"
