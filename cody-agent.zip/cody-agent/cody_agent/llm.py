"""Planner LLM factory. Any LangChain chat model works; these are the common ones."""
from __future__ import annotations

import os

from .config import Settings


def get_llm(s: Settings):
    p = s.llm_provider.lower()
    if p == "anthropic":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(model=s.llm_model, temperature=s.llm_temperature, max_tokens=8000)
    if p == "openrouter":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=s.llm_model, temperature=s.llm_temperature,
                          api_key=os.getenv("OPENROUTER_API_KEY"), base_url="https://openrouter.ai/api/v1")
    if p == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=s.llm_model, temperature=s.llm_temperature)
    if p == "ollama":
        from langchain_ollama import ChatOllama
        return ChatOllama(model=s.llm_model, temperature=s.llm_temperature,
                          base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
    raise ValueError(f"unknown LLM_PROVIDER {s.llm_provider!r}")
