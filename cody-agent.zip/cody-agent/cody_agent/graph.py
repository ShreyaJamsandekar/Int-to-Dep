from __future__ import annotations

from langgraph.graph import END, START, StateGraph

from .config import Settings
from .cody_tool import make_cody_tool
from .llm import get_llm
from .nodes import make_nodes
from .state import AgentState


def build_agent(settings: Settings | None = None, llm=None, cody_tool=None):
    """Compile the LangGraph agent. Inject `llm` / `cody_tool` to customise or to test."""
    settings = settings or Settings()
    llm = llm or get_llm(settings)
    cody_tool = cody_tool or make_cody_tool(settings)
    n = make_nodes(settings, llm, cody_tool)

    g = StateGraph(AgentState)
    for name, fn in n.items():
        g.add_node(name, fn)

    g.add_edge(START, "load_spec")
    g.add_edge("load_spec", "plan_files")
    g.add_edge("plan_files", "graphify")
    g.add_edge("graphify", "generate_file")
    g.add_edge("generate_file", "check_file")
    g.add_conditional_edges("check_file", lambda s: s["verdict"],
                            {"retry": "generate_file", "accept": "commit_file"})
    g.add_conditional_edges("commit_file",
                            lambda s: "more" if s["cursor"] < len(s["order"]) else "done",
                            {"more": "generate_file", "done": "finalize"})
    g.add_edge("finalize", END)
    return g.compile()


def run(spec_path: str | None = None, prompt: str | None = None, settings: Settings | None = None, **kw) -> dict:
    settings = settings or Settings()
    agent = build_agent(settings, **kw)
    return agent.invoke({"spec_path": spec_path, "prompt": prompt}, config={"recursion_limit": 2000})
