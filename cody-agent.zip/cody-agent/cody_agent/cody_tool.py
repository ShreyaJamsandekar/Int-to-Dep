"""Cody as a LangChain tool: POST {CODY_URL}/generate_code  ->  {"code": ..., "timetaken": ...}"""
from __future__ import annotations

import logging
import time

import httpx
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from .config import Settings

log = logging.getLogger("cody_agent")


class CodyError(RuntimeError):
    pass


class CodyInput(BaseModel):
    language: str = Field(description="Language label, e.g. Go, Python, JavaScript, HTML, CSS, SQL")
    requirement: str = Field(
        description="Complete, self-contained instructions for ONE file, including the interfaces "
                    "of any files it imports. Cody sees nothing else."
    )


def check_cody(settings: Settings) -> None:
    """Fail fast with a readable message if the Cody API is not reachable."""
    try:
        r = httpx.get(settings.cody_url.rstrip("/") + "/", timeout=10)
        r.raise_for_status()
    except httpx.HTTPError as e:
        raise CodyError(
            f"Cannot reach Cody at {settings.cody_url} ({e}). Start it with "
            "`cd src && uvicorn main:app --port 7777` (or docker compose up) and set CODY_URL."
        ) from e


def make_cody_tool(settings: Settings) -> StructuredTool:
    endpoint = settings.cody_url.rstrip("/") + "/generate_code"

    def cody_generate_code(language: str, requirement: str) -> str:
        last: Exception | None = None
        for attempt in range(settings.cody_retries + 1):
            try:
                r = httpx.post(endpoint, json={"language": language, "requirement": requirement},
                               timeout=settings.cody_timeout)
                r.raise_for_status()
                body = r.json()
                log.info("cody answered in %s", body.get("timetaken", "?"))
                return body["code"]
            except httpx.HTTPStatusError as e:
                last = e
                if e.response.status_code < 500 and e.response.status_code != 429:
                    break  # 4xx: retrying the same request won't help
            except (httpx.TransportError, KeyError, ValueError) as e:
                last = e
            if attempt < settings.cody_retries:
                wait = 2 * 2**attempt
                log.warning("cody call failed (%s); retrying in %ss", last, wait)
                time.sleep(wait)
        raise CodyError(f"Cody request failed after {settings.cody_retries + 1} attempts: {last}")

    return StructuredTool.from_function(
        func=cody_generate_code,
        name="cody_generate_code",
        description=(
            "Generate the source code of a single file with the Cody multi-agent service "
            "(developer -> tester -> reviewer). Put everything Cody must know in `requirement`."
        ),
        args_schema=CodyInput,
    )
