from __future__ import annotations

from .graphify import CodeGraph, render_interface
from .models import FilePlan, ProjectPlan
from .spec import per_file_requirements

PLANNER_SYSTEM = """You are a software architect. Turn the specification into a FILE PLAN that a code
generator will follow, one file at a time, in dependency order. The generator is a small LLM that only
sees (a) the file's own instructions and (b) the public interfaces of the files you list in `depends_on`.

Return ONLY one JSON object, no prose, no code fences, with this shape:
{
  "project_name": "...",
  "root_package": "Go module path (e.g. library) or top-level Python package",
  "conventions": "5-12 short lines every file must follow: naming, JSON field names, error format, route table, DB column names, ...",
  "external_dependencies": ["third-party packages allowed, if any"],
  "files": [
    {"path": "internal/store/store.go", "purpose": "...", "depends_on": ["db/schema.sql"],
     "exports": ["Store", "NewStore"], "story_ids": ["ST-001"]}
  ]
}

Rules:
- Follow the mandated technology stack exactly. Use the idiomatic project layout for it.
- Keep files small and cohesive (about 250 lines max). Prefer more small files over one big file.
- `depends_on` = other planned files whose CONTENT this file needs: things it imports/calls, the SQL schema a
  data layer queries, the HTML whose element ids a script uses, the HTML whose classes a stylesheet styles.
  A file merely referenced by path (e.g. <script src>) does NOT need to be a dependency.
- The graph must be acyclic. Put shared types in a leaf file. HTML is generated BEFORE the JS/CSS that targets it.
- `exports` = exact top-level names (functions, types, classes) other files will use. Be precise: they are checked.
- Go: one directory = one package; all files in a directory share a package; entrypoints live in cmd/<name>/main.go.
  Do not plan go.mod; it is scaffolded for you. `root_package` is the module path used in internal imports.
- Do not plan README, tests, requirements.txt or lock files.
- Business rules (invariants) belong in the service/data layer, not only in the UI.
- Every story, screen and invariant must be covered by at least one file (use story_ids).
- Put API routes, JSON shapes and DB table/column names in `conventions` so independent files agree.
"""


def planner_user(spec_text: str) -> str:
    return f"SPECIFICATION\n=============\n{spec_text}\n\nReturn the JSON file plan now."


def build_requirement(
    plan: ProjectPlan,
    graph: CodeGraph,
    f: FilePlan,
    files: dict[str, dict],
    spec: dict | None,
    spec_text: str,
    interface_max_chars: int,
    feedback: list[str] | None = None,
    previous_code: str = "",
) -> str:
    """Everything Cody needs, in one string. This is where the graph pays off."""
    file_map = "\n".join(
        f"- {p.path} [{p.language}]" + (f" import as \"{p.import_ref}\"" if p.language in ("Go", "Python") else "")
        + f": {p.purpose}"
        for p in plan.files
    )
    dep_blocks = []
    for d in graph.deps(f.path):
        dp = plan.file(d)
        if d in files:
            iface = render_interface(dp, files[d]["symbols"], interface_max_chars)
            dep_blocks.append(f"### {d}\n{iface}")
    deps_txt = "\n\n".join(dep_blocks) or "(none - this file has no dependencies)"

    rules = [
        f"Write ONLY the complete contents of the single file `{f.path}`. No other files, no tests, no explanations.",
        "Do not add example usage or a main function unless this file is the program entrypoint.",
        "Import ONLY from the standard library, the allowed third-party packages, and the DEPENDENCIES below, "
        "using EXACTLY the import paths and symbol names shown there. Never invent functions, fields or modules.",
    ]
    if f.language == "Go":
        rules.append(f"The Go module path is `{plan.root_package}`. Internal imports must start with it.")
    if f.exports:
        rules.append(f"This file MUST define these top-level names exactly: {', '.join(f.exports)}.")

    out = [
        "You are generating ONE file of a multi-file project.",
        "RULES:\n" + "\n".join(f"- {r}" for r in rules),
        f"PROJECT: {plan.project_name}  (root package/module: {plan.root_package})",
        f"CONVENTIONS (all files obey these):\n{plan.conventions or '(none)'}",
        f"ALLOWED THIRD-PARTY PACKAGES: {', '.join(plan.external_dependencies) or 'none (standard library only)'}",
        f"FILE TO WRITE: {f.path}  [{f.language}]"
        + (f"\nOther files import it as: \"{f.import_ref}\""
           if f.language in ("Go", "Python") and not f.path.startswith("cmd/") else ""),
        f"PURPOSE: {f.purpose}",
        f"RELEVANT REQUIREMENTS:\n{per_file_requirements(spec, spec_text, f.story_ids)}",
        f"PROJECT FILE MAP (these are the only files that exist):\n{file_map}",
        f"DEPENDENCIES (already written - use exactly these interfaces):\n{deps_txt}",
    ]
    if feedback:
        out.append("YOUR PREVIOUS ATTEMPT WAS REJECTED. Fix every problem below:\n"
                   + "\n".join(f"- {m}" for m in feedback))
        if previous_code:
            out.append("PREVIOUS ATTEMPT (fix it, do not start from scratch):\n" + previous_code[:12000])
    return "\n\n".join(out)
