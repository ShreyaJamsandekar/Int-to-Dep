"""Runtime settings, read from environment variables / .env."""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()


def _f(name: str, default: str) -> str:
    return os.getenv(name, default)


@dataclass
class Settings:
    # Cody service
    cody_url: str = field(default_factory=lambda: _f("CODY_URL", "http://localhost:7777"))
    cody_timeout: float = field(default_factory=lambda: float(_f("CODY_TIMEOUT", "900")))
    cody_retries: int = field(default_factory=lambda: int(_f("CODY_RETRIES", "2")))

    # Planner LLM
    llm_provider: str = field(default_factory=lambda: _f("LLM_PROVIDER", "anthropic"))
    llm_model: str = field(default_factory=lambda: _f("LLM_MODEL", "claude-sonnet-5-5"))
    llm_temperature: float = 0.0

    # Agent behaviour
    max_file_attempts: int = field(default_factory=lambda: int(_f("MAX_FILE_ATTEMPTS", "3")))
    plan_attempts: int = 3
    out_dir: str = field(default_factory=lambda: _f("OUT_DIR", "generated"))
    # cap for how much of a dependency's interface is pasted into Cody's prompt
    interface_max_chars: int = 6000
    # re-use files already on disk instead of calling Cody again
    resume: bool = False
