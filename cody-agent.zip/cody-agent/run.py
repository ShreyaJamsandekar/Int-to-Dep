#!/usr/bin/env python3
"""python run.py --spec examples/library_inventory_system.json --out generated"""
import argparse
import logging
import sys

from cody_agent import Settings, build_agent


def main() -> int:
    ap = argparse.ArgumentParser(description="Generate a multi-file project with Cody, ordered by a dependency graph.")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--spec", help="handoff spec JSON (or any text file)")
    src.add_argument("--prompt", help="plain-text requirement")
    ap.add_argument("--out", help="output directory (default OUT_DIR / generated)")
    ap.add_argument("--cody-url", help="override CODY_URL")
    ap.add_argument("--max-attempts", type=int, help="Cody retries per file")
    ap.add_argument("--resume", action="store_true", help="keep files already on disk, only generate the rest")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()

    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s", datefmt="%H:%M:%S")
    logging.getLogger("httpx").setLevel(logging.WARNING)

    s = Settings()
    if a.out: s.out_dir = a.out
    if a.cody_url: s.cody_url = a.cody_url
    if a.max_attempts: s.max_file_attempts = a.max_attempts
    s.resume = a.resume

    agent = build_agent(s)
    result = agent.invoke({"spec_path": a.spec, "prompt": a.prompt}, config={"recursion_limit": 2000})
    print("\n" + result["summary"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
