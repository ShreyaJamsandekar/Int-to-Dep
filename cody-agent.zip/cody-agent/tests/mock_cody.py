"""A stand-in for the real Cody API (same contract) so the agent can be tested without an LLM."""
import re
import threading
import time

import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel


class Req(BaseModel):
    language: str
    requirement: str


def make_app(responses: dict[str, list[str]], log: list[dict]) -> FastAPI:
    app = FastAPI()

    @app.get("/")
    def health():
        return {"status": "API is running"}

    @app.post("/generate_code")
    def gen(r: Req):
        path = re.search(r"FILE TO WRITE: (\S+)", r.requirement).group(1)
        log.append({"path": path, "language": r.language, "requirement": r.requirement})
        queue = responses[path]
        code = queue.pop(0) if len(queue) > 1 else queue[0]
        # mimic Cody's own post-processing: it wraps in fences, then strips them server-side
        return {"code": code, "timetaken": "0.01 seconds"}

    return app


def free_port() -> int:
    import socket
    with socket.socket() as sk:
        sk.bind(("127.0.0.1", 0))
        return sk.getsockname()[1]


def start(app: FastAPI, port: int) -> uvicorn.Server:
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(100):
        if server.started:
            return server
        time.sleep(0.05)
    raise RuntimeError("mock cody did not start")
