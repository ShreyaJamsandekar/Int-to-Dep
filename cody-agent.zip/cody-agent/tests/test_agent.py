import json
from pathlib import Path

import pytest
from langchain_core.language_models.fake_chat_models import FakeListChatModel

from cody_agent import CodeGraph, Settings, build_agent
from cody_agent.graphify import check_imports, extract_symbols
from cody_agent.models import ProjectPlan
from tests.mock_cody import free_port, make_app, start

SCHEMA = """CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  isbn TEXT NOT NULL UNIQUE,
  available_copies INTEGER NOT NULL
);
"""

STORE = """package store

import "database/sql"

type Book struct {
	ID              int64  `json:"id"`
	Title           string `json:"title"`
	AvailableCopies int    `json:"available_copies"`
}

type Store struct{ db *sql.DB }

func NewStore(db *sql.DB) *Store { return &Store{db: db} }

func (s *Store) ListBooks(q string) ([]Book, error) { return nil, nil }
"""

MAIN_BAD = """package main

import (
	"database/sql"
	"library/internal/store"
)

func main() {
	db, _ := sql.Open("sqlite3", "x.db")
	_ = store.NewBookStore(db)
}
"""

MAIN_GOOD = MAIN_BAD.replace("NewBookStore", "NewStore")

HTML = """<!doctype html><html><head><link rel="stylesheet" href="styles.css"></head>
<body><input id="book-search"><ul id="book-list"></ul><script src="app.js"></script></body></html>"""

JS_BAD = "import { api } from './api.js';\nexport function loadBooks() { return api(); }\n"
JS_GOOD = "export function loadBooks() { document.getElementById('book-list'); }\n"
CSS = "#book-list { margin: 0; }\n.card { padding: 1rem; }\n"


def plan_json():
    F = lambda path, purpose, deps=(), exports=(): dict(path=path, purpose=purpose, depends_on=list(deps), exports=list(exports))
    return json.dumps({
        "project_name": "Library Test", "root_package": "library",
        "conventions": "JSON snake_case", "external_dependencies": ["github.com/mattn/go-sqlite3"],
        "files": [
            F("cmd/server/main.go", "entrypoint", ["internal/store/store.go"]),
            F("web/app.js", "ui logic", ["web/index.html"], ["loadBooks"]),
            F("internal/store/store.go", "data layer", ["db/schema.sql"], ["Store", "NewStore", "Book"]),
            F("web/index.html", "page"),
            F("web/styles.css", "styles", ["web/index.html"]),
            F("db/schema.sql", "schema"),
        ]})


@pytest.fixture()
def env(tmp_path):
    log: list[dict] = []
    responses = {
        "db/schema.sql": [SCHEMA], "internal/store/store.go": [STORE],
        "cmd/server/main.go": [MAIN_BAD, MAIN_GOOD],
        "web/index.html": [HTML], "web/app.js": [JS_BAD, JS_GOOD], "web/styles.css": [CSS],
    }
    port = free_port()
    server = start(make_app(responses, log), port)
    s = Settings(cody_url=f"http://127.0.0.1:{port}", out_dir=str(tmp_path), max_file_attempts=3, cody_retries=0)
    yield s, log, tmp_path
    server.should_exit = True


def test_end_to_end(env):
    s, log, tmp = env
    agent = build_agent(s, llm=FakeListChatModel(responses=[plan_json()]))
    out = agent.invoke({"spec_path": "examples/library_inventory_system.json"}, config={"recursion_limit": 500})
    root = tmp / "library-test"

    # 1. generation order respects the graph
    order = out["order"]
    assert order.index("db/schema.sql") < order.index("internal/store/store.go") < order.index("cmd/server/main.go")
    assert order.index("web/index.html") < order.index("web/app.js")
    assert order.index("web/index.html") < order.index("web/styles.css")

    # 2. every file was written, plus scaffolding + graph metadata
    for p in order:
        assert (root / p).exists(), p
    assert (root / "go.mod").read_text().startswith("module library")
    assert (root / ".cody_agent/graph.json").exists() and (root / ".cody_agent/graph.mmd").exists()

    # 3. dependency interfaces were pasted into dependents' prompts
    by_path = {}
    for r in log:
        by_path.setdefault(r["path"], []).append(r["requirement"])
    assert "CREATE TABLE IF NOT EXISTS books" in by_path["internal/store/store.go"][0]
    main_first = by_path["cmd/server/main.go"][0]
    assert 'package store   // import "library/internal/store"' in main_first
    assert "func NewStore(db *sql.DB) *Store" in main_first
    assert "#book-list" in by_path["web/app.js"][0]
    deps_section = by_path["internal/store/store.go"][0].split("DEPENDENCIES (already written")[1]
    assert "NewStore" not in deps_section  # a file never sees interfaces of files generated after it

    # 4. hallucinated symbols/imports were caught and fed back
    assert len(by_path["cmd/server/main.go"]) == 2
    assert "store.NewBookStore is not defined in package library/internal/store" in by_path["cmd/server/main.go"][1]
    assert len(by_path["web/app.js"]) == 2
    assert "does not match any planned file" in by_path["web/app.js"][1]
    assert out["files"]["cmd/server/main.go"]["attempts"] == 2
    assert "store.NewStore" in (root / "cmd/server/main.go").read_text()
    assert "api.js" not in (root / "web/app.js").read_text()
    assert "Files that needed a retry" in out["summary"]


def test_resume_skips_existing(env):
    s, log, tmp = env
    s.resume = True
    root = tmp / "library-test"
    (root / "db").mkdir(parents=True)
    (root / "db/schema.sql").write_text(SCHEMA)
    agent = build_agent(s, llm=FakeListChatModel(responses=[plan_json()]))
    agent.invoke({"spec_path": "examples/library_inventory_system.json"}, config={"recursion_limit": 500})
    assert "db/schema.sql" not in {r["path"] for r in log}


def test_cycle_is_broken():
    plan = ProjectPlan.model_validate({"project_name": "x", "files": [
        {"path": "a.py", "purpose": "a", "depends_on": ["b.py"]},
        {"path": "b.py", "purpose": "b", "depends_on": ["a.py"]}]})
    g = CodeGraph(plan)
    assert len(g.removed_edges) == 1 and len(g.order()) == 2


def test_python_import_checks():
    plan = ProjectPlan.model_validate({"project_name": "x", "root_package": "app", "files": [
        {"path": "app/models.py", "purpose": "m"},
        {"path": "app/service.py", "purpose": "s", "depends_on": ["app/models.py"]}]})
    g = CodeGraph(plan)
    models = "class User:\n    name: str\n\ndef make_user(n: str) -> 'User': ...\n"
    syms = {"app/models.py": [s.to_dict() for s in extract_symbols("Python", models)]}
    f = plan.file("app/service.py")
    ok = check_imports(plan, g, f, "from app.models import User, make_user\n", syms)
    assert not [i for i in ok if i.level == "error"]
    bad = check_imports(plan, g, f, "from app.models import Account\nfrom app.nope import x\n", syms)
    msgs = " ".join(i.message for i in bad if i.level == "error")
    assert "Account" in msgs and "app.nope" in msgs
    rel = check_imports(plan, g, f, "from .models import User\n", syms)
    assert not [i for i in rel if i.level == "error"]


def test_symbol_extraction():
    go = extract_symbols("Go", STORE)
    names = {s.name: s.kind for s in go}
    assert names["Store"] == "struct" and names["NewStore"] == "func" and names["ListBooks"] == "method"
    assert {s.name for s in extract_symbols("HTML", HTML)} >= {"book-search", "book-list"}


def test_go_signature_drops_body():
    from cody_agent.graphify import _go_sig
    assert _go_sig("func NewStore(db *sql.DB) *Store { return &Store{db: db} }") == "func NewStore(db *sql.DB) *Store"
    assert _go_sig("func F(x interface{}) error {") == "func F(x interface{}) error"
    assert _go_sig("func G() interface{} { return nil }") == "func G() interface{}"
