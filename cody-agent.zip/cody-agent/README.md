# cody-agent

A LangGraph agent that builds a **multi-file project** by calling the [Cody](../Cody-main) HTTP API
once per file, in dependency order, with a file dependency graph ("graphify") that tells Cody what
the other files look like — so imports and function names line up.

Cody's API is `POST /generate_code {language, requirement} -> {code, timetaken}` and knows nothing
about other files. This agent supplies that missing context inside `requirement`.

## Flow

```
load_spec -> plan_files -> graphify -> generate_file -> check_file -> commit_file -> finalize
                                           ^   |  retry with errors   |     |
                                           +---+----------------------+     +-- next file
```

| Node | What it does |
|---|---|
| `load_spec` | Reads a handoff JSON (stories, invariants, UI screens, NFRs) or plain text. Pings Cody first. |
| `plan_files` | Planner LLM returns a JSON file plan: path, purpose, `depends_on`, expected `exports`. Invalid plans are sent back for repair. |
| `graphify` | Builds a `networkx` DAG from `depends_on`, breaks cycles, computes generation order. |
| `generate_file` | Builds one self-contained prompt (file purpose, relevant stories/invariants, project file map, **interfaces of dependencies**) and calls the `cody_generate_code` tool. |
| `check_file` | Verifies the result against the graph (below). Errors go back to Cody as feedback, up to `MAX_FILE_ATTEMPTS`. |
| `commit_file` | Writes the file, extracts its symbols into the graph so dependents can see them. |
| `finalize` | Scaffolds `go.mod` / `requirements.txt`, writes `.cody_agent/{plan.json,graph.json,graph.mmd}`. |

### What "graphify" extracts (the interface a dependent sees)

Go funcs/methods/structs/interfaces/consts · Python classes/functions (via `ast`) · JS functions/classes/exports ·
SQL `CREATE TABLE` statements · HTML element ids, form field names, classes · CSS selectors and variables.

### What `check_file` rejects

- an import that is not in the plan (`library/internal/db` when no such package exists)
- `pkg.Func` selectors (Go) / `from x import y` (Python) / `import {y} from './x.js'` (JS) naming symbols the dependency does not define
- missing `exports` the plan promised
- HTML referencing scripts/styles that are not planned
- syntax errors (Python always; Go via `gofmt` and JS via `node --check` when installed)
- undeclared dependencies and unlisted third-party packages are reported as warnings

## Run

```bash
pip install -r requirements.txt
cp .env.example .env            # set CODY_URL + an LLM key for the planner

# start Cody (from the Cody repo)
cd Cody-main/src && uvicorn main:app --port 7777     # or: docker compose up cody

python run.py --spec examples/library_inventory_system.json --out generated
python run.py --prompt "A Python CLI todo app with SQLite storage"
python run.py --spec my.json --resume        # keep files already on disk, generate the rest
```

Output: `generated/<project-slug>/…` plus `.cody_agent/graph.mmd` (paste into mermaid.live to see the graph).

## Use from Python / with other agents

```python
from cody_agent import Settings, build_agent, make_cody_tool

agent = build_agent(Settings())
result = agent.invoke({"spec_path": "spec.json"}, config={"recursion_limit": 2000})

# Cody as a plain LangChain tool, for any other agent (e.g. create_react_agent):
cody = make_cody_tool(Settings())
cody.invoke({"language": "Go", "requirement": "..."})
```

## Notes

- Cody runs three LLM agents per call; a project of 15 files can take a while on free models. Raise `CODY_TIMEOUT` if needed. Use `--resume` after an interruption.
- The planner LLM (`LLM_PROVIDER`/`LLM_MODEL`) is separate from Cody's own model (set in Cody's `src/main.py`). A stronger planner makes a much better graph.
- If you use a different graph tool than the built-in one, replace `CodeGraph` and `extract_symbols` in `graphify.py`; the nodes only need `order()`, `deps()` and symbol lists.
- Tests run without any LLM or real Cody: `python -m pytest tests` (uses a mock server with the same API contract).
