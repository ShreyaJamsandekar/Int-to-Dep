# GRAPH_REPORT — Knowledge Graph & Code Topology (Graphify v8 Compatible)

- **Knowledge Graph Epoch:** `9`
- **Total Nodes:** `61`
- **Total Directed Links:** `109`

## God Nodes (Most-Connected Concepts)

| Node ID | Total Degree |
| :--- | :--- |
| `MOD-001` | 20 |
| `MOD-003` | 17 |
| `MOD-002` | 12 |
| `MOD-005` | 12 |
| `MOD-004` | 10 |
| `AC-002-01` | 8 |
| `AC-001-01` | 7 |
| `FND-001` | 7 |
| `SVC-001` | 7 |
| `SVC-002` | 7 |

## File-Level Deterministic Summaries

- **`services/chess_engine/domain_service.py` (`MOD-001`):** [domain] Core domain logic and persistence for chess-engine. Exports: process_chess_engine, ChessEngineRequest, ChessEngineResponse, ChessEngineDomainError.
- **`services/chess_engine/api_routes.py` (`MOD-002`):** [api] HTTP endpoint router and RFC 7807 error mapping for chess-engine. Exports: handle_chess_engine_endpoint.
- **`services/chess_web_ui/domain_service.py` (`MOD-003`):** [domain] Core domain logic and persistence for chess-web-ui. Exports: process_chess_web_ui, ChessWebUiRequest, ChessWebUiResponse, ChessWebUiDomainError.
- **`services/chess_web_ui/api_routes.py` (`MOD-004`):** [api] HTTP endpoint router and RFC 7807 error mapping for chess-web-ui. Exports: handle_chess_web_ui_endpoint.
- **`services/ui_frontend/ui_controller.py` (`MOD-005`):** [api] Frontend screen state and typed API client for SCR-001, SCR-002. Exports: handle_ui_viewmodel_endpoint.
