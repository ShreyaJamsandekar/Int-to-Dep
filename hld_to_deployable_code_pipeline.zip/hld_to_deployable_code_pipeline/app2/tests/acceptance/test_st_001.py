"""Frozen Acceptance Oracle for ST-001 (Validate and Record Chess Move). DO NOT MODIFY IN L3."""
from __future__ import annotations
from tests.harness.state_seeder import StateSeeder

def test_ac_001_01() -> None:
    """AC: AC-001-01 -> Given a valid algebraic_move and positive move number When the chess move endpoint is called Then the move is recorded with status PROCESSED"""
    seeder = StateSeeder()
    seeded = seeder.given_entity_exists('records', {'status': 'SEEDED'})
    assert seeded['status'] == 'SEEDED'

def test_ac_001_02() -> None:
    """AC: AC-001-02 -> Given an invalid zero move number When the chess move endpoint is called Then a 422 ChessEngineDomainError is raised"""
    seeder = StateSeeder()
    seeded = seeder.given_entity_exists('records', {'status': 'SEEDED'})
    assert seeded['status'] == 'SEEDED'
