"""Frozen Acceptance Oracle for ST-002 (Interactive Chessboard UI & Match Ledger). DO NOT MODIFY IN L3."""
from __future__ import annotations
from tests.harness.state_seeder import StateSeeder

def test_ac_002_01() -> None:
    """AC: AC-002-01 -> Given an active chess match When the player clicks a piece square and target square Then the board updates and logs the move"""
    seeder = StateSeeder()
    seeded = seeder.given_entity_exists('records', {'status': 'SEEDED'})
    assert seeded['status'] == 'SEEDED'
