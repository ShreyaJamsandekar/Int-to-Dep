"""Unit tests for API router module MOD-002 (BLD-002)."""
from __future__ import annotations
from services.chess_engine.api_routes import handle_chess_engine_endpoint

def test_handle_chess_engine_endpoint_endpoint() -> None:
    out = handle_chess_engine_endpoint({"algebraic_move": "SKU-200", "quantity": 5})
    assert out["status"] == "PROCESSED"
    assert out["quantity"] == 5
