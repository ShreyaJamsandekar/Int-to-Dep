"""Unit and property tests for MOD-003 (BLD-003)."""
from __future__ import annotations
import unittest
from services.chess_web_ui.domain_service import process_chess_web_ui, ChessWebUiRequest, ChessWebUiDomainError

def test_process_chess_web_ui_happy_path() -> None:
    res = process_chess_web_ui(ChessWebUiRequest(algebraic_move="SKU-100", quantity=3))
    assert res.status == "PROCESSED"
    assert res.quantity == 3

def test_process_chess_web_ui_rejects_non_positive_quantity() -> None:
    try:
        process_chess_web_ui(ChessWebUiRequest(algebraic_move="SKU-100", quantity=0))
        raise AssertionError('Expected domain error')
    except ChessWebUiDomainError:
        pass
