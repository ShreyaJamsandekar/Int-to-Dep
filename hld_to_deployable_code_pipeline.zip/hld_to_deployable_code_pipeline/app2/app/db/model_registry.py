# Auto-generated persistence table registry from LLDPack. DO NOT EDIT IN WORKER.
from __future__ import annotations
REGISTERED_TABLES: list[str] = ["chess_engine_records", "chess_web_ui_records"]
