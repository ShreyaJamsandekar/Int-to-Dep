-- UP
CREATE TABLE IF NOT EXISTS chess_engine_records (record_id TEXT, algebraic_move TEXT, quantity INTEGER, status TEXT);
-- DOWN
DROP TABLE IF EXISTS chess_engine_records;
