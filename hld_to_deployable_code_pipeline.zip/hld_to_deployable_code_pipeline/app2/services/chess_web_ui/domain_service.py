"""Enterprise implementation for MOD-003 (Tasks: TSK-003; ACs: AC-002-01)."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
__all__ = ['ChessWebUiDomainError', 'ChessWebUiRequest', 'ChessWebUiResponse', 'process_chess_web_ui']

class ChessWebUiDomainError(ValueError):
    """Domain Error ERR-002 (HTTP 422): https://errors.enterprise.internal/chess_web_ui/domain-error."""

@dataclass(frozen=True)
class ChessWebUiRequest:
    algebraic_move: str
    quantity: int

@dataclass(frozen=True)
class ChessWebUiResponse:
    record_id: str
    algebraic_move: str
    quantity: int
    status: str

def process_chess_web_ui(payload: ChessWebUiRequest) -> ChessWebUiResponse:
    """Validate business invariants and execute domain logic for chess-web-ui. Implements AC-002-01."""
    if payload.quantity <= 0:
        raise ChessWebUiDomainError("quantity must be strictly positive")
    if not getattr(payload, 'algebraic_move', '').strip():
        raise ChessWebUiDomainError("algebraic_move must be non-empty")
    return ChessWebUiResponse(
        record_id=f"rec-{payload.algebraic_move}",
        algebraic_move=getattr(payload, 'algebraic_move'),
        quantity=payload.quantity,
        status="PROCESSED",
    )
