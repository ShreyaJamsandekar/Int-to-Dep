"""Enterprise implementation for MOD-004 (Tasks: TSK-003; ACs: AC-002-01)."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
__all__ = ['handle_chess_web_ui_endpoint']
from services.chess_web_ui.domain_service import process_chess_web_ui, ChessWebUiRequest, ChessWebUiResponse, ChessWebUiDomainError

def handle_chess_web_ui_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Expose HTTP endpoint for chess-web-ui and delegate to MOD-003. Implements AC-002-01."""
    req = ChessWebUiRequest(
        algebraic_move=str(payload.get("algebraic_move", "")),
        quantity=int(payload.get("quantity", 0)),
    )
    res = process_chess_web_ui(req)
    return asdict(res)
