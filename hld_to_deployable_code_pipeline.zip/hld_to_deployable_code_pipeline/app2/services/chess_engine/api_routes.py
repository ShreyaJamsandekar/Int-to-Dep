"""Enterprise implementation for MOD-002 (Tasks: TSK-001, TSK-002; ACs: AC-001-01, AC-001-02)."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
__all__ = ['handle_chess_engine_endpoint']
from services.chess_engine.domain_service import process_chess_engine, ChessEngineRequest, ChessEngineResponse, ChessEngineDomainError

def handle_chess_engine_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """Expose HTTP endpoint for chess-engine and delegate to MOD-001. Implements AC-001-01, AC-001-02."""
    req = ChessEngineRequest(
        algebraic_move=str(payload.get("algebraic_move", "")),
        quantity=int(payload.get("quantity", 0)),
    )
    res = process_chess_engine(req)
    return asdict(res)
