# Enterprise Runbook — HND-CHESS-ARENA-002

- Health Probe: `GET /healthz`
- Readiness Probe: `GET /readyz`
- Rollback Command: `alembic downgrade -1 && helm rollback release-sandbox`
