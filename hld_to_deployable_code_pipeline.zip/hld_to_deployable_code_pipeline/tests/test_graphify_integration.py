"""Unit tests for the Graphify v8 adapter, confidence-gated KG sync, and graphify-out exports."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from pipeline.contracts.lld import ModuleSpec, FunctionSpec
from pipeline.graph.sqlite_adapter import SQLiteKnowledgeGraph
from pipeline.harness.graphify_adapter import (
    extract_module_graph,
    sync_graphify_to_kg,
    compute_graph_diff,
    export_graphify_artifacts,
)


class TestGraphifyV8Integration(unittest.TestCase):
    def _sample_module_spec(self) -> ModuleSpec:
        return ModuleSpec(
            id="MOD-001",
            component_id="SVC-001",
            path="services/order_service/domain_service.py",
            layer="domain",
            responsibilities=["Validate and persist customer orders"],
            public_interface=[
                FunctionSpec(
                    name="process_order",
                    signature="def process_order(x: int) -> int",
                    purpose="Process order item quantity deterministically.",
                    ac_ids=["AC-001-01"],
                )
            ],
            task_ids=["TSK-001"],
            ac_ids=["AC-001-01"],
        )

    def test_extract_and_confidence_gate_separation(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            repo = Path(td)
            mod = self._sample_module_spec()
            fpath = repo / mod.path
            fpath.parent.mkdir(parents=True, exist_ok=True)
            fpath.write_text(
                "def helper(v: int) -> int:" + chr(10) + "    return v + 1" + chr(10)*2 +
                "def process_order(x: int) -> int:" + chr(10) + "    y = helper(x)" + chr(10) + "    return y.bit_length()" + chr(10),
                encoding="utf-8",
            )

            extraction = extract_module_graph(repo, mod)
            self.assertIn("nodes", extraction)
            self.assertIn("edges", extraction)
            self.assertIn("summary", extraction)
            self.assertEqual(extraction["summary"]["generated_by"], "deterministic")

            kg = SQLiteKnowledgeGraph(":memory:")
            synced = sync_graphify_to_kg(extraction, "BLD-001", mod, kg, run_id="test-run")
            self.assertTrue(any(e["confidence"] == "EXTRACTED" for e in synced["extracted_edges"]))
            self.assertTrue(any(e["confidence"] == "INFERRED" for e in synced["review_hints"]))

            exported = export_graphify_artifacts(kg, repo)
            self.assertTrue((repo / exported["graph_json"]).is_file())
            self.assertTrue((repo / exported["node_summaries_json"]).is_file())
            self.assertTrue((repo / exported["graph_cypher"]).is_file())
            self.assertTrue((repo / exported["graph_report_md"]).is_file())

            gjson = json.loads((repo / exported["graph_json"]).read_text(encoding="utf-8"))
            self.assertEqual(gjson["graph"]["schema_version"], "1.0")

    def test_compute_graph_diff(self) -> None:
        old_ext = {"nodes": [{"id": "N1"}], "edges": []}
        new_ext = {
            "nodes": [{"id": "N1"}, {"id": "N2"}],
            "edges": [{"source": "N1", "target": "N2", "relation": "calls", "confidence": "EXTRACTED"}],
        }
        diff = compute_graph_diff(old_ext, new_ext)
        self.assertEqual(diff["added_nodes"], ["N2"])
        self.assertEqual(len(diff["added_edges"]), 1)


if __name__ == "__main__":
    unittest.main()
