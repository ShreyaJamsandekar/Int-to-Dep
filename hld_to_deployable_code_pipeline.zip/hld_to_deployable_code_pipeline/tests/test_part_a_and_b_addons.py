"""Unit and integration tests for Part A (Model-Optional LLM Layer) and Part B (UI & app1/app2 folders)."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from pipeline.contracts.ui import UiSpec
from pipeline.contracts.review import Finding, Severity, Dimension
from pipeline.review.evidence import evidence_ok
from pipeline.llm.runtime import (
    DEFAULT_ROLES,
    MockRuntimeClient,
    resolve_roles,
)
from pipeline.orchestration.runner import PipelineRunner


class TestPartAModelOptionalAndPartBUi(unittest.TestCase):
    def test_part_a_resolve_roles_modes(self) -> None:
        mode_none, enabled, blocked = resolve_roles("none", DEFAULT_ROLES, None)
        self.assertEqual(mode_none, "none")
        self.assertEqual(enabled, {})
        self.assertIn("coder", blocked)

        small_client = MockRuntimeClient(context_tokens=20000, tools=True, structured=True, vision=False)
        mode_partial, en2, blk2 = resolve_roles("live", DEFAULT_ROLES, small_client)
        self.assertIn("coder", blk2)
        self.assertIn("vision", blk2)
        self.assertIn("validator", en2)

    def test_part_a_none_mode_skeleton_deploy_default_and_manual_override(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            handoff_path = Path(__file__).resolve().parent.parent / "examples/sample_handoff.json"
            state_dir = tmp / "state"
            app_dir = tmp / "app_none"
            manual_dir = tmp / "inputs/manual"
            manual_dir.mkdir(parents=True, exist_ok=True)

            # Run in mode='none': H0, L2a scaffold, L4 skeleton verify, AND L7_DEPLOY_SKELETON run by default!
            runner = PipelineRunner(
                state_dir=state_dir,
                workspace_dir=app_dir,
                llm_mode="none",
                manual_dir=manual_dir,
            )
            outcome = runner.run(handoff_file=handoff_path)
            self.assertEqual(outcome.status, "BLOCKED_MODEL_REQUIRED")
            self.assertIn("H0_INTAKE", outcome.checkpoint.completed_stages)
            self.assertIn("L2_SCAFFOLD", outcome.checkpoint.completed_stages)
            self.assertIn("L4_VERIFY_SKELETON", outcome.checkpoint.completed_stages)
            self.assertIn("L7_DEPLOY_SKELETON", outcome.checkpoint.completed_stages)
            self.assertIsNotNone(outcome.release_bundle)
            self.assertIn("L1_LLD", outcome.checkpoint.blocked_stages)
            self.assertTrue((app_dir / "model_required_reports.json").is_file())
            self.assertTrue((app_dir / "ui/index.html").is_file())

            # Place manual lld_pack.json in inputs/manual/ and re-run in `none` mode
            mock_runner = PipelineRunner(
                state_dir=tmp / "state_mock",
                workspace_dir=tmp / "app_mock",
                llm_mode="mock",
            )
            mock_out = mock_runner.run(handoff_file=handoff_path, auto_approve_lld=True)
            assert mock_out.lld is not None
            (manual_dir / "lld_pack.json").write_text(mock_out.lld.to_pretty_json(), encoding="utf-8")

            runner2 = PipelineRunner(
                state_dir=tmp / "state_manual",
                workspace_dir=tmp / "app_manual",
                llm_mode="none",
                manual_dir=manual_dir,
            )
            outcome2 = runner2.run(handoff_file=handoff_path)
            self.assertEqual(outcome2.checkpoint.lld_source, "manual")
            self.assertIn("L1_LLD", outcome2.checkpoint.completed_stages)
            self.assertIn("L3_PLANNER_DETERMINISTIC", outcome2.checkpoint.completed_stages)

    def test_part_b_ui_spec_and_evidence_validation(self) -> None:
        with self.assertRaisesRegex(ValueError, "missing wireframe anchor"):
            UiSpec.parse_obj_compat(
                {
                    "mode": "wireframe",
                    "screens": [
                        {
                            "id": "SCR-001",
                            "route": "/orders",
                            "title": "Orders",
                            "story_ids": ["ST-001"],
                            "elements": [
                                {"label": "Title", "role": "heading", "region": "header", "order": 0}
                            ],
                        }
                    ],
                }
            )

        with tempfile.TemporaryDirectory() as td:
            repo = Path(td)
            (repo / "ui").mkdir()
            (repo / "ui/index.html").write_text("<h1>Orders</h1>" + chr(10), encoding="utf-8")
            (repo / "ui/shot.png").write_text("PNG" + chr(10), encoding="utf-8")

            ui_finding_no_img = Finding(
                id="FND-010",
                dimension=Dimension.CORRECTNESS,
                severity=Severity.MAJOR,
                rule="UI_OVERFLOW",
                file="ui/index.html",
                line=1,
                symbol_name="SCR-001",
                quote="<h1>Orders</h1>",
                impact="Header overflows on 375px viewport.",
                refs=["SCR-001", "AC-001-01"],
                source="reviewer",
                evidence_image=None,
            )
            self.assertFalse(evidence_ok(ui_finding_no_img, repo, {"SCR-001", "AC-001-01"}))

            ui_finding_with_img = ui_finding_no_img.copy_with({"evidence_image": "ui/shot.png"})
            self.assertTrue(evidence_ok(ui_finding_with_img, repo, {"SCR-001", "AC-001-01"}))

    def test_auto_incrementing_app1_and_app2_folders(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            sdir = tmp / "state"
            root_examples = Path(__file__).resolve().parent.parent / "examples"

            r1 = PipelineRunner(state_dir=sdir, llm_mode="mock")
            out1 = r1.run(handoff_file=root_examples / "sample_handoff.json", auto_approve_lld=True)
            self.assertTrue(out1.checkpoint.workspace_dir.startswith("app"))

            r2 = PipelineRunner(state_dir=sdir, llm_mode="mock")
            out2 = r2.run(handoff_file=root_examples / "chess.json", auto_approve_lld=True)
            self.assertNotEqual(out1.checkpoint.workspace_dir, out2.checkpoint.workspace_dir)


if __name__ == "__main__":
    unittest.main()
