# Auto-generated router registry from LLDPack. DO NOT EDIT IN WORKER.
from __future__ import annotations
import importlib
from typing import Any
REGISTERED_API_MODULES: list[str] = ["services.order_service.api_routes", "services.inventory_service.api_routes", "services.ui_frontend.ui_controller"]
def load_registered_handlers() -> dict[str, Any]:
    handlers: dict[str, Any] = {}
    for mod_path in REGISTERED_API_MODULES:
        try:
            mod = importlib.import_module(mod_path)
            for attr in dir(mod):
                if attr.startswith('handle_'):
                    handlers[attr] = getattr(mod, attr)
        except Exception:
            continue
    return handlers
