# Enterprise service entrypoint with health/readiness probes and RFC 7807 error formatting.
from __future__ import annotations
from typing import Any
from app.api.router_registry import load_registered_handlers
from app.db.model_registry import REGISTERED_TABLES
def healthz() -> dict[str, str]:
    return {'status': 'ok'}
def readyz() -> dict[str, Any]:
    return {'status': 'ready', 'tables_registered': len(REGISTERED_TABLES)}
def problem_details(status: int, title: str, detail: str, type_uri: str = 'about:blank') -> dict[str, Any]:
    return {'type': type_uri, 'title': title, 'status': status, 'detail': detail}
def dispatch_request(endpoint_name: str, payload: dict[str, Any], traceparent: str = '00-default-01') -> dict[str, Any]:
    handlers = load_registered_handlers()
    if endpoint_name not in handlers:
        return problem_details(404, 'Not Found', f'Endpoint {endpoint_name} not registered')
    try:
        res = handlers[endpoint_name](payload)
        return {'status': 200, 'traceparent': traceparent, 'data': res}
    except Exception as exc:
        return problem_details(422, exc.__class__.__name__, str(exc))
