"""Unit tests for API router module MOD-005 (BLD-005)."""
from __future__ import annotations
from services.ui_frontend.ui_controller import handle_ui_viewmodel_endpoint

def test_handle_ui_viewmodel_endpoint_endpoint() -> None:
    out = handle_ui_viewmodel_endpoint({"order_sku": "SKU-200", "quantity": 5})
    assert out["status"] == "PROCESSED"
    assert out["quantity"] == 5
