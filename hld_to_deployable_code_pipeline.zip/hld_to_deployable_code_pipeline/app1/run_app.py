# Standalone runnable web & API server for HND-ORDER-INVENTORY-001.
from __future__ import annotations
import argparse
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.main import healthz, readyz, dispatch_request
from app.api.router_registry import load_registered_handlers

class AppHTTPHandler(BaseHTTPRequestHandler):
    def _send_json(self, code: int, payload: dict) -> None:
        raw = json.dumps(payload, indent=2).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _send_file(self, rel_path: str, content_type: str) -> None:
        fpath = ROOT_DIR / rel_path
        if not fpath.is_file():
            self._send_json(404, {'error': f'File {rel_path} not found'})
            return
        raw = fpath.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path == '/healthz':
            self._send_json(200, healthz())
        elif self.path == '/readyz':
            self._send_json(200, readyz())
        elif self.path == '/api/spec':
            handlers = sorted(load_registered_handlers().keys())
            self._send_json(200, {'handoff_id': "HND-ORDER-INVENTORY-001", 'handlers': handlers})
        elif self.path == '/ui/styles.css':
            self._send_file('ui/styles.css', 'text/css; charset=utf-8')
        elif self.path == '/ui/design_tokens.json':
            self._send_file('ui/design_tokens.json', 'application/json; charset=utf-8')
        else:
            self._send_file('ui/index.html', 'text/html; charset=utf-8')

    def do_POST(self) -> None:
        if self.path == '/api/dispatch':
            length = int(self.headers.get('Content-Length', '0'))
            body = json.loads(self.rfile.read(length).decode('utf-8') or '{}')
            endpoint = body.get('endpoint', '')
            payload = body.get('payload', {})
            res = dispatch_request(endpoint, payload)
            self._send_json(res.get('status', 200), res)
        else:
            self._send_json(404, {'error': 'Unknown POST endpoint'})

    def log_message(self, fmt: str, *args) -> None:
        return

def main() -> int:
    parser = argparse.ArgumentParser(description='Run generated enterprise application & UI')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        handlers = load_registered_handlers()
        print('Healthz:', healthz())
        print('Readyz: ', readyz())
        print('UI HTML:', (ROOT_DIR / 'ui/index.html').is_file())
        print('Registered Endpoint Handlers:', sorted(handlers.keys()))
        return 0
    server = HTTPServer((args.host, args.port), AppHTTPHandler)
    print(f'Serving HND-ORDER-INVENTORY-001 UI & API at http://{args.host}:{args.port}')
    server.serve_forever()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
