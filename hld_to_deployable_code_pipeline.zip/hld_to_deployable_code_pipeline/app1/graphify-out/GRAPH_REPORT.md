# GRAPH_REPORT — Knowledge Graph & Code Topology (Graphify v8 Compatible)

- **Knowledge Graph Epoch:** `9`
- **Total Nodes:** `61`
- **Total Directed Links:** `109`

## God Nodes (Most-Connected Concepts)

| Node ID | Total Degree |
| :--- | :--- |
| `MOD-001` | 20 |
| `MOD-003` | 17 |
| `MOD-005` | 13 |
| `MOD-002` | 12 |
| `MOD-004` | 10 |
| `SVC-001` | 8 |
| `AC-001-01` | 7 |
| `AC-002-01` | 7 |
| `FND-001` | 7 |
| `AC-001-02` | 6 |

## File-Level Deterministic Summaries

- **`services/order_service/domain_service.py` (`MOD-001`):** [domain] Core domain logic and persistence for order-service. Exports: process_order_service, OrderServiceRequest, OrderServiceResponse, OrderServiceDomainError.
- **`services/order_service/api_routes.py` (`MOD-002`):** [api] HTTP endpoint router and RFC 7807 error mapping for order-service. Exports: handle_order_service_endpoint.
- **`services/inventory_service/domain_service.py` (`MOD-003`):** [domain] Core domain logic and persistence for inventory-service. Exports: process_inventory_service, InventoryServiceRequest, InventoryServiceResponse, InventoryServiceDomainError.
- **`services/inventory_service/api_routes.py` (`MOD-004`):** [api] HTTP endpoint router and RFC 7807 error mapping for inventory-service. Exports: handle_inventory_service_endpoint.
- **`services/ui_frontend/ui_controller.py` (`MOD-005`):** [api] Frontend screen state and typed API client for SCR-001, SCR-002. Exports: handle_ui_viewmodel_endpoint.
