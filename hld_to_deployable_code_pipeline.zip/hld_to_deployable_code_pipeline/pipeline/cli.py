"""Command-line interface for running, approving LLD, and resuming the pipeline."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from pipeline.orchestration.runner import PipelineRunner
from pipeline.orchestration.resume import ResumeManager


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="pipeline.cli",
        description="Vision-PR / HLD-to-Deployable-Code Pipeline CLI (v0.3 with Model-Optional & UI)",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run", help="Start pipeline from H0 Handoff (allocates app1, app2, ... per JSON)")
    p_run.add_argument("--handoff", default="examples/sample_handoff.json", help="Path to HLDHandoff JSON")
    p_run.add_argument("--state-dir", default="state", help="Directory for resume.txt and KG state")
    p_run.add_argument("--workspace-dir", default=None, help="Output folder (default: auto app1, app2, ...)")
    p_run.add_argument("--mode", default="mock", choices=["auto", "live", "mock", "none"], help="LLM execution mode")
    p_run.add_argument("--manual-dir", default="inputs/manual", help="Directory for manual override artifacts")
    p_run.add_argument("--deploy-skeleton", dest="deploy_skeleton", action="store_true", default=True, help="Deploy skeleton in mode='none' (default: True)")
    p_run.add_argument("--no-deploy-skeleton", dest="deploy_skeleton", action="store_false", help="Disable skeleton deploy in mode='none'")
    p_run.add_argument("--new-app", action="store_true", help="Force a brand-new appN folder even if JSON was run before")
    p_run.add_argument("--auto-approve-lld", action="store_true", help="Approve LLD automatically without pausing")

    p_approve = sub.add_parser("approve-lld", help="Mark LLD Approved: YES in state/resume.txt")
    p_approve.add_argument("--state-dir", default="state", help="Directory containing resume.txt")

    p_resume = sub.add_parser("resume", help="Resume pipeline from state/resume.txt")
    p_resume.add_argument("--state-dir", default="state", help="Directory containing resume.txt")
    p_resume.add_argument("--mode", default=None, choices=["auto", "live", "mock", "none"], help="Override LLM mode")

    p_status = sub.add_parser("status", help="Print plain-text state/resume.txt")
    p_status.add_argument("--state-dir", default="state", help="Directory containing resume.txt")

    args = parser.parse_args(argv)

    if args.cmd == "run":
        runner = PipelineRunner(
            state_dir=args.state_dir,
            workspace_dir=args.workspace_dir,
            llm_mode=args.mode,
            manual_dir=args.manual_dir,
            deploy_skeleton_in_none_mode=args.deploy_skeleton,
        )
        outcome = runner.run(
            handoff_file=args.handoff,
            auto_approve_lld=args.auto_approve_lld,
            force_new_app_folder=args.new_app,
        )
        print(f"Pipeline Status:  {outcome.status}")
        print(f"App Folder:       {outcome.checkpoint.workspace_dir}")
        print(f"Resume File:      {Path(args.state_dir) / 'resume.txt'}")
        print(f"Run App Command:  python3 {outcome.checkpoint.workspace_dir}/run_app.py --port 8000")
        if outcome.release_bundle:
            print(f"Sandbox URL:      {outcome.release_bundle.sandbox_url}")
            print(f"Release Bundle:   {Path(outcome.checkpoint.workspace_dir) / 'release_bundle/release-bundle.json'}")
        return 0

    if args.cmd == "approve-lld":
        mgr = ResumeManager(args.state_dir)
        cp = mgr.load()
        cp.lld_approved = "YES"
        cp.current_stage = "LLD_APPROVED_READY_FOR_L2"
        cp.last_status = "LLD_APPROVED_BY_USER"
        cp.next_command = f"python -m pipeline.cli resume --state-dir {args.state_dir}"
        cp.notes = "LLD approved! Run the Next Command to build, verify, and deploy."
        mgr.save(cp)
        print(f"Updated {mgr.txt_path}: LLD Approved = YES (App Folder: {cp.workspace_dir})")
        return 0

    if args.cmd == "resume":
        mgr = ResumeManager(args.state_dir)
        cp = mgr.load()
        runner = PipelineRunner(
            state_dir=args.state_dir,
            workspace_dir=cp.workspace_dir,
            llm_mode=args.mode or cp.llm_mode,
        )
        outcome = runner.run(
            handoff_file=cp.handoff_file,
            auto_approve_lld=(cp.lld_approved == "YES"),
            run_id=cp.run_id,
        )
        print(f"Pipeline Resume Status: {outcome.status}")
        print(f"App Folder:             {outcome.checkpoint.workspace_dir}")
        print(f"Run App Command:        python3 {outcome.checkpoint.workspace_dir}/run_app.py --port 8000")
        if outcome.release_bundle:
            print(f"Sandbox URL:            {outcome.release_bundle.sandbox_url}")
            print(f"Release Bundle:         {Path(cp.workspace_dir) / 'release_bundle/release-bundle.json'}")
        return 0

    if args.cmd == "status":
        mgr = ResumeManager(args.state_dir)
        if mgr.txt_path.is_file():
            print(mgr.txt_path.read_text(encoding="utf-8"))
        else:
            print(f"No resume.txt found in {args.state_dir}")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
