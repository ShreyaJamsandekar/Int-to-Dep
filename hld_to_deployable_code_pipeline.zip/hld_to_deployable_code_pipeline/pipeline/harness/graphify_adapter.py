"""Graphify v8 adapter for deterministic AST extraction, confidence-gated KG sync, and graphify-out exports."""
from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any
from pipeline.contracts.lld import ModuleSpec
from pipeline.graph.sqlite_adapter import SQLiteKnowledgeGraph

try:
    from graphify.extract import extract as _native_graphify_extract  # type: ignore
    HAS_NATIVE_GRAPHIFY = True
except Exception:
    _native_graphify_extract = None
    HAS_NATIVE_GRAPHIFY = False


def build_deterministic_file_summary(py_file: Path, module_spec: ModuleSpec) -> dict[str, Any]:
    exports = (
        [f.name for f in module_spec.public_interface]
        + [d.name for d in module_spec.data_models]
        + [e.exception_name for e in module_spec.errors]
    )
    resp = module_spec.responsibilities[0] if module_spec.responsibilities else "Module implementation"
    summary_text = (
        f"[{module_spec.layer}] {resp[:110].rstrip('.')}. "
        f"Exports: {', '.join(exports[:5])}."
    )[:280]
    return {
        "id": module_spec.id,
        "label": Path(module_spec.path).name,
        "source_file": module_spec.path,
        "summary": summary_text,
        "generated_by": "deterministic",
        "summary_version": 1,
    }


def extract_module_graph(repo_root: Path, module_spec: ModuleSpec) -> dict[str, Any]:
    file_path = repo_root / module_spec.path
    if not file_path.is_file():
        return {"nodes": [], "edges": [], "summary": {}}

    summary_obj = build_deterministic_file_summary(file_path, module_spec)
    if HAS_NATIVE_GRAPHIFY and _native_graphify_extract is not None:
        raw = _native_graphify_extract([file_path], root=repo_root.resolve())
        raw["summary"] = summary_obj
        return raw

    tree = ast.parse(file_path.read_text(encoding="utf-8"))
    nodes: list[dict[str, Any]] = [
        {
            "id": module_spec.id,
            "label": Path(module_spec.path).name,
            "file_type": "code",
            "source_file": module_spec.path,
            "source_location": "L1",
            "summary": summary_obj["summary"],
        }
    ]
    edges: list[dict[str, Any]] = []
    defined_symbols: dict[str, str] = {}

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            sym_id = f"SYM-{module_spec.id}-{node.name}"
            defined_symbols[node.name] = sym_id
            nodes.append(
                {
                    "id": sym_id,
                    "label": node.name,
                    "file_type": "code",
                    "source_file": module_spec.path,
                    "source_location": f"L{node.lineno}",
                }
            )
            edges.append(
                {
                    "source": module_spec.id,
                    "target": sym_id,
                    "relation": "defines",
                    "confidence": "EXTRACTED",
                    "confidence_score": 1.0,
                    "source_file": module_spec.path,
                }
            )

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            caller_id = defined_symbols[node.name]
            for child in ast.walk(node):
                if isinstance(child, ast.Call):
                    if isinstance(child.func, ast.Name):
                        callee_name = child.func.id
                        edges.append(
                            {
                                "source": caller_id,
                                "target": defined_symbols.get(callee_name, f"EXT-{callee_name}"),
                                "relation": "calls",
                                "confidence": "EXTRACTED",
                                "confidence_score": 1.0,
                                "source_file": module_spec.path,
                            }
                        )
                    elif isinstance(child.func, ast.Attribute):
                        edges.append(
                            {
                                "source": caller_id,
                                "target": f"ATTR-{child.func.attr}",
                                "relation": "calls",
                                "confidence": "INFERRED",
                                "confidence_score": 0.85,
                                "source_file": module_spec.path,
                            }
                        )

    return {"nodes": nodes, "edges": edges, "summary": summary_obj}


def sync_graphify_to_kg(
    extraction: dict[str, Any],
    build_id: str,
    module_spec: ModuleSpec,
    kg: SQLiteKnowledgeGraph,
    run_id: str = "run-default",
) -> dict[str, list[dict[str, Any]]]:
    extracted_edges: list[dict[str, Any]] = []
    inferred_or_ambiguous_hints: list[dict[str, Any]] = []

    for edge in extraction.get("edges", []):
        conf = edge.get("confidence", "EXTRACTED")
        if conf == "EXTRACTED":
            extracted_edges.append(edge)
            if edge.get("relation") in ("imports", "depends_on"):
                kg.add_edge(edge["source"], edge["target"], "DEPENDS_ON")
        else:
            inferred_or_ambiguous_hints.append(edge)

    summary = extraction.get("summary")
    if summary and isinstance(summary, dict) and summary.get("id"):
        kg.upsert_node(
            node_id=f"SUM-{module_spec.id}",
            kind="FileSummary",
            payload=summary,
            run_id=run_id,
        )
        kg.add_edge(f"SUM-{module_spec.id}", module_spec.id, "DESCRIBES")

    return {
        "extracted_edges": extracted_edges,
        "review_hints": inferred_or_ambiguous_hints,
    }


def compute_graph_diff(old_ext: dict[str, Any], new_ext: dict[str, Any]) -> dict[str, Any]:
    old_nodes = {n["id"] for n in old_ext.get("nodes", [])}
    new_nodes = {n["id"] for n in new_ext.get("nodes", [])}
    old_edges = {
        (e["source"], e["target"], e["relation"], e.get("confidence", "EXTRACTED"))
        for e in old_ext.get("edges", [])
    }
    new_edges = {
        (e["source"], e["target"], e["relation"], e.get("confidence", "EXTRACTED"))
        for e in new_ext.get("edges", [])
    }
    return {
        "added_nodes": sorted(new_nodes - old_nodes),
        "removed_nodes": sorted(old_nodes - new_nodes),
        "added_edges": sorted(list(new_edges - old_edges)),
        "removed_edges": sorted(list(old_edges - new_edges)),
    }


def export_graphify_artifacts(kg: SQLiteKnowledgeGraph, repo_root: Path) -> dict[str, str]:
    out_dir = repo_root / "graphify-out"
    out_dir.mkdir(parents=True, exist_ok=True)

    all_nodes = kg.list_nodes()
    links: list[dict[str, Any]] = []
    degree_count: dict[str, int] = {n["id"]: 0 for n in all_nodes}

    edge_rows = kg._conn.execute("SELECT src, dst, rel, epoch FROM edges ORDER BY src, dst").fetchall()
    for r in edge_rows:
        src, dst, rel = r["src"], r["dst"], r["rel"]
        links.append(
            {
                "source": src,
                "target": dst,
                "_src": src,
                "_tgt": dst,
                "relation": rel.lower(),
                "confidence": "EXTRACTED",
                "confidence_score": 1.0,
            }
        )
        degree_count[src] = degree_count.get(src, 0) + 1
        degree_count[dst] = degree_count.get(dst, 0) + 1

    graph_json = {
        "directed": False,
        "multigraph": False,
        "graph": {
            "schema_version": "1.0",
            "graphify_version": "v8-pipeline-adapter",
            "kg_epoch": kg.epoch,
            "hyperedges": [],
        },
        "nodes": [
            {
                "id": n["id"],
                "label": n["id"],
                "kind": n["kind"],
                "epoch": n["epoch"],
                "stale": n["stale"],
            }
            for n in all_nodes
        ],
        "links": links,
    }
    (out_dir / "graph.json").write_text(json.dumps(graph_json, indent=2), encoding="utf-8")

    summary_nodes = kg.list_nodes("FileSummary")
    summaries_payload = {
        "version": 1,
        "generator": "deterministic",
        "nodes": {s["payload"]["id"]: s["payload"] for s in summary_nodes},
    }
    (out_dir / "node-summaries.json").write_text(json.dumps(summaries_payload, indent=2), encoding="utf-8")

    cypher_lines = ["// Graphify v8 + Pipeline Knowledge Graph OpenCypher Export"]
    for n in all_nodes:
        safe_id = n["id"].replace('"', "")
        safe_kind = n["kind"].replace('"', "")
        cypher_lines.append(
            f'MERGE (n:{safe_kind} {{id: "{safe_id}"}}) SET n.epoch = {n["epoch"]}, n.stale = {str(n["stale"]).lower()};'
        )
    for lnk in links:
        rel_type = lnk["relation"].upper()
        cypher_lines.append(
            f'MATCH (a {{id: "{lnk["source"]}"}}), (b {{id: "{lnk["target"]}"}}) '
            f'MERGE (a)-[r:{rel_type} {{confidence: "EXTRACTED"}}]->(b);'
        )
    (out_dir / "graph.cypher").write_text(chr(10).join(cypher_lines) + chr(10), encoding="utf-8")

    top_god_nodes = sorted(degree_count.items(), key=lambda kv: (-kv[1], kv[0]))[:10]
    report_lines = [
        "# GRAPH_REPORT — Knowledge Graph & Code Topology (Graphify v8 Compatible)",
        "",
        f"- **Knowledge Graph Epoch:** `{kg.epoch}`",
        f"- **Total Nodes:** `{len(all_nodes)}`",
        f"- **Total Directed Links:** `{len(links)}`",
        "",
        "## God Nodes (Most-Connected Concepts)",
        "",
        "| Node ID | Total Degree |",
        "| :--- | :--- |",
    ]
    for nid, deg in top_god_nodes:
        report_lines.append(f"| `{nid}` | {deg} |")

    report_lines += ["", "## File-Level Deterministic Summaries", ""]
    for s in summary_nodes:
        p = s["payload"]
        report_lines.append(f"- **`{p['source_file']}` (`{p['id']}`):** {p['summary']}")

    (out_dir / "GRAPH_REPORT.md").write_text(chr(10).join(report_lines) + chr(10), encoding="utf-8")

    return {
        "graph_json": "graphify-out/graph.json",
        "node_summaries_json": "graphify-out/node-summaries.json",
        "graph_cypher": "graphify-out/graph.cypher",
        "graph_report_md": "graphify-out/GRAPH_REPORT.md",
    }
