"""Evidence verification (including Part B UI screenshot & SCR- ref rules) and review score."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
from pipeline.contracts.review import Finding, Severity, Dimension


def evidence_ok(f: Finding, repo: Path, known_ids: set[str]) -> bool:
    p = (repo / f.file).resolve()
    if not p.is_relative_to(repo.resolve()) or not p.is_file():
        return False
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    if f.line < 1 or f.line > len(lines):
        return False
    window = chr(10).join(lines[max(0, f.line - 2) : f.line + 1])
    if f.quote.strip() not in window or not all(r in known_ids for r in f.refs):
        return False

    has_scr_ref = any(r.startswith("SCR-") for r in f.refs)
    if f.source == "reviewer" and (has_scr_ref or f.evidence_image is not None):
        if not has_scr_ref or not f.evidence_image:
            return False
        img_path = (repo / f.evidence_image).resolve()
        if not img_path.is_relative_to(repo.resolve()) or not img_path.is_file():
            return False
    return True


def review_score(open_findings: list[Finding]) -> int:
    n = Counter(f.severity for f in open_findings)
    if n[Severity.BLOCKER] >= 3:
        return 0
    if n[Severity.BLOCKER]:
        return 1
    if n[Severity.MAJOR] >= 3:
        return 2
    if n[Severity.MAJOR]:
        return 3
    if any(f.dimension in (Dimension.CORRECTNESS, Dimension.SECURITY) for f in open_findings):
        return 3
    if n[Severity.MINOR]:
        return 4
    return 5
