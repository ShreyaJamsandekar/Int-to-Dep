"""Part B2: UI contracts (UiElement, Screen, UiSpec) compatible with Pydantic v1 & v2."""
from __future__ import annotations

from typing import Any, Literal
from pydantic import Field
from .base import PYDANTIC_V2, Contract, regex_field, ScreenId, StoryId, AcId

if PYDANTIC_V2:
    from pydantic import model_validator
else:
    from pydantic import root_validator  # type: ignore


def _min_list(n: int = 1) -> Any:
    return Field(min_length=n) if PYDANTIC_V2 else Field(min_items=n)


class UiElement(Contract):
    label: str
    role: Literal[
        "button",
        "link",
        "textbox",
        "checkbox",
        "select",
        "table",
        "heading",
        "list",
        "image",
        "nav",
        "dialog",
    ]
    region: Literal["header", "nav", "main", "aside", "footer", "dialog"]
    order: int = Field(ge=0)
    action: str | None = None


class Screen(Contract):
    id: ScreenId
    route: str = regex_field("^/[a-z0-9/_:-]*$")
    title: str
    story_ids: list[StoryId] = _min_list(1)
    ac_ids: list[AcId] = []
    elements: list[UiElement] = _min_list(1)
    states: list[Literal["empty", "loading", "error", "success"]] = [
        "empty",
        "loading",
        "error",
        "success",
    ]
    source_anchor: str | None = None
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)


def _validate_ui_spec(
    mode: str,
    screens: list[Screen],
    flows: list[list[str]],
) -> None:
    errs: list[str] = []
    known = {s.id for s in screens}
    if len(known) != len(screens):
        errs.append("duplicate screen ids")
    if len({s.route for s in screens}) != len(screens):
        errs.append("duplicate routes")
    errs += [
        f"flow references unknown screen {x}"
        for f in flows
        for x in f
        if x not in known
    ]
    if mode == "wireframe":
        errs += [
            f"{s.id}: missing wireframe anchor"
            for s in screens
            if not s.source_anchor
        ]
    if errs:
        raise ValueError("; ".join(errs))


class UiSpec(Contract):
    mode: Literal["wireframe", "design_system"]
    design_system: str | None = "tailwind-shadcn"
    roles: list[str] = []
    screens: list[Screen] = _min_list(1)
    flows: list[list[ScreenId]] = []

    if PYDANTIC_V2:
        @model_validator(mode="after")
        def valid(self):
            _validate_ui_spec(self.mode, self.screens, self.flows)
            return self
    else:
        @root_validator
        def valid(cls, values: dict[str, Any]) -> dict[str, Any]:
            if "screens" in values and "mode" in values:
                _validate_ui_spec(
                    values["mode"],
                    values.get("screens", []),
                    values.get("flows", []),
                )
            return values
