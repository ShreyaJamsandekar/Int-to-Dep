"""Stage H0: HLD Handoff intake, validation, UI screen confidence check, and KG initialization."""
from __future__ import annotations

import json
from pathlib import Path
from pipeline.contracts.base import utc_now_iso, sha256_obj
from pipeline.contracts.envelope import StageResult
from pipeline.contracts.handoff import HLDHandoff
from pipeline.graph.sqlite_adapter import SQLiteKnowledgeGraph


def detect_low_confidence_screens(handoff: HLDHandoff) -> list[str]:
    if not handoff.ui:
        return []
    return [
        f"{sc.id} ({sc.route}): confidence {sc.confidence:.2f} < 0.70"
        for sc in handoff.ui.screens
        if sc.confidence < 0.7
    ]


def run_h0_intake(
    handoff_source: str | Path | dict,
    kg: SQLiteKnowledgeGraph,
    run_id: str = "run-2026-10-22-001",
) -> StageResult[HLDHandoff]:
    started = utc_now_iso()
    if isinstance(handoff_source, (str, Path)):
        raw = json.loads(Path(handoff_source).read_text(encoding="utf-8"))
    else:
        raw = handoff_source

    handoff = HLDHandoff.parse_obj_compat(raw)
    major_ver = int(handoff.handoff_version.split(".")[0])
    if major_ver != 1:
        raise ValueError(f"Unsupported handoff major version: {handoff.handoff_version}")

    ep = kg.load_handoff(handoff, run_id=run_id)
    if handoff.ui:
        for sc in handoff.ui.screens:
            kg.upsert_node(sc.id, "Screen", sc.dump_json_dict(), run_id=run_id)
            for st_id in sc.story_ids:
                kg.add_edge(sc.id, st_id, "DERIVES_FROM")
            for ac_id in sc.ac_ids:
                kg.add_edge(sc.id, ac_id, "SATISFIES")

    validators = [
        "pydantic_strict_schema",
        "major_version_check",
        "referential_integrity",
        "runtime_dependency_acyclicity",
        "kg_epoch_loaded",
    ]
    low_conf = detect_low_confidence_screens(handoff)
    if handoff.ui and not low_conf:
        validators.append("ui_screen_confidence_ok")

    finished = utc_now_iso()
    return StageResult(
        stage="H0_INTAKE",
        run_id=run_id,
        graph_epoch=ep,
        input_hash=sha256_obj(raw),
        model_id="none",
        payload=handoff,
        validators_passed=validators,
        started_at=started,
        finished_at=finished,
    )
