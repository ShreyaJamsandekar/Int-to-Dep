"""Stage L2a: Deterministic Scaffold, Design-System UI, and Runnable App Server Generator."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from pipeline.contracts.handoff import HLDHandoff
from pipeline.contracts.lld import LLDPack


DESIGN_TOKENS = {
    "design_system": "tailwind-shadcn",
    "spacing": {"xs": "0.25rem", "sm": "0.5rem", "md": "1rem", "lg": "1.5rem", "xl": "2rem"},
    "radius": {"sm": "0.25rem", "md": "0.5rem", "lg": "0.75rem"},
    "type_scale": {"sm": "0.875rem", "base": "1rem", "lg": "1.125rem", "xl": "1.25rem", "2xl": "1.5rem"},
    "colors": {
        "light": {
            "background": "#f8fafc",
            "surface": "#ffffff",
            "text": "#0f172a",
            "muted": "#475569",
            "primary": "#2563eb",
            "danger": "#dc2626",
            "success": "#16a34a",
            "border": "#e2e8f0",
        },
        "dark": {
            "background": "#0f172a",
            "surface": "#1e293b",
            "text": "#f8fafc",
            "muted": "#94a3b8",
            "primary": "#3b82f6",
            "danger": "#ef4444",
            "success": "#22c55e",
            "border": "#334155",
        },
    },
}


def _build_ui_html(handoff: HLDHandoff) -> str:
    if handoff.ui:
        ui_dict = handoff.ui.dump_json_dict()
    else:
        ui_dict = {
            "mode": "design_system",
            "design_system": "tailwind-shadcn",
            "roles": ["user"],
            "screens": [
                {
                    "id": "SCR-001",
                    "route": "/",
                    "title": f"{handoff.handoff_id} Workspace",
                    "story_ids": [handoff.stories[0].story_id],
                    "ac_ids": [handoff.stories[0].criteria[0].id],
                    "elements": [
                        {"label": handoff.handoff_id, "role": "heading", "region": "header", "order": 0},
                        {"label": "Dashboard", "role": "link", "region": "nav", "order": 0, "action": "navigate:SCR-001"},
                        {"label": "Payload Input", "role": "textbox", "region": "main", "order": 0},
                        {"label": "Submit Action", "role": "button", "region": "main", "order": 1, "action": "POST /api/dispatch"},
                        {"label": "Activity Table", "role": "table", "region": "main", "order": 2},
                    ],
                    "states": ["empty", "loading", "error", "success"],
                }
            ],
            "flows": [["SCR-001"]],
        }

    is_chess = "chess" in handoff.handoff_id.lower() or any(
        "chess" in c.name.lower() for c in handoff.components
    )
    primary_term = (
        handoff.domain_glossary[0].canonical_snake
        if handoff.domain_glossary
        else "item_code"
    )

    screen_sections: list[str] = []
    for sc in ui_dict["screens"]:
        by_region: dict[str, list[dict[str, Any]]] = {
            r: [] for r in ("header", "nav", "main", "aside", "footer", "dialog")
        }
        for el in sorted(sc["elements"], key=lambda x: x["order"]):
            by_region.setdefault(el["region"], []).append(el)

        region_blocks: list[str] = []
        for reg_name in ("header", "nav", "main", "aside", "footer", "dialog"):
            els = by_region.get(reg_name, [])
            if not els:
                continue
            inner: list[str] = []
            for el in els:
                role = el["role"]
                lbl = el["label"]
                order = el["order"]
                act = el.get("action") or ""
                inner.append(
                    f'<div class="ui-element" role="{role}" aria-label="{lbl}" '
                    f'data-region="{reg_name}" data-order="{order}" data-action="{act}">{lbl}</div>'
                )
            tag = reg_name if reg_name in ("header", "nav", "main", "aside", "footer", "dialog") else "section"
            open_attr = " open" if tag == "dialog" else ""
            region_blocks.append(
                f'<{tag} class="ui-region region-{reg_name}" data-region="{reg_name}"{open_attr}>'
                + "".join(inner)
                + f"</{tag}>"
            )
        screen_sections.append(
            f'<section class="screen-card" id="screen-{sc["id"]}" data-screen-id="{sc["id"]}" data-route="{sc["route"]}">'
            f'<h2>{sc["id"]} — {sc["title"]} (<code>{sc["route"]}</code>)</h2>'
            + "".join(region_blocks)
            + "</section>"
        )

    chess_html = ""
    if is_chess:
        chess_html = """
        <section class="card" id="chess-arena">
          <h2>Interactive Chess Match Board (Connected to Backend Engine)</h2>
          <p class="muted">Click a piece square then a target square (or enter algebraic coordinates like <code>e2</code> to <code>e4</code>) to validate and execute moves via the backend service.</p>
          <div class="chess-controls">
            <label>From: <input id="chess-from" type="text" value="e2" aria-label="From Square" /></label>
            <label>To: <input id="chess-to" type="text" value="e4" aria-label="To Square" /></label>
            <button id="chess-move-btn" type="button" onclick="submitChessMove()">Execute Move</button>
            <button id="chess-reset-btn" type="button" class="secondary" onclick="resetChessBoard()">Reset Board</button>
            <span id="chess-turn-badge" class="badge">Turn: White</span>
          </div>
          <div id="chess-board" class="chess-board" role="grid" aria-label="Chess Board"></div>
        </section>
        """

    return f"""<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{handoff.handoff_id} — Generated Enterprise App</title>
  <link rel="stylesheet" href="/ui/styles.css" />
</head>
<body>
  <div class="container">
    <div class="topbar">
      <div>
        <span class="badge">App ID: {handoff.handoff_id}</span>
        <span class="badge">UI Mode: {ui_dict.get("mode", "design_system")}</span>
        <span class="badge">Tokens: {ui_dict.get("design_system", "tailwind-shadcn")}</span>
      </div>
      <div class="state-switcher" role="group" aria-label="Screen State Switcher">
        <span>Screen State:</span>
        <button type="button" onclick="setUiState('empty')">Empty</button>
        <button type="button" onclick="setUiState('loading')">Loading</button>
        <button type="button" onclick="setUiState('error')">Error</button>
        <button type="button" onclick="setUiState('success')">Success</button>
        <button type="button" onclick="toggleTheme()">Light/Dark</button>
      </div>
    </div>

    <div id="ui-state-banner" class="state-banner" data-state="success">
      Active UI State: <strong id="ui-state-label">success</strong> — All endpoints ready.
    </div>

    {chess_html}

    <section class="card">
      <h2>Live Service Console & API Dispatcher</h2>
      <div class="form-row">
        <label>Endpoint Handler:
          <select id="endpoint-select" aria-label="Endpoint Handler"></select>
        </label>
        <label>{primary_term}:
          <input id="field-primary" type="text" value="{'e2e4' if is_chess else 'SKU-100'}" aria-label="{primary_term}" />
        </label>
        <label>Quantity / Move Number:
          <input id="field-qty" type="number" value="1" aria-label="Quantity" />
        </label>
        <button type="button" onclick="sendApiRequest()">Run Service Endpoint</button>
      </div>
      <pre id="api-output" aria-live="polite">Click "Run Service Endpoint" to call the backend.</pre>
    </section>

    <div class="screens-grid">
      {"".join(screen_sections)}
    </div>
  </div>

  <script>
    const PRIMARY_FIELD = {json.dumps(primary_term)};
    const IS_CHESS = {json.dumps(is_chess)};

    function setUiState(state) {{
      const banner = document.getElementById('ui-state-banner');
      const label = document.getElementById('ui-state-label');
      banner.setAttribute('data-state', state);
      label.textContent = state;
    }}

    function toggleTheme() {{
      const root = document.documentElement;
      root.setAttribute('data-theme', root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    }}

    async function loadSpec() {{
      const res = await fetch('/api/spec');
      const data = await res.json();
      const sel = document.getElementById('endpoint-select');
      sel.innerHTML = '';
      (data.handlers || []).forEach(h => {{
        const opt = document.createElement('option');
        opt.value = h;
        opt.textContent = h;
        sel.appendChild(opt);
      }});
    }}

    async function sendApiRequest() {{
      setUiState('loading');
      const endpoint = document.getElementById('endpoint-select').value;
      const val = document.getElementById('field-primary').value;
      const qty = parseInt(document.getElementById('field-qty').value || '1', 10);
      const payload = {{ quantity: qty }};
      payload[PRIMARY_FIELD] = val;
      try {{
        const res = await fetch('/api/dispatch', {{
          method: 'POST',
          headers: {{ 'Content-Type': 'application/json' }},
          body: JSON.stringify({{ endpoint, payload }})
        }});
        const out = await res.json();
        document.getElementById('api-output').textContent = JSON.stringify(out, null, 2);
        setUiState(out.status === 200 ? 'success' : 'error');
      }} catch (err) {{
        document.getElementById('api-output').textContent = String(err);
        setUiState('error');
      }}
    }}

    const INITIAL_BOARD = [
      ['r','n','b','q','k','b','n','r'],
      ['p','p','p','p','p','p','p','p'],
      ['','','','','','','',''],
      ['','','','','','','',''],
      ['','','','','','','',''],
      ['','','','','','','',''],
      ['P','P','P','P','P','P','P','P'],
      ['R','N','B','Q','K','B','N','R']
    ];
    const GLYPHS = {{
      K:'♔', Q:'♕', R:'♖', B:'♗', N:'♘', P:'♙',
      k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟', '':''
    }};
    let boardState = JSON.parse(JSON.stringify(INITIAL_BOARD));
    let selectedSq = null;
    let moveCount = 1;
    let whiteToMove = true;

    function sqName(r, c) {{
      return 'abcdefgh'[c] + (8 - r);
    }}

    function parseSq(s) {{
      if (!s || s.length !== 2) return null;
      const c = 'abcdefgh'.indexOf(s[0].toLowerCase());
      const r = 8 - parseInt(s[1], 10);
      if (c < 0 || c > 7 || isNaN(r) || r < 0 || r > 7) return null;
      return [r, c];
    }}

    function renderChessBoard() {{
      const el = document.getElementById('chess-board');
      if (!el) return;
      el.innerHTML = '';
      for (let r = 0; r < 8; r++) {{
        for (let c = 0; c < 8; c++) {{
          const sq = sqName(r, c);
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'chess-sq ' + ((r + c) % 2 === 0 ? 'light' : 'dark') + (selectedSq === sq ? ' selected' : '');
          btn.setAttribute('data-square', sq);
          btn.setAttribute('aria-label', 'Square ' + sq);
          btn.textContent = GLYPHS[boardState[r][c]] || '';
          btn.onclick = () => onSquareClick(sq);
          el.appendChild(btn);
        }}
      }}
    }}

    function onSquareClick(sq) {{
      if (!selectedSq) {{
        selectedSq = sq;
        document.getElementById('chess-from').value = sq;
        renderChessBoard();
      }} else {{
        document.getElementById('chess-to').value = sq;
        selectedSq = null;
        submitChessMove();
      }}
    }}

    async function submitChessMove() {{
      const fromSq = document.getElementById('chess-from').value.trim();
      const toSq = document.getElementById('chess-to').value.trim();
      const fc = parseSq(fromSq);
      const tc = parseSq(toSq);
      if (!fc || !tc || (fc[0] === tc[0] && fc[1] === tc[1])) {{
        setUiState('error');
        return;
      }}
      const piece = boardState[fc[0]][fc[1]];
      if (!piece) {{
        setUiState('error');
        return;
      }}
      document.getElementById('field-primary').value = fromSq + toSq;
      document.getElementById('field-qty').value = String(moveCount);
      await sendApiRequest();
      boardState[tc[0]][tc[1]] = piece;
      boardState[fc[0]][fc[1]] = '';
      whiteToMove = !whiteToMove;
      moveCount += 1;
      document.getElementById('chess-turn-badge').textContent = 'Turn: ' + (whiteToMove ? 'White' : 'Black');
      renderChessBoard();
    }}

    function resetChessBoard() {{
      boardState = JSON.parse(JSON.stringify(INITIAL_BOARD));
      selectedSq = null;
      moveCount = 1;
      whiteToMove = true;
      document.getElementById('chess-turn-badge').textContent = 'Turn: White';
      renderChessBoard();
    }}

    window.addEventListener('DOMContentLoaded', () => {{
      loadSpec();
      if (IS_CHESS) renderChessBoard();
    }});
  </script>
</body>
</html>
"""


def run_l2_scaffold(
    handoff: HLDHandoff,
    lld: LLDPack | None,
    repo_root: Path,
) -> list[str]:
    repo_root.mkdir(parents=True, exist_ok=True)
    created: list[str] = []

    def write(rel: str, content: str) -> None:
        p = repo_root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        created.append(rel)

    write("app/__init__.py", "# Enterprise FastAPI application root\n")
    write("app/api/__init__.py", "# API package\n")
    write("app/db/__init__.py", "# Database package\n")
    write("services/__init__.py", "# Generated service modules\n")
    write("tests/__init__.py", "# Test package\n")
    write("tests/unit/__init__.py", "# Unit tests\n")
    write("tests/acceptance/__init__.py", "# Frozen black-box acceptance oracle suite\n")
    write("tests/harness/__init__.py", "# Deterministic test state seeder harness\n")

    api_modules = [m.path[:-3].replace("/", ".") for m in (lld.modules if lld else []) if m.layer == "api"]
    router_reg_lines = [
        "# Auto-generated router registry from LLDPack. DO NOT EDIT IN WORKER.",
        "from __future__ import annotations",
        "import importlib",
        "from typing import Any",
        f"REGISTERED_API_MODULES: list[str] = {json.dumps(api_modules)}",
        "def load_registered_handlers() -> dict[str, Any]:",
        "    handlers: dict[str, Any] = {}",
        "    for mod_path in REGISTERED_API_MODULES:",
        "        try:",
        "            mod = importlib.import_module(mod_path)",
        "            for attr in dir(mod):",
        "                if attr.startswith('handle_'):",
        "                    handlers[attr] = getattr(mod, attr)",
        "        except Exception:",
        "            continue",
        "    return handlers",
    ]
    write("app/api/router_registry.py", chr(10).join(router_reg_lines) + chr(10))

    tables = [t.table_name for m in (lld.modules if lld else []) for t in m.tables]
    model_reg_lines = [
        "# Auto-generated persistence table registry from LLDPack. DO NOT EDIT IN WORKER.",
        "from __future__ import annotations",
        f"REGISTERED_TABLES: list[str] = {json.dumps(tables)}",
    ]
    write("app/db/model_registry.py", chr(10).join(model_reg_lines) + chr(10))

    main_lines = [
        "# Enterprise service entrypoint with health/readiness probes and RFC 7807 error formatting.",
        "from __future__ import annotations",
        "from typing import Any",
        "from app.api.router_registry import load_registered_handlers",
        "from app.db.model_registry import REGISTERED_TABLES",
        "def healthz() -> dict[str, str]:",
        "    return {'status': 'ok'}",
        "def readyz() -> dict[str, Any]:",
        "    return {'status': 'ready', 'tables_registered': len(REGISTERED_TABLES)}",
        "def problem_details(status: int, title: str, detail: str, type_uri: str = 'about:blank') -> dict[str, Any]:",
        "    return {'type': type_uri, 'title': title, 'status': status, 'detail': detail}",
        "def dispatch_request(endpoint_name: str, payload: dict[str, Any], traceparent: str = '00-default-01') -> dict[str, Any]:",
        "    handlers = load_registered_handlers()",
        "    if endpoint_name not in handlers:",
        "        return problem_details(404, 'Not Found', f'Endpoint {endpoint_name} not registered')",
        "    try:",
        "        res = handlers[endpoint_name](payload)",
        "        return {'status': 200, 'traceparent': traceparent, 'data': res}",
        "    except Exception as exc:",
        "        return problem_details(422, exc.__class__.__name__, str(exc))",
    ]
    write("app/main.py", chr(10).join(main_lines) + chr(10))

    seeder_lines = [
        "# Deterministic state seeding harness for black-box acceptance tests.",
        "from __future__ import annotations",
        "from typing import Any",
        "class StateSeeder:",
        "    def __init__(self) -> None:",
        "        self._store: dict[str, list[dict[str, Any]]] = {}",
        "    def given_entity_exists(self, table_name: str, record: dict[str, Any]) -> dict[str, Any]:",
        "        self._store.setdefault(table_name, []).append(dict(record))",
        "        return record",
        "    def list_entities(self, table_name: str) -> list[dict[str, Any]]:",
        "        return list(self._store.get(table_name, []))",
    ]
    write("tests/harness/state_seeder.py", chr(10).join(seeder_lines) + chr(10))

    write("ui/design_tokens.json", json.dumps(DESIGN_TOKENS, indent=2) + chr(10))
    write(
        "ui/styles.css",
        """/* Fixed Design System Token Stylesheet (tailwind-shadcn tokens) */
:root, [data-theme="light"] {
  --bg: #f8fafc; --surface: #ffffff; --text: #0f172a; --muted: #475569;
  --primary: #2563eb; --danger: #dc2626; --success: #16a34a; --border: #e2e8f0;
  --space-sm: 0.5rem; --space-md: 1rem; --space-lg: 1.5rem; --radius-md: 0.5rem;
}
[data-theme="dark"] {
  --bg: #0f172a; --surface: #1e293b; --text: #f8fafc; --muted: #94a3b8;
  --primary: #3b82f6; --danger: #ef4444; --success: #22c55e; --border: #334155;
}
* { box-sizing: border-box; }
body { margin: 0; font-family: system-ui, sans-serif; background: var(--bg); color: var(--text); overflow-x: hidden; }
.container { max-width: 1120px; margin: 0 auto; padding: var(--space-lg); }
.topbar { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: var(--space-sm); margin-bottom: var(--space-md); }
.badge { display: inline-block; padding: 0.25rem 0.6rem; border-radius: var(--radius-md); background: var(--surface); border: 1px solid var(--border); font-size: 0.875rem; margin-right: 0.35rem; }
.card, .screen-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-md); padding: var(--space-md); margin-bottom: var(--space-md); }
.state-banner { padding: var(--space-sm) var(--space-md); border-radius: var(--radius-md); border: 1px solid var(--border); margin-bottom: var(--space-md); background: var(--surface); }
.form-row, .chess-controls { display: flex; flex-wrap: wrap; gap: var(--space-sm); align-items: center; margin-bottom: var(--space-sm); }
input, select, button { padding: 0.45rem 0.75rem; border-radius: var(--radius-md); border: 1px solid var(--border); font-size: 0.9rem; }
button { background: var(--primary); color: #ffffff; cursor: pointer; border: none; }
button.secondary { background: var(--muted); }
pre { background: var(--bg); padding: var(--space-md); border-radius: var(--radius-md); border: 1px solid var(--border); overflow-x: auto; }
.ui-region { padding: var(--space-sm); border: 1px dashed var(--border); border-radius: var(--radius-md); margin-top: var(--space-sm); }
.ui-element { padding: 0.35rem 0.6rem; margin: 0.25rem 0; background: var(--bg); border-radius: var(--radius-md); }
.chess-board { display: grid; grid-template-columns: repeat(8, 2.75rem); grid-template-rows: repeat(8, 2.75rem); gap: 2px; margin-top: var(--space-sm); }
.chess-sq { width: 2.75rem; height: 2.75rem; font-size: 1.4rem; display: flex; align-items: center; justify-content: center; padding: 0; }
.chess-sq.light { background: #e2e8f0; color: #0f172a; }
.chess-sq.dark { background: #64748b; color: #0f172a; }
.chess-sq.selected { outline: 3px solid var(--primary); }
""",
    )
    write("ui/index.html", _build_ui_html(handoff))
    write("ui/screenshots/SCR-001-1280.png", "PNG_PLACEHOLDER_1280" + chr(10))

    run_app_lines = [
        f"# Standalone runnable web & API server for {handoff.handoff_id}.",
        "from __future__ import annotations",
        "import argparse",
        "import json",
        "import sys",
        "from http.server import BaseHTTPRequestHandler, HTTPServer",
        "from pathlib import Path",
        "",
        "ROOT_DIR = Path(__file__).resolve().parent",
        "if str(ROOT_DIR) not in sys.path:",
        "    sys.path.insert(0, str(ROOT_DIR))",
        "",
        "from app.main import healthz, readyz, dispatch_request",
        "from app.api.router_registry import load_registered_handlers",
        "",
        "class AppHTTPHandler(BaseHTTPRequestHandler):",
        "    def _send_json(self, code: int, payload: dict) -> None:",
        "        raw = json.dumps(payload, indent=2).encode('utf-8')",
        "        self.send_response(code)",
        "        self.send_header('Content-Type', 'application/json; charset=utf-8')",
        "        self.send_header('Content-Length', str(len(raw)))",
        "        self.end_headers()",
        "        self.wfile.write(raw)",
        "",
        "    def _send_file(self, rel_path: str, content_type: str) -> None:",
        "        fpath = ROOT_DIR / rel_path",
        "        if not fpath.is_file():",
        "            self._send_json(404, {'error': f'File {rel_path} not found'})",
        "            return",
        "        raw = fpath.read_bytes()",
        "        self.send_response(200)",
        "        self.send_header('Content-Type', content_type)",
        "        self.send_header('Content-Length', str(len(raw)))",
        "        self.end_headers()",
        "        self.wfile.write(raw)",
        "",
        "    def do_GET(self) -> None:",
        "        if self.path == '/healthz':",
        "            self._send_json(200, healthz())",
        "        elif self.path == '/readyz':",
        "            self._send_json(200, readyz())",
        "        elif self.path == '/api/spec':",
        "            handlers = sorted(load_registered_handlers().keys())",
        f"            self._send_json(200, {{'handoff_id': {json.dumps(handoff.handoff_id)}, 'handlers': handlers}})",
        "        elif self.path == '/ui/styles.css':",
        "            self._send_file('ui/styles.css', 'text/css; charset=utf-8')",
        "        elif self.path == '/ui/design_tokens.json':",
        "            self._send_file('ui/design_tokens.json', 'application/json; charset=utf-8')",
        "        else:",
        "            self._send_file('ui/index.html', 'text/html; charset=utf-8')",
        "",
        "    def do_POST(self) -> None:",
        "        if self.path == '/api/dispatch':",
        "            length = int(self.headers.get('Content-Length', '0'))",
        "            body = json.loads(self.rfile.read(length).decode('utf-8') or '{}')",
        "            endpoint = body.get('endpoint', '')",
        "            payload = body.get('payload', {})",
        "            res = dispatch_request(endpoint, payload)",
        "            self._send_json(res.get('status', 200), res)",
        "        else:",
        "            self._send_json(404, {'error': 'Unknown POST endpoint'})",
        "",
        "    def log_message(self, fmt: str, *args) -> None:",
        "        return",
        "",
        "def main() -> int:",
        "    parser = argparse.ArgumentParser(description='Run generated enterprise application & UI')",
        "    parser.add_argument('--host', default='127.0.0.1')",
        "    parser.add_argument('--port', type=int, default=8000)",
        "    parser.add_argument('--self-test', action='store_true')",
        "    args = parser.parse_args()",
        "    if args.self_test:",
        "        handlers = load_registered_handlers()",
        "        print('Healthz:', healthz())",
        "        print('Readyz: ', readyz())",
        "        print('UI HTML:', (ROOT_DIR / 'ui/index.html').is_file())",
        "        print('Registered Endpoint Handlers:', sorted(handlers.keys()))",
        "        return 0",
        "    server = HTTPServer((args.host, args.port), AppHTTPHandler)",
        f"    print(f'Serving {handoff.handoff_id} UI & API at http://{{args.host}}:{{args.port}}')",
        "    server.serve_forever()",
        "    return 0",
        "",
        "if __name__ == '__main__':",
        "    raise SystemExit(main())",
    ]
    write("run_app.py", chr(10).join(run_app_lines) + chr(10))

    if lld:
        for con in lld.api_contracts:
            write(
                con.path,
                f"openapi: 3.1.0{chr(10)}info:{chr(10)}  title: {handoff.handoff_id}{chr(10)}  version: {lld.lld_version}{chr(10)}paths: {{}}{chr(10)}",
            )
        for mod in lld.modules:
            for tbl in mod.tables:
                cols_sql = ", ".join(f"{c.name} {c.type_annotation}" for c in tbl.columns)
                write(
                    f"migrations/001_{tbl.table_name}.sql",
                    f"-- UP{chr(10)}CREATE TABLE IF NOT EXISTS {tbl.table_name} ({cols_sql});{chr(10)}-- DOWN{chr(10)}DROP TABLE IF EXISTS {tbl.table_name};{chr(10)}",
                )
        for mod in lld.modules:
            pkg_dir = Path(mod.path).parent
            write(str(pkg_dir / "__init__.py"), "# Service component package." + chr(10))
            stub_lines = [
                f"# Stub for {mod.id} ({mod.path}).",
                "from __future__ import annotations",
                "from dataclasses import dataclass",
                "",
            ]
            for err in mod.errors:
                stub_lines += [f"class {err.exception_name}(Exception):", "    pass", ""]
            for dto in mod.data_models:
                stub_lines.append("@dataclass")
                stub_lines.append(f"class {dto.name}:")
                for fld in dto.fields:
                    stub_lines.append(f"    {fld.name}: {fld.type_annotation}")
                stub_lines.append("")
            for fn in mod.public_interface:
                stub_lines += [
                    f"{fn.signature}:",
                    "    raise NotImplementedError('Stub pending L3 build')",
                    "",
                ]
            write(mod.path, chr(10).join(stub_lines))

    write("Dockerfile", f"FROM python:3.12-slim{chr(10)}RUN useradd -m -u 10001 appuser{chr(10)}USER 10001{chr(10)}WORKDIR /app{chr(10)}COPY . /app{chr(10)}")
    write("helm/values.yaml", f"targetPlatform: {handoff.target_platform}{chr(10)}replicaCount: 2{chr(10)}podDisruptionBudget:{chr(10)}  minAvailable: 1{chr(10)}networkPolicy:{chr(10)}  enabled: true{chr(10)}")
    write("suppressions.yaml", "suppressions: []" + chr(10))
    write(".graphifyrc", f"# Graphify v8 project configuration{chr(10)}viz_node_limit=0{chr(10)}")
    return created
