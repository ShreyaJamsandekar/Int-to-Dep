"""Part A: Model-Optional LLM Layer (live | mock | none | auto) with role resolution and repair."""
from __future__ import annotations

import json
import os
import time
import urllib.request
from typing import Any, Protocol
from pydantic import BaseModel, ValidationError
from pipeline.contracts.base import Contract, sha256_obj


class ModelCaps(BaseModel):
    context_tokens: int
    tools: bool
    structured: bool
    vision: bool


class RoleCfg(BaseModel):
    model: str
    temperature: float = 0.0
    max_steps: int = 20
    max_tokens_per_run: int = 200_000
    needs_tools: bool = False
    needs_vision: bool = False
    min_context: int = 16_000


class ModelRequiredReport(Contract):
    stage: str
    role: str
    reason: str
    expected_artifact: str
    manual_override_hint: str
    created_at: str


class LLMClient(Protocol):
    def caps(self, model: str) -> ModelCaps: ...
    def generate_structured(
        self, model: str, prompt: str, schema: type[BaseModel], **kw: Any
    ) -> BaseModel: ...
    def chat_with_tools(
        self, model: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]], **kw: Any
    ) -> dict[str, Any]: ...


class ModelRequired(Exception):
    def __init__(self, role: str, reason: str, stage: str = "", expected_artifact: str = "") -> None:
        super().__init__(f"{role}: {reason}")
        self.role = role
        self.reason = reason
        self.stage = stage
        self.expected_artifact = expected_artifact


class BudgetExceeded(Exception):
    pass


class StepLimitExceeded(Exception):
    pass


DEFAULT_ROLES: dict[str, RoleCfg] = {
    "lld_architect": RoleCfg(model=os.environ.get("MODEL_STRONG", "gemini-2.5-pro"), needs_tools=False, min_context=32000),
    "planner": RoleCfg(model=os.environ.get("MODEL_FAST", "gemini-2.5-flash"), needs_tools=False),
    "oracle_writer": RoleCfg(model=os.environ.get("MODEL_STRONG", "gemini-2.5-pro"), needs_tools=False),
    "coder": RoleCfg(model=os.environ.get("MODEL_STRONG", "gemini-2.5-pro"), needs_tools=True, min_context=32000),
    "reviewer": RoleCfg(model=os.environ.get("MODEL_STRONG", "gemini-2.5-pro"), needs_tools=True, min_context=32000),
    "validator": RoleCfg(model=os.environ.get("MODEL_FAST", "gemini-2.5-flash")),
    "journey": RoleCfg(model=os.environ.get("MODEL_STRONG", "gemini-2.5-pro"), needs_tools=True),
    "vision": RoleCfg(model=os.environ.get("MODEL_VISION", "gemini-2.5-pro"), needs_vision=True),
}


def resolve_roles(
    mode: str, roles: dict[str, RoleCfg], client: LLMClient | None
) -> tuple[str, dict[str, RoleCfg], dict[str, str]]:
    if mode == "none" or client is None:
        return "none", {}, {r: "no model configured" for r in roles}
    enabled: dict[str, RoleCfg] = {}
    blocked: dict[str, str] = {}
    for name, cfg in roles.items():
        try:
            caps = client.caps(cfg.model)
        except Exception as e:
            blocked[name] = f"model unreachable: {e}"
            continue
        if cfg.needs_tools and not caps.tools:
            blocked[name] = "model lacks tool calling"
        elif cfg.needs_vision and not caps.vision:
            blocked[name] = "model lacks vision"
        elif caps.context_tokens < cfg.min_context:
            blocked[name] = "context window too small"
        else:
            enabled[name] = cfg
    if not enabled:
        return "none", {}, blocked
    return ("mock" if mode == "mock" else "live"), enabled, blocked


def compute_role_token_budget(caps: ModelCaps) -> int:
    return min(24000, int(0.6 * caps.context_tokens))


def _parse_json_with_schema(text: str, schema: type[BaseModel]) -> BaseModel:
    if hasattr(schema, "parse_json_compat"):
        return schema.parse_json_compat(text)  # type: ignore[attr-defined]
    if hasattr(schema, "model_validate_json"):
        return schema.model_validate_json(text)  # type: ignore[attr-defined]
    return schema.parse_raw(text)


def _dump_json_from_model(instance: BaseModel) -> str:
    if hasattr(instance, "to_pretty_json"):
        return instance.to_pretty_json()  # type: ignore[attr-defined]
    if hasattr(instance, "model_dump_json"):
        return instance.model_dump_json()  # type: ignore[attr-defined]
    return instance.json()


def validate_or_repair(
    client: LLMClient,
    role: RoleCfg,
    text: str,
    schema: type[BaseModel],
    tries: int = 2,
) -> BaseModel:
    for attempt in range(tries + 1):
        try:
            return _parse_json_with_schema(text, schema)
        except (ValidationError, ValueError) as e:
            if attempt == tries:
                raise
            repaired = client.generate_structured(
                role.model,
                f"Fix this JSON so it satisfies the schema." + chr(10) + f"Errors:{e}" + chr(10) + f"JSON:{text}",
                schema,
            )
            text = _dump_json_from_model(repaired)
    raise RuntimeError("validate_or_repair exhausted")


def run_agent(
    client: LLMClient,
    role: RoleCfg,
    system: str,
    packet: str,
    tools: dict[str, Any],
    tool_specs: list[dict[str, Any]],
    schema: type[BaseModel],
) -> BaseModel:
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system},
        {"role": "user", "content": packet},
    ]
    spent = 0
    for _ in range(role.max_steps):
        reply = client.chat_with_tools(
            role.model, messages, tool_specs, temperature=role.temperature
        )
        spent += reply.get("usage", {}).get("total_tokens", 0)
        if spent > role.max_tokens_per_run:
            raise BudgetExceeded(f"Exceeded {role.max_tokens_per_run} tokens")
        if reply.get("tool_calls"):
            messages.append(reply["message"])
            for call in reply["tool_calls"]:
                out = tools[call["name"]](**call["arguments"])
                messages.append(
                    {"role": "tool", "tool_call_id": call["id"], "content": str(out)}
                )
            continue
        return validate_or_repair(client, role, reply["message"]["content"], schema)
    raise StepLimitExceeded(f"Exceeded {role.max_steps} steps")


class MockRuntimeClient:
    def __init__(
        self,
        context_tokens: int = 64_000,
        tools: bool = True,
        structured: bool = True,
        vision: bool = True,
    ) -> None:
        self._caps = ModelCaps(
            context_tokens=context_tokens,
            tools=tools,
            structured=structured,
            vision=structured if vision is None else vision,
        )
        self.call_log: list[dict[str, Any]] = []

    def caps(self, model: str) -> ModelCaps:
        return self._caps

    def generate_structured(
        self, model: str, prompt: str, schema: type[BaseModel], **kw: Any
    ) -> BaseModel:
        t0 = time.time()
        self.call_log.append(
            {
                "model": model,
                "prompt_hash": sha256_obj(prompt),
                "schema": schema.__name__,
                "latency_ms": round((time.time() - t0) * 1000, 2),
            }
        )
        raise LookupError(f"Mock structured handler requires explicit fixture for {schema.__name__}")

    def chat_with_tools(
        self, model: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]], **kw: Any
    ) -> dict[str, Any]:
        return {
            "message": {"role": "assistant", "content": messages[-1]["content"]},
            "tool_calls": [],
            "usage": {"total_tokens": 128},
        }


class OpenAICompatibleClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        vision_enabled: bool = True,
    ) -> None:
        self.base_url = (base_url or os.environ.get("LLM_BASE_URL") or "").rstrip("/")
        self.api_key = (
            api_key
            or os.environ.get("LLM_API_KEY")
            or os.environ.get("GEMINI_API_KEY")
            or os.environ.get("OPENAI_API_KEY")
            or ""
        )
        if not self.base_url and os.environ.get("GEMINI_API_KEY"):
            self.base_url = "https://generativelanguage.googleapis.com/v1beta/openai"
        elif not self.base_url and os.environ.get("OPENAI_API_KEY"):
            self.base_url = "https://api.openai.com/v1"
        self.vision_enabled = vision_enabled

    def is_configured(self) -> bool:
        return bool(self.base_url and self.api_key)

    def caps(self, model: str) -> ModelCaps:
        if not self.is_configured():
            raise ConnectionError("LLM_BASE_URL / LLM_API_KEY not configured")
        return ModelCaps(
            context_tokens=128_000,
            tools=True,
            structured=True,
            vision=self.vision_enabled,
        )

    def generate_structured(
        self, model: str, prompt: str, schema: type[BaseModel], **kw: Any
    ) -> BaseModel:
        if not self.is_configured():
            raise ConnectionError("LLM_BASE_URL / LLM_API_KEY not configured")
        url = f"{self.base_url}/chat/completions"
        payload = {
            "model": model,
            "temperature": kw.get("temperature", 0.0),
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": "Return valid JSON matching the requested schema."},
                {"role": "user", "content": prompt},
            ],
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            body = json.loads(resp.read().decode("utf-8"))
        content = body["choices"][0]["message"]["content"]
        return _parse_json_with_schema(content, schema)

    def chat_with_tools(
        self, model: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]], **kw: Any
    ) -> dict[str, Any]:
        if not self.is_configured():
            raise ConnectionError("LLM_BASE_URL / LLM_API_KEY not configured")
        url = f"{self.base_url}/chat/completions"
        payload: dict[str, Any] = {
            "model": model,
            "temperature": kw.get("temperature", 0.0),
            "messages": messages,
        }
        if tools:
            payload["tools"] = tools
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            body = json.loads(resp.read().decode("utf-8"))
        choice = body["choices"][0]
        return {
            "message": choice["message"],
            "tool_calls": choice["message"].get("tool_calls", []),
            "usage": body.get("usage", {"total_tokens": 0}),
        }


def build_client_for_mode(mode: str) -> tuple[str, LLMClient | None]:
    if mode == "mock":
        return "mock", MockRuntimeClient()
    if mode == "none":
        return "none", None
    live_client = OpenAICompatibleClient()
    if mode == "live":
        return "live", live_client
    if live_client.is_configured():
        return "live", live_client
    return "none", None
