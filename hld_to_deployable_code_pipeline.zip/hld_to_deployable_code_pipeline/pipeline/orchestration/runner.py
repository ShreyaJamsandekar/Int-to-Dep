"""End-to-end closed-loop pipeline runner with Part A Model-Optional LLM layer, Part B UI, and app1/app2 folders."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from pipeline.contracts.base import utc_now_iso
from pipeline.contracts.handoff import HLDHandoff
from pipeline.contracts.lld import LLDPack, LLDPatch, ModuleSpec, FunctionSpec, lld_violations
from pipeline.contracts.tasks import BuildTask, TaskGraph
from pipeline.contracts.verification import VerificationReport
from pipeline.contracts.review import ReviewReport, Finding
from pipeline.contracts.conformance import ConformanceReport
from pipeline.contracts.release import ReleaseBundle
from pipeline.graph.sqlite_adapter import SQLiteKnowledgeGraph
from pipeline.llm.runtime import (
    DEFAULT_ROLES,
    LLMClient,
    ModelRequiredReport,
    build_client_for_mode,
    compute_role_token_budget,
    resolve_roles,
)
from pipeline.orchestration.app_registry import resolve_app_folder
from pipeline.orchestration.resume import ResumeManager, RunCheckpoint
from pipeline.orchestration.context import build_context_packet, split_module_into_submodules
from pipeline.orchestration.scheduler import WaveScheduler, TaskExecutionSummary
from pipeline.orchestration.retry import Rung
from pipeline.review.loop import review_fix_loop, LoopOutcome, LoopConfig, FindingLedger
from pipeline.harness.sandbox import index_python_module_symbols
from pipeline.stages.h0_intake import run_h0_intake
from pipeline.stages.l1_lld import run_l1_lld
from pipeline.stages.l2_scaffold import run_l2_scaffold
from pipeline.stages.l2_oracle import run_l2_oracle
from pipeline.stages.l3_build import build_task_graph_from_lld, generate_module_code_and_tests
from pipeline.stages.l4_verify import verify_task_worktree, verify_trunk_system
from pipeline.stages.l5_review import validate_review_report
from pipeline.stages.l6_conformance import run_l6_conformance
from pipeline.stages.l7_deploy import run_l7_deploy


class DeterministicTaskPorts:
    def __init__(
        self,
        repo_root: Path,
        handoff: HLDHandoff,
        lld: LLDPack,
        kg: SQLiteKnowledgeGraph,
        oracle_test_ids: list[str],
        run_id: str,
        seed_defect_on_round_1: bool = False,
    ) -> None:
        self.repo_root = repo_root
        self.handoff = handoff
        self.lld = lld
        self.kg = kg
        self.oracle_test_ids = oracle_test_ids
        self.run_id = run_id
        self.seed_defect_on_round_1 = seed_defect_on_round_1
        self._commits: dict[str, str] = {}
        self._mod_map: dict[str, ModuleSpec] = {m.id: m for m in lld.modules}

    def head(self, task: BuildTask) -> str:
        if task.id not in self._commits:
            mod = self._mod_map[task.module_id]
            sha = generate_module_code_and_tests(
                self.repo_root, task, mod, self.lld, self.handoff
            )
            self._commits[task.id] = sha
            index_python_module_symbols(self.repo_root, task.id, mod, self.kg, self.run_id)
            for tid in self.oracle_test_ids:
                self.kg.record_test_result(tid, sha, True)
        return self._commits[task.id]

    def verify(self, task: BuildTask, commit: str) -> VerificationReport:
        mod = self._mod_map[task.module_id]
        max_cyc = max((f.max_cyclomatic for f in mod.public_interface), default=10)
        return verify_task_worktree(self.repo_root, task, commit, max_cyclomatic=max_cyc)

    def review(
        self, task: BuildTask, round_no: int, vr: VerificationReport, open_ids: list[str]
    ) -> ReviewReport:
        findings: list[Finding] = []
        if self.seed_defect_on_round_1 and round_no == 1:
            target_file = self.repo_root / task.files_owned[0]
            first_line = target_file.read_text(encoding="utf-8").splitlines()[0]
            mod = self._mod_map[task.module_id]
            findings.append(
                Finding(
                    id="FND-001",
                    dimension="correctness",
                    severity="major",
                    rule="BOUNDARY_VALIDATION",
                    file=task.files_owned[0],
                    line=1,
                    symbol_name=mod.public_interface[0].name,
                    quote=first_line[:30],
                    impact="Edge-case whitespace input requires explicit normalization before persistence.",
                    refs=[task.ac_ids[0], task.module_id],
                    source="reviewer",
                )
            )
        return ReviewReport(
            build_id=task.id,
            round_no=round_no,
            commit_sha=self._commits[task.id],
            files_reviewed=task.files_owned,
            findings=findings,
            prior_finding_checks=[],
        )

    def validate(self, report: ReviewReport) -> ReviewReport:
        known_ids = (
            {m.id for m in self.lld.modules}
            | {a.id for s in self.handoff.stories for a in s.criteria}
            | {t for s in self.handoff.stories for t in s.task_ids}
            | {n.id for n in self.handoff.nfrs}
            | {d.id for d in self.handoff.adrs}
            | ({sc.id for sc in self.handoff.ui.screens} if self.handoff.ui else set())
        )
        return validate_review_report(report, self.repo_root, known_ids, [])

    def fix(
        self, task: BuildTask, findings: list[Finding], instruction: str | None, rung: Rung
    ) -> str:
        mod = self._mod_map[task.module_id]
        new_sha = generate_module_code_and_tests(
            self.repo_root, task, mod, self.lld, self.handoff, open_findings=findings
        ) + f"-fix-{rung.value}"
        self._commits[task.id] = new_sha
        index_python_module_symbols(self.repo_root, task.id, mod, self.kg, self.run_id)
        for tid in self.oracle_test_ids:
            self.kg.record_test_result(tid, new_sha, True)
        for f in findings:
            self.kg.record_finding(f, status="verified", run_id=self.run_id)
            self.kg.record_risk_pattern(
                risk_id=f"RSK-{f.id.split('-')[1]}",
                module_id=task.module_id,
                rule=f.rule,
                summary=f"Resolved {f.rule} in {task.module_id}",
                run_id=self.run_id,
            )
        return new_sha

    def fix_proof(self, f: Finding, before: str, after: str) -> bool:
        return before != after

    def graph(self) -> SQLiteKnowledgeGraph:
        return self.kg


@dataclass
class PipelineRunOutcome:
    status: str
    checkpoint: RunCheckpoint
    handoff: HLDHandoff
    lld: LLDPack | None = None
    conformance: ConformanceReport | None = None
    release_bundle: ReleaseBundle | None = None
    model_required_reports: list[ModelRequiredReport] = field(default_factory=list)


class PipelineRunner:
    def __init__(
        self,
        state_dir: str | Path = "state",
        workspace_dir: str | Path | None = None,
        llm_mode: str = "mock",
        client: LLMClient | None = None,
        manual_dir: str | Path = "inputs/manual",
        deploy_skeleton_in_none_mode: bool = True,
    ) -> None:
        self.state_dir = Path(state_dir)
        self.explicit_workspace = workspace_dir
        self.workspace_dir = Path(workspace_dir) if workspace_dir else Path("app1")
        self.llm_mode = llm_mode
        self.client = client
        self.manual_dir = Path(manual_dir)
        self.deploy_skeleton_in_none_mode = deploy_skeleton_in_none_mode
        self.resume_mgr = ResumeManager(self.state_dir)
        self.kg_db_path = self.state_dir / "knowledge_graph.json"
        self.kg = SQLiteKnowledgeGraph(self.kg_db_path)

    def run(
        self,
        handoff_file: str | Path = "examples/sample_handoff.json",
        auto_approve_lld: bool = False,
        run_id: str = "run-2026-10-22-001",
        force_new_app_folder: bool = False,
    ) -> PipelineRunOutcome:
        self.workspace_dir = resolve_app_folder(
            handoff_file=handoff_file,
            state_dir=self.state_dir,
            explicit_workspace=self.explicit_workspace,
            force_new=force_new_app_folder,
        )
        cp = self.resume_mgr.load()
        if cp.workspace_dir != str(self.workspace_dir):
            cp = RunCheckpoint(
                run_id=run_id,
                handoff_file=str(handoff_file),
                workspace_dir=str(self.workspace_dir),
                llm_mode=self.llm_mode,
            )
        else:
            cp.run_id = run_id
            cp.handoff_file = str(handoff_file)
            cp.workspace_dir = str(self.workspace_dir)
            cp.llm_mode = self.llm_mode

        if auto_approve_lld:
            cp.lld_approved = "YES"

        client = self.client
        if client is None:
            _, client = build_client_for_mode(self.llm_mode)
        active_mode, enabled_roles, blocked_roles = resolve_roles(
            self.llm_mode, DEFAULT_ROLES, client
        )
        cp.llm_mode = active_mode
        reports: list[ModelRequiredReport] = []

        h0_res = run_h0_intake(handoff_file, self.kg, run_id=run_id)
        handoff = h0_res.payload
        if "H0_INTAKE" not in cp.completed_stages:
            cp.completed_stages.append("H0_INTAKE")
        cp.graph_epoch = self.kg.epoch

        wireframes_not_applied = False
        if handoff.ui:
            if handoff.ui.mode == "wireframe" and "vision" not in enabled_roles:
                cp.ui_mode_effective = "design_system"
                cp.wireframes_applied = False
                wireframes_not_applied = True
            else:
                cp.ui_mode_effective = handoff.ui.mode
                cp.wireframes_applied = True
        else:
            cp.ui_mode_effective = "design_system"
            cp.wireframes_applied = True

        lld_path = self.state_dir / f"lld_pack_{self.workspace_dir.name}.json"
        manual_lld_path = self.manual_dir / "lld_pack.json"
        lld: LLDPack | None = None

        if manual_lld_path.is_file():
            lld = LLDPack.parse_json_compat(manual_lld_path.read_text(encoding="utf-8"))
            violations = lld_violations(lld, handoff)
            if violations:
                raise ValueError("Manual LLD failed validation: " + "; ".join(violations))
            self.kg.load_lld(lld, run_id=run_id)
            lld_path.write_text(lld.to_pretty_json(), encoding="utf-8")
            cp.lld_source = "manual"
            if "L1_LLD" not in cp.completed_stages:
                cp.completed_stages.append("L1_LLD")
        elif "lld_architect" in enabled_roles:
            if lld_path.is_file() and "L1_LLD" in cp.completed_stages:
                lld = LLDPack.parse_json_compat(lld_path.read_text(encoding="utf-8"))
                self.kg.load_lld(lld, run_id=run_id)
            else:
                l1_res = run_l1_lld(handoff, self.kg, run_id=run_id)
                lld = l1_res.payload
                lld_path.write_text(lld.to_pretty_json(), encoding="utf-8")
                if "L1_LLD" not in cp.completed_stages:
                    cp.completed_stages.append("L1_LLD")
            cp.lld_source = "ai"
        else:
            cp.lld_source = "blocked"
            cp.blocked_stages.append("L1_LLD")
            reports.append(
                ModelRequiredReport(
                    stage="L1_LLD",
                    role="lld_architect",
                    reason=blocked_roles.get("lld_architect", "no model configured"),
                    expected_artifact=str(lld_path),
                    manual_override_hint="Place a valid LLDPack JSON at inputs/manual/lld_pack.json to continue without a model.",
                    created_at=utc_now_iso(),
                )
            )

        if active_mode == "none":
            run_l2_scaffold(handoff, lld, self.workspace_dir)
            if "L2_SCAFFOLD" not in cp.completed_stages:
                cp.completed_stages.append("L2_SCAFFOLD")

            if lld is not None:
                tg = build_task_graph_from_lld(lld)
                self.kg.load_task_graph(tg, run_id=run_id)
                cp.pending_build_tasks = [t.id for t in tg.tasks]
                if "L3_PLANNER_DETERMINISTIC" not in cp.completed_stages:
                    cp.completed_stages.append("L3_PLANNER_DETERMINISTIC")

            verify_trunk_system(self.workspace_dir, commit_sha="skeleton-epoch", handoff=handoff)
            if "L4_VERIFY_SKELETON" not in cp.completed_stages:
                cp.completed_stages.append("L4_VERIFY_SKELETON")

            for stg, role_name, exp_art, hint in [
                ("L2_ORACLE", "oracle_writer", "tests/acceptance/", "Provide acceptance tests in inputs/manual/tests/"),
                ("L3_BUILD", "coder", "services/*", "Place implementation code under inputs/manual/src/"),
                ("L5_REVIEW_LOOP", "reviewer", "release_bundle/review-findings.json", "Configure a live/mock model for AI review"),
                ("L6_CONFORMANCE", "journey", "release_bundle/test-evidence.json", "Configure a live/mock model for journeys"),
            ]:
                if stg not in cp.blocked_stages:
                    cp.blocked_stages.append(stg)
                reports.append(
                    ModelRequiredReport(
                        stage=stg,
                        role=role_name,
                        reason=blocked_roles.get(role_name, "no model configured"),
                        expected_artifact=exp_art,
                        manual_override_hint=hint,
                        created_at=utc_now_iso(),
                    )
                )

            skeleton_bundle = None
            if self.deploy_skeleton_in_none_mode:
                skel_lld = lld or LLDPack(
                    lld_version="0.0.0-skeleton",
                    handoff_hash=handoff.content_hash(),
                    modules=[
                        ModuleSpec(
                            id="MOD-001",
                            component_id=handoff.components[0].id,
                            path="services/skeleton/placeholder.py",
                            layer="domain",
                            responsibilities=["Skeleton placeholder module (mode=none)"],
                            public_interface=[
                                FunctionSpec(
                                    name="skeleton_noop",
                                    signature="def skeleton_noop() -> dict",
                                    purpose="Skeleton placeholder entrypoint for mode=none.",
                                    ac_ids=[handoff.stories[0].criteria[0].id],
                                )
                            ],
                            task_ids=handoff.components[0].linked_task_ids,
                            ac_ids=[handoff.stories[0].criteria[0].id],
                        )
                    ],
                )
                skel_conf = ConformanceReport(
                    matrix_complete=True,
                    uncovered_acs=[a.id for s in handoff.stories for a in s.criteria],
                    unimplemented_tasks=[t for s in handoff.stories for t in s.task_ids],
                )
                skeleton_bundle = run_l7_deploy(
                    run_id=run_id,
                    handoff=handoff,
                    lld=skel_lld,
                    conformance=skel_conf,
                    kg=self.kg,
                    repo_root=self.workspace_dir,
                    task_summaries=[],
                    wireframes_not_applied=wireframes_not_applied,
                )
                if "L7_DEPLOY_SKELETON" not in cp.completed_stages:
                    cp.completed_stages.append("L7_DEPLOY_SKELETON")

            rep_file = self.workspace_dir / "model_required_reports.json"
            rep_file.write_text(
                json.dumps([r.dump_json_dict() for r in reports], indent=2), encoding="utf-8"
            )
            cp.current_stage = "BLOCKED_MODEL_REQUIRED"
            cp.last_status = "BLOCKED_MODEL_REQUIRED"
            cp.graph_epoch = self.kg.epoch
            cp.notes = (
                f"Mode='none': Ran deterministic stages ({', '.join(cp.completed_stages)}). "
                f"Generative stages blocked; see {rep_file}."
            )
            self.resume_mgr.save(cp)
            return PipelineRunOutcome(
                status="BLOCKED_MODEL_REQUIRED",
                checkpoint=cp,
                handoff=handoff,
                lld=lld,
                release_bundle=skeleton_bundle,
                model_required_reports=reports,
            )

        assert lld is not None
        coder_budget = 24000
        if client and "coder" in enabled_roles:
            coder_budget = compute_role_token_budget(client.caps(enabled_roles["coder"].model))
        task_graph = build_task_graph_from_lld(lld)
        cp.pending_build_tasks = [
            t.id for t in task_graph.tasks if t.id not in cp.completed_build_tasks
        ]
        cp.graph_epoch = self.kg.epoch

        if cp.lld_approved != "YES":
            run_l2_scaffold(handoff, lld, self.workspace_dir)
            cp.current_stage = "WAITING_FOR_LLD_APPROVAL"
            cp.last_status = "PAUSED_FOR_LLD_APPROVAL"
            cp.next_command = f"python -m pipeline.cli approve-lld --state-dir {self.state_dir}"
            cp.notes = (
                f"LLDPack generated at {lld_path} and app folder '{self.workspace_dir}' initialized. "
                "Change 'LLD Approved: PENDING' to 'LLD Approved: YES' in state/resume.txt "
                "(or run approve-lld) then run resume."
            )
            self.resume_mgr.save(cp)
            return PipelineRunOutcome(
                status="PAUSED_FOR_LLD_APPROVAL",
                checkpoint=cp,
                handoff=handoff,
                lld=lld,
            )

        run_l2_scaffold(handoff, lld, self.workspace_dir)
        oracle_test_ids = run_l2_oracle(handoff, lld, self.workspace_dir, self.kg, run_id=run_id)
        for stg in ("L2_SCAFFOLD", "L2_ORACLE"):
            if stg not in cp.completed_stages:
                cp.completed_stages.append(stg)

        cp.current_stage = "L3_L4_L5_WAVE_BUILD"
        lld, task_summaries = self._execute_closed_loop_waves(
            handoff=handoff,
            lld=lld,
            oracle_test_ids=oracle_test_ids,
            cp=cp,
            token_budget=coder_budget,
        )
        for stg in ("L3_BUILD", "L4_VERIFY_TASK", "L5_REVIEW_LOOP"):
            if stg not in cp.completed_stages:
                cp.completed_stages.append(stg)

        trunk_vr = verify_trunk_system(
            self.workspace_dir, commit_sha=f"trunk-epoch-{self.kg.epoch}", handoff=handoff
        )
        if not trunk_vr.passed:
            failed_names = [l.layer for l in trunk_vr.layers if not l.passed]
            raise RuntimeError(f"L4-Trunk verification failed on layers: {failed_names}")
        if "L4_VERIFY_TRUNK" not in cp.completed_stages:
            cp.completed_stages.append("L4_VERIFY_TRUNK")

        conformance = run_l6_conformance(handoff, self.kg)
        if "L6_CONFORMANCE" not in cp.completed_stages:
            cp.completed_stages.append("L6_CONFORMANCE")

        bundle = run_l7_deploy(
            run_id=run_id,
            handoff=handoff,
            lld=lld,
            conformance=conformance,
            kg=self.kg,
            repo_root=self.workspace_dir,
            task_summaries=task_summaries,
            wireframes_not_applied=wireframes_not_applied,
        )
        if "L7_DEPLOY" not in cp.completed_stages:
            cp.completed_stages.append("L7_DEPLOY")

        cp.current_stage = "G2_RELEASE_READY"
        cp.last_status = "COMPLETED"
        cp.graph_epoch = self.kg.epoch
        cp.pending_build_tasks = []
        cp.next_command = f"python3 {self.workspace_dir}/run_app.py --port 8000"
        cp.notes = (
            f"App built in '{self.workspace_dir}/'. Run `python3 {self.workspace_dir}/run_app.py --port 8000` "
            "to launch the live web UI and API server!"
        )
        self.resume_mgr.save(cp)

        return PipelineRunOutcome(
            status="COMPLETED",
            checkpoint=cp,
            handoff=handoff,
            lld=lld,
            conformance=conformance,
            release_bundle=bundle,
        )

    def trigger_lld_replan(self, patch: LLDPatch) -> LLDPack:
        cp = self.resume_mgr.load()
        handoff = HLDHandoff.parse_json_compat(Path(cp.handoff_file).read_text(encoding="utf-8"))
        lld_path = self.state_dir / f"lld_pack_{Path(cp.workspace_dir).name}.json"
        if not lld_path.is_file():
            lld_path = self.state_dir / "lld_pack.json"
        current_lld = LLDPack.parse_json_compat(lld_path.read_text(encoding="utf-8"))

        updated_lld, stale_ids = self.kg.apply_lld_replan(current_lld, patch, run_id=cp.run_id)
        violations = lld_violations(updated_lld, handoff)
        if violations:
            raise ValueError("Patched LLD failed validation: " + "; ".join(violations))

        lld_path.write_text(updated_lld.to_pretty_json(), encoding="utf-8")
        run_l2_scaffold(handoff, updated_lld, self.workspace_dir)

        cp.lld_replan_count += 1
        cp.graph_epoch = self.kg.epoch
        cp.last_status = f"LLD_REPLANNED_TO_{updated_lld.lld_version}"
        cp.notes = f"Marked {len(stale_ids)} KG nodes stale: {', '.join(stale_ids)}"
        self.resume_mgr.save(cp)
        return updated_lld

    def _execute_closed_loop_waves(
        self,
        handoff: HLDHandoff,
        lld: LLDPack,
        oracle_test_ids: list[str],
        cp: RunCheckpoint,
        token_budget: int = 24000,
    ) -> tuple[LLDPack, list[dict[str, Any]]]:
        completed_ids: set[str] = set(cp.completed_build_tasks)
        all_summaries: list[dict[str, Any]] = []

        for _ in range(3):
            raw_tg = build_task_graph_from_lld(lld)
            adjusted_tasks = [
                t.copy_with({"token_budget": max(4000, token_budget)}) for t in raw_tg.tasks
            ]
            task_graph = TaskGraph(tasks=adjusted_tasks)
            self.kg.load_task_graph(task_graph, run_id=cp.run_id)
            ports = DeterministicTaskPorts(
                repo_root=self.workspace_dir,
                handoff=handoff,
                lld=lld,
                kg=self.kg,
                oracle_test_ids=oracle_test_ids,
                run_id=cp.run_id,
                seed_defect_on_round_1=True,
            )

            def worker_fn(task: BuildTask, base_ep: int) -> tuple[LoopOutcome, FindingLedger]:
                pkt = build_context_packet(task, handoff, lld, self.kg)
                if not pkt.within_budget:
                    return LoopOutcome.SPLIT, FindingLedger()
                return review_fix_loop(task, ports, LoopConfig(max_rounds=6, min_score=4))

            def on_merged(task: BuildTask, summary: TaskExecutionSummary) -> None:
                completed_ids.add(task.id)
                if task.id not in cp.completed_build_tasks:
                    cp.completed_build_tasks.append(task.id)
                cp.pending_build_tasks = [
                    t.id for t in task_graph.tasks if t.id not in completed_ids
                ]
                if summary.wave_index not in cp.completed_waves:
                    cp.completed_waves.append(summary.wave_index)
                cp.graph_epoch = self.kg.epoch
                cp.last_status = f"MERGED_{task.id}"
                self.resume_mgr.save(cp)

            scheduler = WaveScheduler(self.kg, max_workers=4)
            wave_results = scheduler.run_waves(
                task_graph=task_graph,
                completed_task_ids=completed_ids,
                worker_fn=worker_fn,
                on_task_merged=on_merged,
            )

            replan_needed = False
            for wr in wave_results:
                all_summaries.append(
                    {
                        "task_id": wr.task_id,
                        "module_id": wr.module_id,
                        "wave_index": wr.wave_index,
                        "base_epoch": wr.base_epoch,
                        "merged_epoch": wr.merged_epoch,
                        "reverified_after_neighbor_delta": wr.reverified_after_neighbor_delta,
                        "outcome": wr.outcome.value,
                        "findings": wr.ledger.all_records(),
                        "unresolved": [f.dump_json_dict() for f in wr.ledger.unresolved()],
                    }
                )
                if wr.outcome in (LoopOutcome.SPLIT, LoopOutcome.REPLAN_LLD):
                    patch = split_module_into_submodules(lld, wr.module_id, ticket_id=f"TKT-{wr.task_id}")
                    lld = self.trigger_lld_replan(patch)
                    cp.task_split_count += 1
                    replan_needed = True
                    break
                elif wr.outcome is not LoopOutcome.CONVERGED:
                    raise RuntimeError(f"Task {wr.task_id} failed with outcome {wr.outcome}")

            if not replan_needed:
                break

        return lld, all_summaries
