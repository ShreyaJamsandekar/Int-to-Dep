"""Simple plain-text resume and LLD approval manager for Antigravity and CLI runs."""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any
from pipeline.contracts.base import utc_now_iso


@dataclass
class RunCheckpoint:
    run_id: str = "run-2026-10-22-001"
    handoff_file: str = "examples/sample_handoff.json"
    workspace_dir: str = "app1"
    llm_mode: str = "mock"
    current_stage: str = "H0_INTAKE"
    lld_approved: str = "PENDING"
    lld_source: str = "ai"
    ui_mode_effective: str = "design_system"
    wireframes_applied: bool = True
    graph_epoch: int = 0
    completed_stages: list[str] = field(default_factory=list)
    blocked_stages: list[str] = field(default_factory=list)
    completed_waves: list[int] = field(default_factory=list)
    completed_build_tasks: list[str] = field(default_factory=list)
    pending_build_tasks: list[str] = field(default_factory=list)
    lld_replan_count: int = 0
    task_split_count: int = 0
    last_status: str = "INITIALIZED"
    run_app_command: str = "python3 app1/run_app.py --port 8000"
    next_command: str = "python -m pipeline.cli resume --state-dir state"
    updated_at: str = field(default_factory=utc_now_iso)
    notes: str = "Edit 'LLD Approved: YES' in resume.txt (or run approve-lld) to continue past LLD gate."


class ResumeManager:
    def __init__(self, state_dir: str | Path = "state") -> None:
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.txt_path = self.state_dir / "resume.txt"
        self.json_path = self.state_dir / "checkpoint.json"

    def save(self, cp: RunCheckpoint) -> Path:
        cp.updated_at = utc_now_iso()
        cp.run_app_command = f"python3 {cp.workspace_dir}/run_app.py --port 8000"
        self.json_path.write_text(json.dumps(asdict(cp), indent=2), encoding="utf-8")
        lines = [
            "PIPELINE RESUME FILE (SIMPLE PLAIN TEXT)",
            "========================================",
            "You can read or edit this file directly in Antigravity or any text editor.",
            "To approve the LLD and let the pipeline build and deploy the code, change",
            "'LLD Approved: PENDING' to 'LLD Approved: YES' and run the Next Command below.",
            "",
            f"Run ID: {cp.run_id}",
            f"Handoff File: {cp.handoff_file}",
            f"Workspace Directory: {cp.workspace_dir}",
            f"LLM Mode: {cp.llm_mode}",
            f"Current Stage: {cp.current_stage}",
            f"LLD Approved: {cp.lld_approved}",
            f"LLD Source: {cp.lld_source}",
            f"UI Mode Effective: {cp.ui_mode_effective}",
            f"Wireframes Applied: {'YES' if cp.wireframes_applied else 'NO (wireframes not applied)'}",
            f"Graph Epoch: {cp.graph_epoch}",
            f"Completed Stages: {', '.join(cp.completed_stages) if cp.completed_stages else 'None'}",
            f"Blocked Stages: {', '.join(cp.blocked_stages) if cp.blocked_stages else 'None'}",
            f"Completed Waves: {', '.join(str(w) for w in cp.completed_waves) if cp.completed_waves else 'None'}",
            f"Completed Build Tasks: {', '.join(cp.completed_build_tasks) if cp.completed_build_tasks else 'None'}",
            f"Pending Build Tasks: {', '.join(cp.pending_build_tasks) if cp.pending_build_tasks else 'None'}",
            f"LLD Replan Loops Run: {cp.lld_replan_count}",
            f"Task Splits Run: {cp.task_split_count}",
            f"Last Status: {cp.last_status}",
            f"Updated At: {cp.updated_at}",
            f"Notes: {cp.notes}",
            "",
            "HOW TO RUN THE GENERATED APP & UI:",
            f"Run App Server:  {cp.run_app_command}",
            f"Self-Test App:   python3 {cp.workspace_dir}/run_app.py --self-test",
            "",
            "HOW TO RESUME OR APPROVE:",
            f"Next Command: {cp.next_command}",
            "Approve LLD Command: python -m pipeline.cli approve-lld --state-dir " + str(self.state_dir),
            "Resume Run Command:  python -m pipeline.cli resume --state-dir " + str(self.state_dir),
            "",
        ]
        txt_out = chr(10).join(lines)
        self.txt_path.write_text(txt_out, encoding="utf-8")
        ws_path = Path(cp.workspace_dir)
        if ws_path.is_dir():
            (ws_path / "resume.txt").write_text(txt_out, encoding="utf-8")
        return self.txt_path

    def load(self) -> RunCheckpoint:
        data: dict[str, Any] = {}
        if self.json_path.is_file():
            data = json.loads(self.json_path.read_text(encoding="utf-8"))
        cp = RunCheckpoint(**data) if data else RunCheckpoint()

        if self.txt_path.is_file():
            for raw_line in self.txt_path.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if ":" not in line or line.startswith("#") or line.startswith("="):
                    continue
                k, v = [p.strip() for p in line.split(":", 1)]
                if k == "Run ID" and v:
                    cp.run_id = v
                elif k == "Handoff File" and v:
                    cp.handoff_file = v
                elif k == "Workspace Directory" and v:
                    cp.workspace_dir = v
                elif k == "LLM Mode" and v:
                    cp.llm_mode = v.lower()
                elif k == "Current Stage" and v:
                    cp.current_stage = v
                elif k == "LLD Approved" and v:
                    cp.lld_approved = v.upper()
                elif k == "Graph Epoch" and v.isdigit():
                    cp.graph_epoch = int(v)
                elif k == "Completed Build Tasks":
                    cp.completed_build_tasks = (
                        [] if v in ("None", "") else [x.strip() for x in v.split(",") if x.strip()]
                    )
                elif k == "Pending Build Tasks":
                    cp.pending_build_tasks = (
                        [] if v in ("None", "") else [x.strip() for x in v.split(",") if x.strip()]
                    )
        return cp
