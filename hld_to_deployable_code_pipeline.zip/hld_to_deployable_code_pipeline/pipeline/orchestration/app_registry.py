"""Automatic per-JSON app folder allocator (app1, app2, app3, ...)."""
from __future__ import annotations

import json
from pathlib import Path


def resolve_app_folder(
    handoff_file: str | Path,
    state_dir: str | Path = "state",
    explicit_workspace: str | Path | None = None,
    force_new: bool = False,
) -> Path:
    if explicit_workspace and str(explicit_workspace) not in ("", "auto"):
        return Path(explicit_workspace)

    sdir = Path(state_dir)
    sdir.mkdir(parents=True, exist_ok=True)
    reg_file = sdir / "apps_registry.json"
    registry: dict[str, str] = {}
    if reg_file.is_file():
        try:
            registry = json.loads(reg_file.read_text(encoding="utf-8"))
        except Exception:
            registry = {}

    norm_key = str(Path(handoff_file).resolve())
    if not force_new and norm_key in registry:
        return Path(registry[norm_key])

    existing_nums: list[int] = []
    for folder_name in registry.values():
        bname = Path(folder_name).name
        if bname.startswith("app") and bname[3:].isdigit():
            existing_nums.append(int(bname[3:]))
    for p in Path(".").iterdir():
        if p.is_dir() and p.name.startswith("app") and p.name[3:].isdigit():
            existing_nums.append(int(p.name[3:]))

    next_num = (max(existing_nums) + 1) if existing_nums else 1
    allocated = f"app{next_num}"
    registry[norm_key] = allocated
    reg_file.write_text(json.dumps(registry, indent=2), encoding="utf-8")
    return Path(allocated)
